#This file contain the commands to run the exmaple "simplest" within R

library(calibro)                          #loads Calibro
CE = calEnv$new(name = 'simplest')        #creates a new calibration environment
CE$add.ds(name = 'data1', Y.star = 'obs.csv', TT = 'inputs.csv', Y = 'sims.csv')  #adds a calibration data-et
CE$rd = 'pca'                             #performs Principal Componenet Analysis
CE$sa = 'sobolSmthSpl'                    #performs sensitivity analysis through the "sobolSmthSpl" method
CE$ret = list(mthd = 'ng.screening')      #performs parameter and principal componenet retention with the "ng.screening" method"
CE$mdls = 'gpr.ng.sePar01_whitePar01'     #Builds a meta-model of the type "gpr.ng.sePar01_whitePar01" 
CE$train = list(type = 'fw_training', alg = 'amoeba', vrb = 0)    #trains the meta-model with Nelder–Mead method ("amoeba")
CE$cals = 'cal.gpr.ng'                    #creates the calibrator
CE$cal.mcmc = list(alg = 'amg')           #runs the calibrator with Adaptive Metropolis within Gibbs algorithm ('amg')
CE$cal.res()                              #returns calibration results
CE$genReport(type = 'json', out = 'cal')  #generates json report
