#This file contain the commands to run the exmaple "2targets" within R
#Note well: this example may require some time to run.

library(calibro)	#load calibro

#Create a new calibration environment
CE = calEnv$new(name = '2targets')	


#Add a new dataset
CE$add.ds(name = 'data1', 	#dataset name
	Y.star = 'obs1.csv',	#targets of the calibration 
	TT = 'inputs.csv', 	#input matrix
	Y = 'sim1.csv'		#simulations
)

#Add a new dataset
CE$add.ds(name = 'data2', 	#dataset name
	Y.star = 'obs2.csv',	#targets of the calibration 
	TT = 'inputs.csv',	#input matrix
	Y = 'sim2.csv'		#simulations
)


CE$rd = 'pca'	#perform PCA
CE$sa = 'sobolSmthSpl'	#perform sensitivity analysis with sobolSmthSpl
CE$ret = list(mthd = 'ng.screening')	#perform factor retention with ng.screening
CE$mdls = 'gpr.ng.sePar01_whitePar01'	#build an emulator of the given type
CE$train = list(type = 'training', alg = 'amoeba')	#train emulator
CE$cals = 'cal.gpr.ng'	#build calibrator
CE$cal.mcmc = list(alg = 'amg')	#calibrate with Adaptive Metropolis within Gibbs
CE$cal.res()	#returns calibration results
CE$genReport(type = 'pdf', out = c('dss', 'cal'))	#generates json report


