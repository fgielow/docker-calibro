#  This file is part of Calibro.
#
#  Calibro is free software; you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation; either version 2 of the License, or
#  (at your option) any later version.
#  
#  Calibro is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#  
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software
#  Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
#  MA 02110-1301, USA.

#_DOC_
#ERROR AND WARNING HANDLING FUNCTIONS

.exe.safeFort <- function (fun, ...) {
	#_DOC_
	#Executes fun (which should involve a call to Fortran) whithin try, and then call reset so that
	#no garbage is left in memory
	#_MAIN_
	.reset()
	ANS = try(fun(...))
	.reset()
	return(ANS)
}
.reset <- function () {
	#_DOC_
	#Resets the memory allocated in the Fortran environment.
	#_MAIN_
	.C('__reset_MOD_reset_all')
}	
.actmthd.wrp <- function (obj, arg, mthd) {
	#_DOC_
	#Decorator for active methods of 'calibro.obj' clas objects.
	#_ARGUMENTS_
	#obj: 'calibro.obj' class object
	#arg: arguments to be passed to the method
	#mthd: method
	#_MAIN_ 
	if (!is(arg, 'calibro.obj')) {
		mthd(obj, arg)
	}
}
