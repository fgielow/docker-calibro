#COVARIANCE STRUCTURES
#A covariance strcture (CS) is made of a list of kernels (krns) determing the correlation between different target vaiables (trgs).
#The number of krns (nkrns) is a function of the number of trgs (ntrgs): nkrns = (ntrgs**2 - ntrgs) / 2 + ntrgs 

#  This file is part of Calibro.
#
#  Calibro is free software; you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation; either version 2 of the License, or
#  (at your option) any later version.
#  
#  Calibro is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#  
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software
#  Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
#  MA 02110-1301, USA.

#* CS11 CLASS
cs = R6Class('cs11',
	#_DOC_
	#Class representing the covariance strcture of training data building the Gaussian Process.
	inherit = r6.list,
	#** public
	public = list(
		#*** methods
		#**** initialize
		initialize = function (name, Z, krns) {
			#_DOC_
			#Initialises a CS accroding to the given  name and list of krns.
			#The list contaning the krns must be nemed accoridn to the target correlated by a certain krn.
			#The format for the names is 'id_trg1,id_trg2' (or 'id_trg2,id_trg1').
			#For example, in case ntrgs = 2 : list('1,1' = krn(trg1, trg1), '1,2' = krn(trg1, trg2), '2,2' = krn(trg2, trg2)  
			#_ARGUMENTS_
			#name: name/description for the covariance strcture
			#Z: named list of parameter matrices (one per output of the covariance strcutre)
			#krns: named list of kernels to apply to the matrices in Z
			#_MAIN_
			if (is.list(Z) && is.list(krns)) {
				private$.trgs = names(Z)
				krn.lst = list()
				#~checks that all the needed krns have been provided and orders them as needed
				for (i in 1:length(private$.trgs)) {
					for (j in i:length(private$.trgs)) {
						nm1 = paste(private$.trgs[i], private$.trgs[j], sep = ',')	#'i,j' name
						nm2 = paste(private$.trgs[j], private$.trgs[i], sep = ',')	#'j,i' name
						if (nm1 %in% names(krns)) {									#checks if nm1 is provided and conseq_dbuently stores the krn
							krn.lst[[nm1]] = krns[[nm1]]
						} else if (nm2 %in% names(krns)) {							#cecjks if nm2 is provided and conseq_dbuenteyl stroes the krn
							krn.lst[[nm2]] = krns[[nm2]]
						} else {													#if neither nm1 nor nm2 hve been provided stops
							stop('krns list must be named according to Z')
						}
						if (private$.trgs[i] == private$.trgs[j]) krn.lst[[nm1]]$diag = T
					}
				}
				#~
			} else if (is.matrix(Z) && is(krns, 'kernel')) {
				Z = list('Z' = Z)
				krns$diag = T
				krn.lst = list('Z,Z' = krns)
				private$.trgs = names(Z)
			} else {
				stop('unknown argument type combination. Z list of matrices and krns list of kernels or Z matrix and krns a single kernel.')
			}
			private$.Z = Z
			super$initialize(name = paste0(name, '^{cs}'), objs = krn.lst, cl = 'kernel')										
		},
		#**** bld.ccs
		bld = function () {
			#_DOC_
			#Builds the kernels of the covariance structure.
			#_MAIN_
			.mthd.bld.cs(self)
		},
		add.z = function (Z) {
			#_DOC_
			#Adds a parameter to the covariance structure.
			#_ARGUMENTS_
			#Z: matrix with columns the parameters to add.
			#_MAIN
			.mthd.add_z.cs(self, Z)
		},
		bld.ccs = function (Z.star = NULL) {
			#_DOC_
			#Builds a conditinal cross covariance structure.
			#_ARGUMENTS_
			#Z.star: input matrix for the test set
			#_MAIN_
			.mthd.bld.ccs.cs(self, Z.star)
		},
		bld.csstar = function (Z.star, rplCfs, appCfs, nl) {
			#_DOC_
			#Builds a conditional covariance structure for the test set
			#_ARGUMENTS_
			#Z.star: input matrix for the test set
			#rplCfs: named list with nbames the diagonal covariance function to replace and elements the respective replacing functions.
			#appCfs: list of covariance functions to append to the covariance structure #TODO check
			#_MAIN_
			.mthd.bld.csstar.cs(self, Z.star, rplCfs, appCfs, nl)
		},
		evl = function () {
			#_DOC_
			#Evaluates the covariance structure (i.e. calculates the corresponding covariance matrix)
			#for a combination of hyper parameters (randomly generated from the respective distributions, 
			#if map values are set they a taken instead)
			#_MAIN_
			.mthd.evl.cs(self)
		},
		print = function () {
			#_DOC_
			#Prints a representation representation of the covariance structure to the screen
			#_MAIN_
			.mthd.print.cs(self)
		},
		.fortPars = function () {
			#_DOC_
			#Generates the list of parameters needed to represent the covariance structure in the
			#Fortran environment.
			#_MAIN_
			do.call(paste0('.fortPars.', class(self)[1]), list('CS' = self))
		}
	),
	#** active
	active = list(
		#*** pars
		pars = function () {
			#_DOC_
			#Returns the all the free parameters 
			#_MAIN_
			.actmthd.get_pars.cs(self)
		},
		hp = function () {
			#_DOC_
			#Returns the hyper only the parameters.
			#_MAIN_
			.actmthd.get_hp.cs(self)
		},
		hp.nst = function () {
			#_DOC_
			#Returns only the nested hyper parameters.
			#_MAIN_
			.actmthd.get_nstHp.cs(self)
		},
		maps = function (vals) {
			#_DOC_
			#Returns/set the MAP values of the coavariance structure parameters
			#_MAIN_
			if(missing(vals)){.get.maps.hp(self)}else{.actmthd.wrp(self, vals, ..set_maps.hp)}
		},
		Z = function () {
			#_DOC_
			#Return the input matrix of the covariance structure
			#_MAIN_
			return(private$.Z)
		},
		trgs = function () {
			#_DOC_
			#Returns the targets of the covariance structure
			#_MAIN_
			return(private$.trgs)
		},
		.id = function () {
			#_DOC_
			#Returns the id identifying yhe kind of covariance structure in the Fortran environment.
			#_MAIN_
			.intrf.CS__id(class(self)[1])
		}
	),
	#** private
	private = list(
		#*** attributes
		.trgs = NULL,	#tagets names
		.Z = NULL,		#named list of parameter matrices
		#*** methods
		.init = function () {
			#_DOC_
			#Initialises the current covariance structure in the Fortran environment.
			#_MAIN_
			do.call(paste0('.init.', class(self)[1]), list('CS' = self))
		} 
	)
)

#* CS12 CLASS
ccs = R6Class('cs12',
	#_DOC_
	#Class representing a cross-covariance structure between training ans test set.
	inherit = cs,
	#** public
	public = list(
		#*** method
		#**** initialize
		initialize = function (name, Z, Z.star, krns) { 
			#_DOC_
			#Initialises the CCS
			#_ARGUMENTS_
			#name: name or short description for the CCS
			#Z, Z.star: named list of training parameter matrices and named list of test parameter matrices
			#krns: named list of kernels
			#_MAIN_
			super$initialize(name, Z, krns)
			private$.Z.star = Z.star
		},
		bld.ccs = NULL,		#cannot generate conditional cross-covariance structures
		bld.csstar = NULL	#cannot generate conditional covariance structure for the test set
	),
	#** active
	active = list(
		#*** Z.star
		Z.star = function () {
			#_DOC_
			#Returns the input matrix of the test set.
			#_MAIN_
			return(private$.Z.star)
		}
	),
	#** private
	private = list(
		#*** attributes
		.Z.star = NULL	#input matrix of the test set
	)
)

#* CS22 CLASS
csstar = R6Class('cs22',
	#_DOC_
	#Class representing the observation covariance structure of the test set.
	inherit = cs,
	#** public
	public = list(
		bld.ccs = NULL,		#cannot generate conditional cross-covariance structures
		bld.csstar = NULL 	#cannot generate conditional covariance structure for the test set
	)
)

#* METHOD FUNCTIONS
#_DOC_
#Functions called as methods in the classes 'cs11', 'cs12', 'cs22', 'csd', 'cs12d' and 'cs22d'.
#In the following CS indicates an object of the above classes.
.mthd.bld.cs <- function (CS) {
	#_DOC_
	#Builds the kernels within the covariance structure.
	#_MAIN_
	nms = lapply(CS$Z, function(Z)colnames(Z))
	ANS = lapply(1:length(nms), function(i)CS$expand()[[i]]$bld(nms[[i]]))
	invisible(CS)
}
.mthd.add_z.cs <- function (CS, Z) {
	#_DOC_
	#Adds a parameter to the covariance structure.
	#_ARGUMENTS_
	#Z: matrix with columns the parameters to add.
	#_MAIN_
	Z0 = CS$Z
	if (is.matrix(Z) && length(CS$Z) == 1) {
		Z0[[1]] = cbind(Z0[[1]], Z)
	} else if (is.list(Z)) {
		if (all(names(Z) == names(CS$Z))) {
			Z0 = CS$Z
			for (nm in names(CS$Z)) Z0[[nm]] = cbind(Z0[[nm]], Z[[nm]])
		}
	} else {
		stop('argument Z is not compatible.')
	}
	CS$.set.private('.Z', val = Z0)
	CS$bld()
	invisible(CS)
}
.mthd.bld.ccs.cs <- function (CS, Z.star) {
	#_DOC_
	#Builds a cross-covariance strcture from this covariance strcture (stripped from diagonal cfs).
	#Arguements:
	#Z.star: named list of test input matrices
	#_MAIN_
	krns.cnd = CS$exe.mthd('cnd', rplCfs = 'diag0', appCfs = NULL, exp = T, cp.rm = F, wrap = F, mode = 'lapply')
	names(krns.cnd) = names(CS$list)
	if (is.null(Z.star)) Z.star = CS$Z
	return(ccs$new(name = paste(CS$name, '*'), Z = CS$Z, Z.star = Z.star, krns = krns.cnd))
}
.mthd.bld.csstar.cs <- function (CS, Z.star, rplCfs, appCfs, nl) {
	#_DOC_
	#Creates a conditional covariance strcture. A conditional covariance strctures is made by the same kernels as its parent
	#but may have different diagonal covariance functions.
	#_ARGUMENTS_
	#Z.star: input matrix of the test set.
	#rplCfs: named list of cfs. Each name indicates the cf to replace, if argument is the new cf.
	#appCfs: named list of cfs to append to the kernels. The names of the list must be the names of the kernels to which the functions have to be appended.
	#_MAIN_
	d = which(CS$get.attr('diag', exp = T, mode = 'sapply', wrap = F, cp.rm = T))
	krns.cnd = list()
	for (i in 1:length(CS$list)) {
		if (i %in% d) {
			if (CS$list[[i]]$name %in% names(appCfs)) {
				appCfsi = appCfs[[CS$list[[i]]$name]]
			} else {
				appCfsi = NULL
			}
			krns.cnd[[i]] = CS$list[[i]]$cnd(rplCfs = rplCfs, appCfs = appCfsi, nl = nl)
		}
	}
	if (is.null(Z.star)) {
		Z.star = CS$Z
	} else if (is.matrix(Z.star) && length(CS$Z) == 1) {
		Z = list()
		Z[[names(CS$Z)[1]]] = Z.star
		Z.star = Z
	}	
	names(krns.cnd) = names(CS$list)
	return(csstar$new(name = paste(CS$name, '**'), Z = Z.star, krns = krns.cnd))
}	
.mthd.evl.cs <- function (CS) {
	#_DOC_
	#Calsulates the covariance matrix from the covariance strcture.
	#_CONTAINS_
	.evl <- function () {
		hp = CS$pars$exe.mthd('r', n = 1, exp = T, wrap = F, cp.rm = T, mode = 'sapply') 
		CS$.get.private('.init')()
		return(..evl.csi(i = 1, fortPars = CS$.fortPars(), hp = hp, ans = T))
	}
	return(.exe.safeFort(.evl))		
}
.actmthd.get_hp.cs <- function (CS) { 
	#_DOC_
	#Returns a r6.list containing the hp of all the cfs building the kernels in the strcuture.
	#_MAIN_
	return(CS$get.attr('hp', exp = T, mode = 'lapply', cp.rm = F, wrap = T, cl = 'uvrv'))
}
.actmthd.get_nstHp.cs <- function (CS) { 
	#_DOC_
	#Returns a r6.list containing the hp nested in the hp of the covariance functions.
	#_MAIN_
	hp.nst = CS$hp$exe.mthd('get.uvrv.pars', wrap = F, cp.rm = T, mode = 'lapply')
	hp.nst = unlist(list.null.rm(hp.nst))
	if (length(hp.nst) > 0) {
		return(r6.list$new(name = NULL, objs = hp.nst, cl = 'uvrv'))
	} else {
		return(NULL)
	}
}
.actmthd.get_pars.cs <- function (CS) {
	#_DOC_
	#Retrieves the parameters of the 'cs' class object.
	#_MAIN_
	return(r6.list$new(
		name = paste0(CS$name, '.pars'), 
		objs = list.null.rm(list('hp' = CS$hp, 'hp.nst' = CS$hp.nst)),
		cl  ='uvrv'
	))
}
.actmthd.get_pars.cs <- function (CS) {
	#_DOC_
	#Extracts and returns the parameters of the CS.
	#_MAIN_
	return(r6.list$new(
		name = paste0(CS$name, '.pars'), 
		objs = list.null.rm(list('hp' = CS$hp, 'hp.nst' = CS$hp.nst)),
		cl  ='uvrv'
	))
}
.mthd.print.cs <- function (CS) {
	#_DOC_
	#Prints a human friendly version of the covariance structure
	#_MAIN_
	ANS = matrix(NA, nrow = length(CS$trgs), ncol = length(CS$trgs))
	rownames(ANS) = CS$trgs
	colnames(ANS) = CS$trgs
	xy = strsplit(names(CS$list), ',', fixed = T)
	for (i in 1:length(xy)) {
		ANS[xy[[i]][1],xy[[i]][2]] = CS$list[[i]]$name
		ANS[xy[[i]][2],xy[[i]][1]] = CS$list[[i]]$name
	}
	rownames(ANS) = paste0(' ', rownames(ANS))
	cat(paste('\n CS:', CS$name, '\n\n'))
	cat('* Structure:\n\n')
	print(ANS)
	cat('\n where:\n')
	for (k in CS$list) print(k)
	cat('* Z:\n')
	for (i in length(CS$Z)) {
		cat(paste0('\n** ', names(CS$Z)[i], ': \n'))
		print(summary(CS$Z[[i]]))
	}
}

#* AUXILIARY FUNCTIONS
.fortPars.cs11 <- function (CS) {
	#_DOC_
	#Builds a list contaning all the parameters needed to initialise the CS in the Fortran 90 subrputines.
	#_MAIN_
	#Build CM strcuture
	krns = CS$exe.mthd('.fortPars', exp = T, wrap = FALSE, cp.rm = FALSE, mode = 'lapply')	
	nkrns = length(krns)
	ntrgs = length(CS$trgs)
	m = sapply(CS$Z, nrow)
	b = cumsum(m)
	a = b - m + 1
	mould = c()
	m = unlist(lapply(m, function(x)1:x))
	k = 0 
	for (i in 1:length(a)) {
		for (j in 1:i) {
			k = k + 1
			if (!identical(KRN0, CS$list[[k]])) {
				rwcl = symm.indexes(a[i]:b[i], a[i]:b[i])
				mould = rbind(mould, cbind(
					rwcl, 				#covariance matrix cells
					rep(i, nrow(rwcl)), #Z1 index
					rep(j, nrow(rwcl)),	#Z2 index
					m[rwcl[,1]], 		#Z1 rows
					m[rwcl[,2]], 		#Z2 rows 
					rep(k, nrow(rwcl))	#kernel index
				))
			}
			krns[[k]][['hpMapp']] = CS$list[[k]]$.pars.mapping(CS$pars$expand(cp.rm = T))	#update parameter mapping
			p = sapply(colnames(CS$Z[[i]]), function(x)which(colnames(CS$Z[[j]]) == x))
			krns[[k]][['nhp']] = as.matrix(CS$list[[k]]$.nhp())
		}			
	}
	colnames(mould) = c('i', 'j', 'Z1id', 'Z2id', 'z1i', 'z2j', 'k')
	fortPars = list(
		'nkrns' = nkrns, 
		'krns' = krns, 
		'ntrgs' = ntrgs, 
		'id' = CS$.id, 
		'Z1' = CS$Z,
		'MOULD' = mould
	)
	class(fortPars) = 'fortPars.cs'
	return(fortPars)
} 
.fortPars.cs12 <- function (CS) {
	#_DOC_
	#Return a list contaning all the parameters needed to initialise the CS in the Fortran 90 subrputines.
	#_MAIN_
	krns = CS$exe.mthd('.fortPars', exp = T, wrap = FALSE, cp.rm = FALSE, mode = 'lapply')	
	nkrns = length(krns)
	ntrgs = length(CS$trgs)
	m = sapply(CS$Z, nrow)
	m.star = sapply(CS$Z.star, nrow)
	b1 = cumsum(m)
	a1 = b1 - m + 1
	b2 = cumsum(m.star)
	a2 = b2 - m.star + 1
	mould = c()
	m = unlist(lapply(m, function(x)1:x))
	m.star = unlist(lapply(m.star, function(x)1:x))
	k = 0
	for (i in 1:length(a1)) {
		for (j in i:length(a2)) {
			k = k + 1
			rwcl = expand.grid(a1[i]:b1[i], a2[i]:b2[i])
			mould = rbind(mould, cbind(
				rwcl, 				#covariance matrix cells
				rep(i, nrow(rwcl)), #Z1 index
				rep(j, nrow(rwcl)),	#Z2 index
				m[rwcl[,1]], 		#Z1 rows
				m.star[rwcl[,2]], 	#Z2 rows 
				rep(k, nrow(rwcl))	#kernel index
			))
			krns[[k]][['hpMapp']] = CS$list[[k]]$.pars.mapping(CS$pars$expand(cp.rm = T))	#update parameter mapping
			p = sapply(colnames(CS$Z[[i]]), function(x)which(colnames(CS$Z[[j]]) == x))
			krns[[k]][['nhp']] = as.matrix(CS$list[[k]]$.nhp())
		}
	}
	colnames(mould) = c('i', 'j', 'Z1id', 'Z2id', 'z1i', 'z2j', 'k')
	fortPars = list(
		'nkrns' = nkrns, 
		'krns' = krns, 
		'ntrgs' = ntrgs, 
		'id' = CS$.id, 
		'Z1' = CS$Z,
		'Z2' = CS$Z.star,
		'MOULD' = as.matrix(mould)
	)
	class(fortPars) = 'fortPars.ccs'
	return(fortPars)
}
.fortPars.cs22 <- function (CS) {
	#_DOC_
	#Creates the list of parameters necessary to represent the 'cs22' object in the Fortran environment.
	#_MAIN_
	fortPars = .fortPars.cs11(CS)
	fortPars[['Z2']] = CS$Z
	fortPars[['Z1']] = NULL
	class(fortPars) = 'fortPars.cs22'
	return(fortPars)
}
.init.CMi <- function (i, fortPars) {
	#_DOC_
	#Initialises the ith covariance matrix (CM), by setting its dimensions in the Fortran environment.
	#_ARGUMENTS_
	#i: CM index
	#fortPars: list of paramters generated with a ".forPars." function
	#_MAIN_
	if (fortPars[['id']] == 1) { 
		m1 = sum(sapply(fortPars[['Z1']], nrow))
		m2 = m1
	} else if (fortPars[['id']] == 2) { 
		m1 = sum(sapply(fortPars[['Z1']], nrow))
		m2 = sum(sapply(fortPars[['Z2']], nrow))
	} else if (fortPars[['id']] == 3) {
		m1 = sum(sapply(fortPars[['Z2']], nrow))
		m2 = m1
	}
	CM = matrix(0, nrow = m1, ncol = m2)
	.intrf.CM__init(i, cmId = fortPars[['id']], CM) 
}
.init.Zi <- function (i, zId, fortPars) {
	#_DOC_
	#Initialises the ith list of input matrices, by setting dimensions in the Fortran environment.
	#_ARGUMENTS_
	#i: list index
	#zId: Z identifier
	#fortPars: list of paramters generated with a ".forPars." function
	#_MAIN_
	.intrf.Z__allocateMVi(i, zId = zId, n = fortPars[['ntrgs']])
	Z = paste0('Z', zId)
	for (j in 1:fortPars[['ntrgs']]) .intrf.Z__init(i, j, zId = zId, fortPars[[Z]][[j]])	
}
.init.cs11 <- function (CS) {
	#_DOC_
	#Initialises the 'cs11' class objects, in the Fortran environment
	#_MAIN_
	fortPars = CS$.fortPars()
	#~allocation
	.intrf.CS__allocate(csId = fortPars[['id']], ncs = 1)
	.intrf.MOULD__allocate(csId = fortPars[['id']], ncs = 1)
	.intrf.Z__allocate(zId = 1, n = 1)
	.intrf.CM__allocate(cmId = fortPars[['id']], n = 1)
	#~initialisation
	.init.csi(i = 1, fortPars = fortPars)
	.init.Zi(i = 1, zId = 1, fortPars = fortPars)
	.init.CMi(i = 1, fortPars = fortPars)
	#~
}
.init.cs12 <- function (CS) {
	#_DOC_
	#Initialises the 'cs12' class objects in the Fortran environment
	#_MAIN_
	fortPars = CS$.fortPars()
	#~allocation
	.intrf.CS__allocate(csId = fortPars[['id']], ncs = 1)
	.intrf.MOULD__allocate(csId = fortPars[['id']], ncs = 1)
	.intrf.Z__allocate(zId = 1, n = 1)
	.intrf.Z__allocate(zId = 2, n = 1)
	.intrf.CM__allocate(cmId = fortPars[['id']], n = 1)
	#~initialisation
	.init.csi(i = 1, fortPars = fortPars)
	.init.Zi(i = 1, zId = 1, fortPars = fortPars)
	.init.Zi(i = 1, zId = 2, fortPars = fortPars)
	.init.CMi(i = 1, fortPars = fortPars)
	#~
}
.init.cs22 <- function (CS) {
	#_DOC_
	#Initialises the 'cs22' class objects in the Fortran environment
	#_MAIN_
	fortPars = CS$.fortPars()
	#~allocation
	.intrf.CS__allocate(csId = fortPars[['id']], ncs = 1)
	.intrf.MOULD__allocate(csId = fortPars[['id']], ncs = 1)
	.intrf.CM__allocate(fortPars[['id']], n = 1)
	.intrf.Z__allocate(zId = 2, n = 1)
	#~initialisation
	.init.csi(i = 1, fortPars = fortPars)
	.init.Zi(i = 1, zId = 2, fortPars = fortPars)
	.init.CMi(i = 1, fortPars = fortPars)
	#~
}
.init.csi <- function (i, fortPars) {
	#_DOC_
	#Initialises the ith covariance structure.
	#_ARGUMENTS_
	#i: CS index
	#fortPars: list of the parameters necessary to initialise the ith CS in the Fortran environment. 
	#	To be generated through a .fortPars. function.
	#_MAIN_
	.intrf.CS__allocateMMi(i, fortPars[['id']], fortPars[['nkrns']])				
	for (j in 1:fortPars[['nkrns']]) {
		.intrf.CS__allocateMVi(i, j, fortPars[['id']])
		for (k in 1:3) {
			.intrf.CS__set_krnAttr(i, j, k, fortPars[['id']], fortPars[['krns']][[j]][[k]])
		}
	}
	.intrf.MOULD__init(i, fortPars[['id']], fortPars[['MOULD']])
	if (fortPars[['id']] %in% c(4, 5, 6)) {
		.intrf.H__init(i, fortPars[['H']])
	}
	
}
..evl.csi <- function (i, fortPars, hp, ans = T) {
	#_DOC_
	#Evaluates the ith CS
	#_ARGUMENTS_
	#i: CS index
	#hp: hyper parameters values
	#ans: if T => returns calcualtes CM
	#fortPars: list of paramters generated with a ".forPars." function
	#_MAIN_
	.intrf.CS__evlCm(csId = fortPars[['id']], i = i, hp = hp)
	if (ans) return(.intrf.CM__get(i, fortPars[['id']]))
} 
