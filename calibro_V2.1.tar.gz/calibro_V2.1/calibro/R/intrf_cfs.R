#  This file is part of Calibro.
#
#  Calibro is free software; you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation; either version 2 of the License, or
#  (at your option) any later version.
#  
#  Calibro is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#  
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software
#  Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
#  MA 02110-1301, USA.

#_DOC_
#Kernels and covariance functions

#* INTERFACES TO FORTRAN SUBROUTINES FOR KERNEL OBJS
.intrf.krn__evl <- function (x1, x2, hp, fortPars, i, j) {
	#_DOC_
	#Calls the Fortran subroutine that evaluates the the kernel
	#_ARGUMENTS_
	#x1, x2: input vectors
	#fortPars: list of parameters needed by the Fortran subroutines
	#_MAIN_
	R = .C('__intrf_cfs_MOD_intrf_krn__evl', 
		'RES' = as.double(0), 
		'lwhich' = as.integer(nrow(fortPars[['cfs']])), 
		'lx1' = as.integer(length(x1)), 
		'lx2' = as.integer(length(x2)), 
		'Lhp' = as.integer(sum(fortPars[['nhp']])), 
		'which' = as.integer(fortPars[['cfs']]), 
		'x1' = as.double(x1), 
		'x2' = as.double(x2), 
		'hp' = as.double(hp),
		'nhp' = as.integer(fortPars[['nhp']]),
		'i' = as.integer(i),
		'j' = as.integer(j)
	)
	return(R[[1]])
}

#* 	INTERFACES TO FORTRAN SUBROUTINE FOR CF OBJS

#** TO EVALUATE
.intrf.cf__evl <- function (which, x1, x2, hp, i, j) {
	#_DOC_
	#Evaluates the covariance function ideintified by the index which
	#_MAIN_	
	ANS = .C('__intrf_cfs_MOD_intrf_cf__evl', 
		'RES' = double(1),
		'lx1' = as.integer(length(x1)), 
		'lx2' = as.integer(length(x2)),
		'lhp' = as.integer(length(hp)),
		'which' = as.integer(which),
		'x1' = as.double(x1),
		'x2' = as.double(x2),
		'hp' = as.double(hp), 
		'i' = as.integer(i),
		'j' = as.integer(j)
	)
	return(ANS[['RES']])
}

#** TO INITIALIZE CF VECTOR
.intrf.covfns__init <- function () {
	#_DOC_
	#Initialise the vector contaning the covariance functions.
	#_MAIN_
	ANS = .C('__intrf_cfs_MOD_intrf_covfns__init')
}

#** CF IDS
.intrf.cf__id <- function (cfname) {
	#_DOC_
	#Retrieves and returns the id corresponding to the cf specified in the Fortran environment.
	#_ARGUMENTS_
	#cfname: class of the covariance function
	#_MAIN_
	return(.C(paste0('__intrf_cfs_MOD_intrf_', cfname, '__id'), integer(1))[[1]])
}
