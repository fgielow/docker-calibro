#  This file is part of Calibro.
#
#  Calibro is free software; you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation; either version 2 of the License, or
#  (at your option) any later version.
#  
#  Calibro is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#  
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software
#  Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
#  MA 02110-1301, USA.

#* MATHEMATICAL AND STATISTICAL FUNCTIONS

#** TO SCALE AND NORMALIZE TRANSFORM

normalize <- function (X, MAXS = NULL, MINS = NULL, inv = F) {
	#_DOC_
	#Normalizes a vector or a matrix according to the given 'MAXS' and 'MINS'.
	#If 'MAXS' and 'MINS' are not provided 'X' is scaled so that each column is within [0,1].
	#_ARGUMENTS_
	#X: matrix or vector to normalize
	#MAXS, MINS: maxima and minima. NULL or NA values are set to max(X[,i]) and min(X[,i]) respectively.
	#_MAIN_
	X = as.matrix(X)
	if (inv) {
		return(scale(scale(X, center = F, scale = (MAXS - MINS)**(-1)), center = -MINS, scale = F))
	} else {
		if (is.null(MAXS)) MAXS = apply(X, 2, max)
		if (is.null(MINS)) MINS = apply(X, 2, min)
		for (i in 1:ncol(X)) {
			if (is.na(MAXS[i])) MAXS[i] = max(X[,i])
			if (is.na(MINS[i])) MINS[i] = min(X[,i])
		}
		ANS = scale(X, center = MINS, scale = MAXS - MINS)
		attr(ANS, 'scaled:center') = NULL
		attr(ANS, 'scaled:scale') = NULL
		attr(ANS, 'norm:max') = MAXS
		attr(ANS, 'norm:min') = MINS
		return(ANS)
	}
}	
scaleT <- function (X, C = T, S = T) {
	#_DOC_
	#Transposed scale function. It scales a matrix row-wise intead that column-wise as the normal
	#'scale' function does.
	#_ARGUMENTS_
	#X: matrix to scale
	#C: center or not center or vector respect which to center the matrix
	#S: scale or not scale or vector respect which to scale the matrix
	#_MAIN_
	return(t(scale(t(X), center = C, scale = S)))
} 
scale.var <- function (X, S) {
	#_DOC_
	#Scales only the variance and leaves the mean unchanged.
	#_ARGUMENTS_
	#X: matrix to scale
	#S: scale or not scale or vector respect which to scale the matrix
	#_MAIN_
	C = apply(X, 2, mean)
	X = scale(X, center = C, scale = S)
	X = apply(X, 1, function(x)x + C)
	return(X)
} 
scale.varT <- function (X, S) {
	#_DOC_
	#Scales only the variance and leaves the mean unchanged.
	#_ARGUMENTS_
	#X: matrix to scale
	#S: scale or not scale or vector respect which to scale the matrix
	#_MAIN_
	C = apply(t(X), 2, mean)
	X = scale(t(X), center = C, scale = S)
	X = apply(t(X), 1, function(x)x + C)
	return(t(X))
} 
trn <- function (p, ctr) {
	#_DOC_
	#Transforms the inputs according to the contrains indicated, so as to achive an unconstrined optimisation problem
	#_ARGUMENTS_
	#p: input vector
	#ctr: type of constrain (-ctr inverse => inverse trnasformation)
	#_MAIN_
	if (ctr == 0) {			#no constrain => no trnation
		return(p)
	} else if (ctr == 1) {	#p > 0 => use exp
		return(exp(p))
	} else if (ctr == -1) { #p > 0 => use log 
		return(log(p))
	}
}

#** PROJECTIONS

gramShmidt <- function (u, v) {
	#_DOC_
	#Gram-Shmidt orthogonalisation process where the vector v is made orthogonal to the vector u.
	#_ARGUMENTS_
	#u,v: vectors
	#_MAIN_
	prj = (t(v) %*% u) / (t(u) %*% u) * u
	v = v - prj
	return(v)
}	
lsq.fit <- function (Y, basis, A = NULL) {
	#_DOC_
	#It calculates the regression weights for a set of basis function given a precision matrix or
	#a set of rpecision matric containined into an array
	#_ARGUMENTS_	
	#Y: observations or target of the regression (column-wise)
	#basis: matrix of basis vectors (column-wise)
	#A: precision matrix
	#_MAIN_
	Y = as.matrix(Y)
	basis = as.matrix(basis)
	if (is.null(A)) {	#if A is not specified it is set ot the identity matrix
		ANS = solve(t(basis) %*% basis, t(basis) %*% Y)
	} else {
		ANS = solve(t(basis) %*% A %*% basis, t(basis) %*% A %*% Y)
	}
	return(t(ANS))
}
prj.mat <- function (K) {
	#_DOC_
	#Given a set of basis returns the projection matrix in the orthogonal space
	#_ARGUMENTS_
	#K: matrix of basis vector (columns)
	#_MAIN_
	return(K %*% solve(t(K)%*%K) %*%t(K))
}
	 	
#** GOODNESS OF FIT		
				
dst <- function (x1, x2) {
	#_DOC_
	#Euclidean distance between the points identified by the vectors 'x1' and 'x2'.
	#_ARGUMENTS_
	#x1, x2: vectors
	#_MAIN_ 
	return(nrm(x2 - x1))
}
ssq <- function (x) {
	#_DOC_
	#Sum of squares of the vector 'x'.
	#_ARGUMENTS_
	#x: vector
	return(sum(x^2))
}
nrm <- function (x) {
	#_DOC_
	#Euclidean norm of the vector 'x'.
	#_ARGUMENTS_
	#x: vector
	#_MAIN_
	return(sqrt(ssq(x)))
}
mse <- function (y, y.hat) {
	#_DOC_
	#Mean Squared Error between the observations ('y') and the predictions ('y.hat').
	#_ARGUMENTS_
	#y: obeservation vactor
	#y.hat: prediction vector
	#_MAIN_
	mean((y - y.hat)^2) 
}
rmse <- function (y, y.hat) {
	#_DOC_
	#Root Mean Squared Error between the observations ('y') and the predictions ('y.hat').
	#_ARGUMENTS_
	#y: observation vector
	#y.hat: prediction vector.
	#_MAIN_
	sqrt(mse(y, y.hat))
} 
mbe <- function (y, y.hat) {
	#_DOC_
	#Mean Biased Error between the observations ('y') and the predicitons ('y.hat').
	#_ARGUMENTS_
	#y: observation vector
	#y.hat: prediction vector
	#_MAIN_
	return(mean(y - y.hat))
}
nmbe <- function (y, y.hat) {
	#_DOC_
	#Normalised (respect to the observation mean) Mean Biased Error.
	#Returns the percentage respect to the observation mean.
	#Reference: ASHRAE GUIDE 14-2002: Measurement of Energy and Demand Savings ASHRAE, 2002 
	#_ARGUMENTS_
	#y: observation vector
	#y.hat: prediction vector
	mbe(y, y.hat) / mean(y)
}
cvrmse <- function (y, y.hat) {
	#_DOC_
	#Coefficient of Variation of the Root Mean Squared Error.
	#Returns the percentage respect to the observation mean.
	#Reference: ASHRAE GUIDE 14-2002: Measurement of Energy and Demand Savings ASHRAE, 2002 
	#_ARGUMENTS_
	#y: observation vector
	#y.hat: prediction vector
	#_MAIN_
	rmse(y, y.hat) / mean(y)
}
reddyGOF <- function (y, y.hat) {
	#_DOC_
	#Reddy Goodness Of Fit criteria.
	#Combines the nmbe (%) and the rmse (%).
	#Reference: Cipriano, J.; Mor, G.; Chemisana, D.; Perez, D.; Gamboa, G. & Cipriano, X. 
	#Evaluation of a multi-stage guided search approach for the calibration of building energy simulation 
	#models Energy and Buildings, 2015, 87, 370 - 385 
	#_ARGUMENTS_
	#y: observation vector
	#y.hat: prediction vector
	#_MAIN_
	sqrt(2) / 2 * sqrt(nmbe(y, y.hat)^2 + cvrmse(y, y.hat)^2)
}
Rscore1 <- function (y, y.hat) {
	#_DOC_
	#Coefficient of determination (R^2 score)
	#_ARGUMENTS_
	#y: observation vector
	#y.hat: prediction vector
	#_MAIN_
	ssq(y.hat - mean(y)) / ssq(y - mean(y))
}
Rscore2 <- function (y, y.hat) {
	#_DOC_
	#Coefficient of determination (R^2 score)
	#_ARGUMENTS_
	#y: observation vector
	#y.hat: prediction vector
	#_MAIN_
	res = y - y.hat
	1 - ssq(res) / ssq(y - mean(y))
}
Rscore3 <-function (y, y.hat) {
	#_DOC_
	#Coefficient of determination (R^2 score)
	#_ARGUMENTS_
	#y: observation vector
	#y.hat: prediction vector
	#_MAIN_
	var(y.hat) / var(y)
}

#** STATS
quantile.boot <- function (x, q, R, B) {
	ANS = sapply(1:R, function(i)quantile(sample(x, size = B, replace = T), q))
	if (length(q) > 1) {
		M = apply(ANS, 1, mean)
	} else {
		M = mean(ANS)
	}
	return(list('M' = M, 'boot.M' = ANS))
}
test.white <- function (x, p = F) {
	#_DOC_
	#Tests if a sample is gaussian i.i.d. throught its correlaton.
	#_ARGUMENTS_
	#x: sample
	#_MAIN_
	ACF = acf(x, plot = F)
	m = max(ACF$lag)
	n = length(x)
	R = n * sum(ACF$acf[-1]**2) 
	ifelse(p, return(pchisq(R, m)), R)
}
test.white.mat <- function (X, p = F) {
	R = sum(apply(X, 2, test.white, p = F))
	m = floor(ncol(X) * 10*log10(nrow(X)))
	ifelse(p, return(pchisq(R, m)), R)
}
density.mode <- function (x) {
	#_DOC_
	#Determines the mode of the vector 'x' as the maximum of the function 'density'.
	#_ARGUMENTS_
	#x: vector
	#_MAIN_
	d = density(x, na.rm = T)
	d$x[which.max(d$y)]
} 
avg <-function (x, n, last = T) {
	#_DOC_
	#Averages the vector 'x' each 'n' elements.
	#_ARGUMENTS_
	#x: vector
	#n: averaging step
	#last: as in split.mat function  
	A = split.mat(X = x, L = n, last = last, dm = 2)
	apply(A, 2, mean)
} 

#** MATH
log.cnv <- function (x, b1 = exp(1), b2 = 10) {
	#_DOC_
	#Coverts the given log from base b1 to base b2.
	#_ARGUMENTS_
	#x: log value
	#b1: intial base
	#b2: final base
	#_MAIN_
	return(x / log(b2, base = b1))
}
BF.log10 <- function (L0, L1, cnv = T) {
	#_DOC_
	#Returns the signficance of a Bayes Factor according to log10 scale.
	#Reference: Kass, R. E. & Raftery, A. E. Bayes Factors Journal of the American Statistical Association, Informa UK Limited, 1995, 90, 773-795 
	#_ARGUMENTS_
	#L0: log likelihood of model 0
	#L1: log likelihood of model 1
	#cnv: if T converts the log likelihoods from base e to base 10
	#_MAIN_
	if (cnv) {
		L0 = log.cnv(L0)
		L1 = log.cnv(L1)
	}
	B10 = L1 - L0
	ev = NULL
	#evideince agains H0
	if (B10 < 0) {
		ev = 'NEGATIVE'
	} else if (B10 >= 0 && B10 < 1/2) {
		ev = 'WEAK'
	} else if (B10 >= 1/2 && B10 < 1) {
		ev = 'SUBSTANTIAL'
	} else if (B10 >= 1 && B10 < 2) {
		ev = 'STRONG'
	} else if (B10 >= 2) {
		ev = 'DECISIVE'
	}
	names(B10) = ev 
	return(B10)
}
BF.2ln <- function (L0, L1) {
	#_DOC_
	#Returns the signficance of a Bayes Factor according to ln scale.
	#Reference: Kass, R. E. & Raftery, A. E. Bayes Factors Journal of the American Statistical Association, Informa UK Limited, 1995, 90, 773-795 
	#_ARGUMENTS_
	#L0: log likelihood of model 0
	#L1: log likelihood of model 1
	#_MAIN_
	B10 = 2 * (L1 - L0)
	ev = NULL
	if (B10 < 0) {
		ev = 'NEGATIVE'
	} else if (B10 >= 0 && B10 < 2) {
		ev = 'WEAK'
	} else if (B10 >= 2 && B10 < 6) {
		ev = 'POSITIVE'
	} else if (B10 >= 6 && B10 < 10) {
		ev = 'STRONG'
	} else if (B10 >= 10) {
		ev = 'VERY STRONG'
	}
	names(B10) = ev 
	return(B10)
}
lndet <- function(A){
	#_DOC_
	#Calculates the log determinat of a matrix 'A'
	#_MAIN_
	d = diag(chol(A))
	return(2 * sum(log(d)))
}
logSumExp <- function (x, b = exp(1)){
	#_DOC_
	#Returns the log of a sum of exponentials given as log.
	#_ARGUMENTS_
	#x: vector of ln
	#b: logarithm base
	#_MAIN_
	m = max(x)
	x.nrm = x - m
	return(m + log(sum(exp(x.nrm)), base = b))
}
logMeanExp <- function (x, b = exp(1)) {
	#_DOC_
	#Returns the log of the mean of a series of exponential given as log.
	#_ARGUMENTS_
	#x: vector of ln
	#b: logarithm base 
	#_MAIN_
	logSumExp(x, b = b) - log(length(x), base = b)
}
logVarExp <- function (x, b = exp(1)) {
	#_DOC_
	#Returns the log of the variance of a series of exponential given as log.
	#_ARGUMENTS_
	#x: vector of ln
	#b: logarithm base 
	#_MAIN_
	m = logSumExp(x, b = b)
	x.nrm = x - m
	return(m + log(var(exp(x.nrm)), base = b))
}
logSdExp <- function (x, b = exp(1)) {
	#_DOC_
	#Returns the log of the sd of a series of exponential given as log.
	#_ARGUMENTS_
	#x: vector of ln
	#b: logarithm base 
	#_MAIN_
	m = logSumExp(x, b = b)
	x.nrm = x - m
	return(m + log(sd(exp(x.nrm)), base = b))
}
tr <- function(A){
	#_DOC_
	#Trace of the matrix 'A'
	#_MAIN_
	sum(diag(A))
}
kld <- function (x, dist, brk = seq(0, 1, length.out = floor(sqrt(length(x)))), ...) {
	#_DOC_
	#Kullback–Leibler divergence between the sample x and the distribution dist
	#_ARGUMENTS_
	#x: sample
	#dist: function representing a probability density distribution
	#_MAIN_
	H = hist(x, plot = F, breaks = brk)
	H$counts[H$counts == 0] = .intrf.tol()
	px = H$counts/sum(H$counts)
	qx = diff(dist(H$breaks, ...))
	return(sum(px * (log(px) - log(qx))))
}
kld2 <- function (x, y, brk = seq(0, 1, length.out = floor(sqrt(length(x))))) {
	#_DOC_
	#Kullback–Leibler divergence between the sample x and the distribution dist
	#_ARGUMENTS_
	#x: sample
	#dist: function representing a probability density distribution
	#_MAIN_
	Hx = hist(x, plot = F, breaks = brk)
	Hx$counts[Hx$counts == 0] = .intrf.tol()
	px = Hx$counts/sum(Hx$counts)
	Hy = hist(y, plot = F, breaks = brk)
	Hy$counts[Hy$counts == 0] = .intrf.tol()
	py = Hy$counts/sum(Hy$counts)
	return(sum(py * (log(py) - log(px))))
}
hdi.mcmc <- function(x, p = 0.95, smp = F) {
	#_DOC_
	#Computes highest density interval from a sample of representative values,
	#estimated as shortest credible interval.
	#Reference: Kruschke, J. K. Doing Bayesian Data Analysis: A Tutorial with R and BUGS Academic Press, 2010 
	#_ARGUMENTS_
	#x: is a vector of representative values from a probability distribution.
	#p: is a scalar between 0 and 1, indicating the mass within the credible interval that is to be estimated.
	srt = sort(x)
	d = floor(p * length(srt))
	nci = length(srt) - d
	w = sapply(1:nci, function(i)srt[i + d] - srt[i])
	lw = srt[which.min(w)]
	up = srt[which.min(w) + d]
	if (smp) {
		return(x[x>=lw & x<=up])
	} else {
		ans = c(lw, up)
		names(ans) = c('lower', 'upper')
		return(ans)	
	}
}
pmcmc <- function (x, v, log = F) {
	#_DOC_
	#Returns the probability that x < v
	#_ARGUMENTS_
	#x: sample
	#v: value
	ifelse(log, return(log(length(x[x < v])) - log(length(x))), return(length(x[x < v]) / length(x)))
}
HDIofICDF = function( ICDFname , credMass=0.95 , tol=1e-8 , ... ) {
  # Arguments:
  #   ICDFname is R's name for the inverse cumulative density function
  #     of the distribution.
  #   credMass is the desired mass of the HDI region.
  #   tol is passed to R's optimize function.
  # Return value:
  #   Highest density iterval (HDI) limits in a vector.
  # Example of use: For determining HDI of a beta(30,12) distribution, type
  #   HDIofICDF( qbeta , shape1 = 30 , shape2 = 12 )
  #   Notice that the parameters of the ICDFname must be explicitly named;
  #   e.g., HDIofICDF( qbeta , 30 , 12 ) does not work.
  # Adapted and corrected from Greg Snow's TeachingDemos package.
  incredMass =  1.0 - credMass
  intervalWidth = function( lowTailPr , ICDFname , credMass , ... ) {
    ICDFname( credMass + lowTailPr , ... ) - ICDFname( lowTailPr , ... )
  }
  optInfo = optimize( intervalWidth , c( 0 , incredMass ) , ICDFname=ICDFname ,
                      credMass=credMass , tol=tol , ... )
  HDIlowTailPr = optInfo$minimum
  return( c( ICDFname( HDIlowTailPr , ... ) ,
             ICDFname( credMass + HDIlowTailPr , ... ) ) )
}
