#  This file is part of Calibro.
#
#  Calibro is free software; you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation; either version 2 of the License, or
#  (at your option) any later version.
#  
#  Calibro is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#  
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software
#  Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
#  MA 02110-1301, USA.

#_DOC_
#ADAPTIVE METROPOLIS WITHIN GIBBS ALGORITHM (amg)
#Reference: AMCMC: An R interface for adaptive MCMC Computational Statistics & Data Analysis, Elsevier BV, 2007, 51, 5467-5470 

#* PARAMETERS
#_DOC_
#Parameters needed to run an 'amg' simulation.

.par.default_state.amg = list(	
	#_DOC_
	#List of function returning the default state values.
	#_FIELDS_
	'z' = function (...) ..z.default(...),	#vector of initial parameters					 
	'lnSigmas' = function (...) ..lnSigmas_default.amg(...)	#log-variances for proposal
)

#* AMG CLASS
amg = R6Class('amg',
	#_DOC_
	#Class representing a 'amg' simualtion.
	inherit = amcmc,
	#** private
	private = list(
		#*** attributes
		.state_skel = list('z' = NULL, 'lnSigmas' = NULL),		#state skeleton 
		.default_state = .par.default_state.amg,				#default state values
		#*** methods
		.init_alg = function (...) .prvmthd.init.amg(...),			#initialises the simulation
		.run_alg = function (...) .prvmthd.run.amg(...),			#only run the simulation
		.print_start = function (...) .prvmthd.print_star.amg(...)	#print simulation header at the start
	)
)

#* AUXILIARY FUNCTIONS
..lnSigmas_default.amg <- function (mdl, ...) {
	#_DOC_
	#Returns the default values for the log-variances of the proposal.
	#_ARGUMENTS_
	#mdl: model to simulate
	#...: additional ignored arguments
	#_MAIN_
	sigmas = apply(mdl$pars$exe.mthd('r', n = 1000, exp = T, cp.rm = T, wrap = F, mode = 'sapply'), 2, sd) 
	sigmas[sigmas == 0] = .intrf.env_par__get('tol')
	return(log(sigmas/6))
}
.prvmthd.print_star.amg <- function (start.time, m, n, ...) {
	#_DOC_
	#Prints the starting header.
	#_ARGUMENTS_
	#start.time: start time
	#m: number of chains
	#n: number of simulations
	#_MAIN_
	cat(paste('\n### ADAPTIVE METROPOLIS WITHIN GIBBS ALGORITHM ###\n\n Start time:', start.time, 
			'\n Number of chains:', m, '\n Number of simulations:', n, '\n\n'))
}
.prvmthd.init.amg <- function (i, z, adapt, fp, lnSigmas, nBatches, lBatch, ...) {
	#_DOC_
	#Initialises all the array needed to launch AMG
	#_ARGUMENTS_
	#z: initial input vector
	#adapt: > 0 => adapts the proposal distributions
	#lnSigmas: initial log variances of the proposals
	#nBatches: number of batches
	#lBatch: number of iteration per batch
	#_MAIN_
	#~init MCMC chain parameters
	.intrf.amcmc__set_nlevels(1)
	.intrf.acount__init(matrix(0, length(z), 1))
	.intrf.fp__init(fp)
	.intrf.lnSigmas__init(lnSigmas)
	.intrf.nBatches__init(nBatches)  
	.intrf.lBatch__init(lBatch)  
	.intrf.iter__init(0)
	.intrf.beta__init(1)
	.intrf.amcmc__set_alg(1)
	.intrf.amcmc__set_adapt(adapt)
	#~
	.intrf.amcmc__z_init(z)	#init z
}
.prvmthd.run.amg <- function (mdl, z, nBatches, lnSigmas, ...) {
	#_DOC_
	#Runs a nBathces the 'amg' algorithm.
	#_ARGUMENTS_
	#mdl: model to simulate
	#z: initial parameter values
	#nBathces: number of batch to run
	#lnSigmas: log-variances of the proposal.
	#...: additional ignored arguments
	#_MAIN_
	ANS = .intrf.amg__run(z, nBatches, lnSigmas)
	ANS[['z']] = ANS[['Z']][nrow(ANS[['Z']]),]
	nms = mdl$pars$get.attr('name', exp = T, cp.rm = T, wrap = F, mode = 'sapply')	
	colnames(ANS[['Z']]) = nms
	names(ANS[['z']]) = nms
	names(ANS[['bestz']]) = nms
	return(ANS) 
}

#* INTERFACES TO FORTRAN SUBROUTINES
.intrf.amg__run <- function (z, nBatches, lnSigmas) {
	#_DOC_
	#Runs the AMG algorithm for the current initial input vector, number of bathches and proposal log variances
	#_ARGUMENTS_
	#z: input vector
	#nBatches: number of batches
	#lnSigmas: log proposal variances
	#_MAIN_ 
	ANS = .C('__amg_MOD_intrf_amg__run', 
			'lz' = as.integer(length(z)),
			'Z' = double(length(z)*nBatches),
			'lnpd' = double(nBatches),
			'bestz' = double(length(z)),
			'bestLnpd' = double(1),
			'lnSigmas' = as.double(lnSigmas)
		)
	#~packs results
	ANS[['Z']] = matrix(ANS[['Z']], nrow = nBatches, ncol = length(z))
	ANS[['lz']] = NULL
	return(ANS)	
	#~
}
.intrf.lnSigmas__init <- function (lnSigmas) {
	#_DOC_
	#Initialises the matrix containing the log variances used by the proposal distributions in each level
	#_ARGUMENTS_
	#lnSigmas: matrix containing the intial log variances
	#_MAIN_
	lnSigmas = as.matrix(lnSigmas)
	ANS = .C('__amg_MOD_intrf_lnsigmas__init', 
		'lz' = as.integer(nrow(lnSigmas)), 
		'nLevels' = as.integer(ncol(lnSigmas)), 
		'lnSigmas' = as.double(lnSigmas)
	)
}
.intrf.acount__init <- function (acount) {
	#_DOC_
	#Initialises the acount vector, which stores the number of accepted moves for each direction
	#_ARGUMENTS_
	#acount: vector of initial values
	#EXCUTION
	acount = as.matrix(acount)
	ANS = .C('__amg_MOD_intrf_acount__init', 
		'lz' = as.integer(nrow(acount)), 
		'nLevels' = as.integer(ncol(acount)), 
		'acount' = as.integer(acount)
	)
}
.intrf.lnSigmas__dim <- function () {
	#_DOC_
	#Retreives the dimension of the array used to store the log-variances of the proposal.
	#_MAIN_
	ANS = .C('__amg_MOD_intrf_lnsigmas__dim', m = integer(1), n = integer(1))
	return(c(ANS[['m']], ANS[['n']]))
}
.intrf.lnSigmas__get <-function () {
	#_DOC_
	#Retreives the array used to store the log-variances of the proposal.
	#_MAIN_
	dm = .intrf.lnSigmas__dim()
	ANS = .C('__amg_MOD_intrf_lnsigmas__get', S = double(prod(dm)), as.integer(dm[1]), as.integer(dm[2]))
	return(matrix(ANS[['S']], nrow = dm[1], ncol = dm[2]))
}
