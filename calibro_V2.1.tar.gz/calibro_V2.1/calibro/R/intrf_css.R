#  This file is part of Calibro.
#
#  Calibro is free software; you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation; either version 2 of the License, or
#  (at your option) any later version.
#  
#  Calibro is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#  
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software
#  Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
#  MA 02110-1301, USA.

#_DOC_
#Covariance structures.

#* INTERFACES TO FORTRAN SUBROUTINE

.intrf.CS__id <- function (csname) {
	#_DOC_
	#Returns the identifier of kind of covariance strcuture in the Fortran environment.
	#_ARGUMENTS_
	#csname: class name
	#_MAIN_
	.C(paste0('__intrf_css_MOD_intrf_', csname, '__id'), integer(1))[[1]]
}
.intrf.MOULD__allocate <- function (csId, ncs) {
	#_DOC_
	#Allocates the the number of MOULDS for the covarance strctures indicated by csId
	#_MAIN_
	ANS = .C('__intrf_css_MOD_intrf_mould__allocate',
		'csId' = as.integer(csId),
		'ncs' = as.integer(ncs)
	)
}
.intrf.MOULD__init <- function (i, csId, MOULD) {
	#_DOC_
	#Initialises the MOULD for the ith covariance structures identified by csId
	#_MAIN_
	ANS = .C('__intrf_css_MOD_intrf_mould__init',
		'i' = as.integer(i),
		'csId' = as.integer(csId),
		'm' = as.integer(nrow(MOULD)),
		'n' = as.integer(ncol(MOULD)),
		'MOULD' = as.integer(MOULD)
	)
}
#** CS ALLOCATION AND INITIALISATION
.intrf.CS__allocate <- function (csId, ncs) {
	#_DOC_
	#Allocates the slots containing the CSs
	#_ARGUMENTS_
	#csId: identifier of the kind of covariance structure in the Fortran environment
	#ncs: number of CS (models) to allocate
	#_MAIN_
	ANS = .C('__intrf_css_MOD_intrf_cs__allocate', 
		'csId' = as.integer(csId), 
		'n' = as.integer(ncs)
	)
	if (csId %in% c(4, 5, 6)) {
		.intrf.H__allocate(ncs)
	}	
}
.intrf.CS__allocateMMi <- function (i, csId, nkrn) {
	#_DOC_
	#Allocate the matrix of matrices representing one CS
	#_ARGUMENTS_
	#i: CS index
	#csId: CS indentifier (1 = CS11, 2 = CS12, 3 = CS22)
	#nkrn: nuber of matrices (representing kernels) to allocate
	#_MAIN_
	ANS = .C('__intrf_css_MOD_intrf_cs__allocatemmi',
		'i' = as.integer(i),
		'csId' = as.integer(csId),
		'nkrn' = as.integer(nkrn)
	)
}
.intrf.CS__allocateMVi <- function (i, j, csId) {
	#_DOC_
	#Allocates 5 slots (one for each kernel attribute) for the jth kernel in the ith CS
	#_ARGUMENTS_
	#i: CS index
	#j: kernel index
	#csId: CS identifier (1 = CS11, 2 = CS12, 3 = CS22)
	#_MAIN_
	ANS = .C('__intrf_css_MOD_intrf_cs__allocatemvi',
		'i' = as.integer(i),
		'j' = as.integer(j),
		'csId' = as.integer(csId)
	)
}
.intrf.CS__set_krnAttr <- function (i, j, k, csId, attr) {
	#_DOC_
	#Sets a certain kernal attribute
	#_ARGUMENTS_
	#i: CS index
	#j: kernel index
	#k: attribute index
	#attr: attribute
	#_MAIN_
	ANS = .C('__intrf_css_MOD_intrf_cs__set_krnattr',
		'i' = as.integer(i),
		'j' = as.integer(j),
		'k' = as.integer(k),
		'csId' = as.integer(csId),
		'm' = as.integer(nrow(attr)),
		'n' = as.integer(ncol(attr)),
		'attr' = as.integer(attr)
	)
}
#** CM ALLOCATION AND INITIALISATION
.intrf.CM__allocate <- function (cmId, n) {
	#_DOC_
	#Allocates the slots for storing covariance matrices
	#_ARGUMENTS_
	#cmId: CM identifier (1 = CM11, 2 = CM12, 3 = CM22)
	#n: number of CM (number of CS or models)
	#_MAIN_
	ANS = .C('__intrf_css_MOD_intrf_cm__allocate', 
		'csId' = as.integer(cmId),
		'n' = as.integer(n)
	)
}
.intrf.CM__init <- function (i, cmId, CM) {
	#_DOC_
	#Initialises a certain covariance matrix to CM
	#_ARGUMENTS_
	#i: CM index
	#cmId: CM indentifier
	#CM: initial covariance matrix
	#_MAIN_
	ANS = .C('__intrf_css_MOD_intrf_cm__init',
		'i' = as.integer(i),
		'cmId' = as.integer(cmId),
		'm' = as.integer(nrow(CM)),
		'n' = as.integer(ncol(CM)),
		'CM' = as.double(CM)
	)
}
.intrf.flCM11inv__set <- function (x) {
	#_DOC_
	#Set the flag flCM11inv. if > 0 it inverts CM11 after calculation.
	#_ARGUMENTS_
	#x: value
	#_MAIN_
	ANS = .C('__intrf_css_MOD_intrf_flcm11inv__set',
		'x' = as.integer(x)
	)
}
#** Z ALLOCATION AND INITIALISATION
.intrf.Z__id <- function (z) {
	#_DOC_
	#Returns the idenfiers of the kind of input matris in the Fortran environemnt.
	#_ARGUMENTS_
	#z: name of the input matrix
	#_MAIN_
	.C(paste0('__intrf_css_MOD_intrf_', z, '__id'), integer(1))[[1]]
}
.intrf.Z__allocate <- function (zId, n) {
	#_DOC_
	#Allocates the slots for storing the list of input matrices
	#_ARGUMENTS_
	#zId: Z indentifier
	#n: number of matrices (number of CSs/models)
	#_MAIN_
	ANS = .C('__intrf_css_MOD_intrf_z__allocate',
		'zId' = as.integer(zId),
		'n' = as.integer(n)
	)
}
.intrf.Z__allocateMVi <- function (i, zId, n) {
	#_DOC_
	#Allocates the slots for storing the input matrices for the ith model
	#_ARGUMENTS_
	#i: model index
	#zId: input matrix identifier (1 = Z1, 2 = Z2)
	#n: number of input matrices
	#_MAIN_
	ANS = .C('__intrf_css_MOD_intrf_z__allocatemvi',
		'i' = as.integer(i),
		'zId' = as.integer(zId),
		'n' = as.integer(n)
	)
}
.intrf.Z__init <- function (i, j, zId, Z) {
	#_DOC_
	#Initialises jth input matrix of the ith model to the matrix Z
	#_ARGUMENTS_
	#i: model index
	#j: Z index
	#Z: matrix of value to initialise
	#_MAIN_
	ANS = .C('__intrf_css_MOD_intrf_z__init',
		'i' = as.integer(i),
		'j' = as.integer(j),
		'zId' = as.integer(zId),
		'm' = as.integer(nrow(Z)),
		'n' = as.integer(ncol(Z)),
		'Z' = as.double(Z)
	)
}

#* CS EVALUATION
.intrf.CS__evlCm <- function (csId, i, hp) {
	#_DOC_
	#Evaluates the ith CS
	#_ARGUMENTS_
	#i: CS index
	#csId: CS indentifier 
	#hp: hyper parameters values
	#_MAIN_
	ANS = .C('__intrf_css_MOD_intrf_cs__evlcm',
		'csId' = as.integer(csId),
		'i' = as.integer(i),
		'Lhp' = as.integer(length(hp)),
		'hp' = as.double(hp)
	)
}
.intrf.CM__dim <- function (cmi, cmId) {
	#_DOC_
	#Returns the dimension of the ith calculated covariance matrix
	#_ARGUMENTS_
	#cmi: CM index
	#cmId: CM identifier
	#_MAIN_
	ANS = .C('__intrf_css_MOD_intrf_cm__dim',
		'm' = as.integer(1),
		'n' = as.integer(1),
		'gpri' = as.integer(cmi),
		'cmId' = as.integer(cmId)
	)
	return(c(ANS[['m']], ANS[['n']]))
}
.intrf.CM__get <- function (cmi, cmId) {
	#_DOC_
	#Rreturns the ith CM
	#_ARGUMENTS_
	#cmi: CM index
	#cmId: CM identifier
	#_MAIN_
	CM.dim = .intrf.CM__dim(cmi, cmId)
	ANS = .C('__intrf_css_MOD_intrf_cm__get',
		'CM' = double(prod(CM.dim)),
		'm' = as.integer(CM.dim[1]),
		'n' = as.integer(CM.dim[2]),
		'gpri' = as.integer(cmi),
		'cmId' = as.integer(cmId)
	)
	CM = ANS[['CM']]
	dim(CM) = CM.dim
	return(CM)
}
