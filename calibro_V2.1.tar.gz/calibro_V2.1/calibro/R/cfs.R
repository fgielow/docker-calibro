#KERNEL AND COVARIANCE FUNCTIONS

#  This file is part of Calibro.
#
#  Calibro is free software; you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation; either version 2 of the License, or
#  (at your option) any later version.
#  
#  Calibro is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#  
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software
#  Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
#  MA 02110-1301, USA.

#* PARAMETERS
.LNKHP = c('%RHO%', '%PHI%', '%GAMMA')
.UNLNKHP = c('%ALPHA%', '%SIGMA%')

#* KERNEL CLASS
krn <- R6Class('kernel',
	#_DOC_
	#Class representing a kernel (linear combination of covariance functions).
	inherit = r6.list,
	#** public
	public = list(
		#*** methods
		#**** initialize
		initialize = function (name, cfs) {
			#_DOC_
			#Creates a new kernel object.
			#_ARGUMENTS_
			#name: kernel name
			#cfs: list of covariance functions 
			#_MAIN_
			super$initialize(name = paste0(name, '{k}'), objs = cfs, cl = 'cf')
		},
		#**** bld
		bld =  function (p.nms) .mthd.bld.krn(self, p.nms),
		#**** cnd
		cnd = function (rplCfs = NULL, appCfs = NULL, nl = 2) {
			#_DOC_
			#Creates a conditional kernel (same off diagonal covariance function but possibly different diagonal ones).
			#It is possible to condition only using diagonal convariance functions.
			#_ARGUMENTS_
			#rplCfs: named list having the names of the covariance functions to replace and as element the respective replacements.
			#appCfs: list containing the covariance function to append
			.mthd.cnd.krn(self, rplCfs, appCfs, nl)
		},
		evl = function (x1, x2, i = 1, j = 2) {
			#_DOC_
			#Evaluates the kernel at the points x1, and x2
			#_ARGUMENTS_
			#x1, x2: points at which to evaluate the kernel.
			#i, j: if equal the point is the same 
			.mthd.evl.krn(self, x1, x2, i, j)
		},
		print = function () {
			#_DOC_
			#Print method for the kernal class
			.mthd.print.krn(self)
		},
		.pars.mapping = function (pars) {
			#_DOC_
			#Maps the kernel parameters to the model parameters
			#_ARGUMENTS_
			#pars: model paramters
			#_MAIN_
			.pars.mapping.krn(self, pars)
		},
		.fortPars = function () {
			#_DOC_
			#Returns the list of parameters for representing the kernel in the Fortran environment.
			#_MAIN_
			.fortPars.krn(self)
		},
		.nhp = function () {
			#_DOC_
			#Returns the number of hyper parameters in the kernel
			#_MAIN_
			.nhp.krn(self)
		}
	),
	#** active
	active = list(
		#*** hp
		hp = function (x) {
			#_DOC_
			#Returns the hp of the kernel
			#_MAIN_
			if (missing(x)) {.actmthd.get_hp.krn(self)} else {}
		},
		maps = function (vals) {
			#_DOC_
			#Returns or sets the MAP values of the hyper parameters
			#_ARGUMENTS_
			#vals: MAP values
			#_MAIN_
			if (missing(vals)) {
				..get_maps.hp(self)
			} else {
				.actmthd.wrp(self, vals, ..set_maps.hp)
			}
		},
		diag = function (d) {
			#_DOC_
			#Sets returns the 
			if (missing(d)) {
				return(private$.diag)
			} else {
				if (is.null(private$.diag)) {
#					self$.set.private('.diag', val = d)
					private$.diag = d
				}
			}
		} 
	),
	private = list(
		.diag = NULL
	)
)

#**	METHODS FOR KERNEL CLASS
#Function called directly by methods of the class.
#In the following 'k' indicates a kernel class object.
.mthd.bld.krn <- function (k, p.nms) {
	#_DOC_
	#Builds the covariance functions with the kernel
	#_ARGUMENTS_
	#p.nms: names of the parameters associated with the hyper parameters of the covariance function
	#_MAIN_
	k$exe.mthd('bld', p.nms = p.nms)
}
.mthd.cnd.krn <- function (k, rplCfs, appCfs, nl) {
	#_DOC_
	#Creates a kernel conditional to k.
	#Only diagonal covariance function can be used.
	#_ARGUMENTS_
	#rplCfs: named list having as names the names of the cfs to replace and as element the replacing functions.
	#appCfs: covariance functions to append to the kernel
	#_MAIN_
	kcnd = k$clone(deep = FALSE)
	if (is.null(rplCfs) && is.null(appCfs)) {
		return(kcnd)
	} else {
		if (!is.null(rplCfs)) {
			d = which(k$get.attr('is.diag', exp = T, cp.rm = T, wrap = F, mode = 'sapply'))
			if (length(d) == 0) {
				warning(paste('kernel', k$name, 'does not contain diagonal functions. No modification made.'))
			} else if (is(rplCfs, 'character')) {
					if (rplCfs == 'diag0') {
						kcnd$pop(d)
					} else {
						stop(paste('unknown rplCfs:', replCfs))
					}
			} else if (!(all(sapply(rplCfs, function(x)x$is.diag)))) {
				stop('you are trying to condition with non-diagonal covariance functions')
			} else {
				kcnd$replace(rplCfs, nl)
			}
		}
		if (!is.null(appCfs)) {
			if (!(all(sapply(appCfs, function(x)x$is.diag)))) stop('you are trying to condition with non-diagonal covariance functions')
			kcnd$append(appCfs$list)
		}
		return(kcnd)
	}
}
.mthd.evl.krn <- function (k, x1, x2, i = 1, j = 2) {
	#_DOC_
	#Evaluates the kernel according to two ginve model input vectors.
	#_ARGUMENTS_
	#x1, x2: points
	#i, j: indexes of the points (row and column of the covariance matrix - important only if they are the same => only diag cf are calculated))
	#_MAIN_
	if (length(x1) != length(x2)) stop('x1 and x2 have different lengths.')
	hp = k$hp$exe.mthd('r', n = 1, exp = T, cp.rm = T, wrap = F, mode = 'sapply')
	.intrf.krn__evl(x1, x2, hp, k$.fortPars(), i, j)
}
.mthd.print.krn <- function (k) {
	#_DOC_
	#prints a human friendly version of the kernel
	#_MAIN_
	strs = list()
	for (i in 1:length(k$list)) {
		strs[[i]] = paste0(k$list[[i]]$.get.private('.symb'), '(.)')
	}
	cat(paste0('\t', k$name, ' = ', paste(strs, collapse = ' + ')))
	cat('\n')
}
.pars.mapping.krn <- function (k, pars) {
	#_DOC_
	#Maps the kernel parameters with respect ot the model parameters.
	#_ARGUMENTS_
	#pars: model parameters
	#_MAIN_
	return(as.matrix(pars.mapping(k$hp$expand(cp.rm = F), pars)))
}
.fortPars.krn <- function (k) {
	#_DOC_
	#Returns a list of the arguments needed to initialise Fortran subroutines
	#_MAIN_
	fortpars = list()
	fortpars[['cfs']] = as.matrix(k$exe.mthd('.id', wrap = F, cp.rm = F, exp = T, mode = 'sapply'))
	fortpars[['hpMapp']] = k$.pars.mapping(k$hp$expand(cp.rm = T))
	fortpars[['nhp']] = k$.nhp()
	return(fortpars)
}
.nhp.krn <- function (K) {
	#_DOC_
	#Returns the number of hyper parameters for each covariance function.
	#_MAIN_
	as.matrix(K$exe.mthd('.nhp', exp = T, cp.rm = T, wrap = F, mode = 'sapply'))
}
.actmthd.get_hp.krn <- function (K) {
	#_DOC_
	#Returns an r6.list conotaining the hp of the cfs making the krn.
	#_MAIN_
	return(K$get.attr('hp', exp = T, mode = 'lapply', cp.rm = F, wrap = T, cl = 'uvrv'))
}
..get_maps.hp <- function (K) {
	#_DOC_
	#Retuirns the MAP values of the hyper parameters fo the kernel.
	#_MAIN_
	K$hp$get.attr('map', exp = T, cp.rm = T, mode = 'sapply')
}
..set_maps.hp <- function (K, vals) {
	#_DOC_
	#Sets the MAP values of the kernel hyper parameters.
	#_MAIN_
	K$hp$set.attr('map', val = vals, exp = T, all = F)
	invisible()
}

#* COVARIANCE FUNCTIONS

#** ROOT COVARIANCE FUNCTION CLASS
.cf <- R6Class('cf',
	#_DOC_
	#All the covariance function classes that follow inherit from this one.
	inherit = calibro.obj,
	#*** public
	public = list(
		#**** methods
		bld = function (p.nms) .mthd.bld_hp.cf(self, p.nms),
		#***** evl
		evl = function (x1, x2, i = 1, j = 2) {
			#_DOC_
			#Evaluates the covariance function
			#_ARGUMENTS_
			#x1, x2: points to wich evaluate the function
			#_MAIN_
			.mthd.evl.cf(self, x1, x2, i, j)
		},
		print = function () {
			#_DOC_
			#Print method
			#_MAIN_
			.mthd.print.cf(self)
		},
		.nhp = function() {
			#_DOC_
			#Return the number of hyper paramters in the function.
			#_MAIN_
			return(length(self$hp$expand(cp.rm = T)))
		},
		.id = function () {
			#_DOC_
			#Returns the id number of the function indicating its position in the COVFNS array in the Fortran environment
			#_MAIN_ 
			.intrf.cf__id(class(self)[1])
		}
	),
	#*** active
	active = list(
		hp = function (x) {
			#_DOC_
			#Returns the hyper parameters.
			#_MAIN_
			if (missing(x)) {return(private$.hp)} else {}
		},
		hp.nst = function (x) {
			#_DOC_
			#return the nested hyper parameters only.
			#_MAIN_
			if (missing(x)) {.actmthd.get_hpNst.cf(self)} else {}
		},
		maps = function (val) {
			#_DOC_
			#Returns or sets the MAP values of the hyper parameters.
			#_ARGUMENTS_
			#val: MAP values.
			#_MAIN_
			if (missing(val)) {
				..get_maps.hp(self)
			} else {
				..set_maps.hp(self, val)
			}
		},
		is.diag = function (x) {
			#_DOC_
			#Return T if the covariance function is diagonal or F in the opposite case.
			#_MAIN_
			if (missing(x)) {return(private$.diag)} else {}
		}
	),
	#*** private
	private = list(
		#**** attributes
		.symb = NULL, 	#simbol to print to screen representing the covariance function
		.hp = NULL,		#hyper parameters
		.diag = NULL	#logical flag indicating if a cf id 'diagonal'
	)
)
	
#*** METHODS FOR ROOT COVARIANCE FUNCTION CLASS
#In the following C indicates a covariance function class object.
.mthd.evl.cf <- function (C, x1, x2, i, j) {
	#_DOC_
	#Evaluates the covariance function.
	#_ARGUMENTS_
	#x1, x2: input vectors
	#_MAIN_
	if (length(x1) != length(x2)) stop('x1 and x2 have different lengths.')
	hp = C$hp$exe.mthd('r', n = 1, exp = T, wrap = F, cp.rm = F, mode = 'sapply')
	return(.intrf.cf__evl(which = C$.id(), x1 = x1, x2 = x2, hp = hp, i = i, j = j)) 
}
.mthd.print.cf <- function (C) {
	#_DOC_
	#Prints a character representation of the covariance function object.
	#_MAIN_
	cat(paste0(C$.get.private('.symb'), '(.)\n'))
}
.actmthd.get_hpNst.cf <- function (C) {
	#_DOC_
	#Returns the hp nested in the hp of the function.
	#_MAIN_
	hp.nst = C$hp$exe.mthd('get.uvrv.pars', exp = T, wrap = F, cp.rm = T, mode = 'lapply')
	hp.nst = unlist(list.null.rm(hp.nst))
	if (length(hp.nst) > 0) {
		return(r6.list$new(name = NULL, objs = hp.nst, cl = 'uvrv'))
	} else {
		return(NULL)
	}
}

#* CONSTANT COVARIANCE CLASS
cf.const = R6Class('const',
	#_DOC_
	#It gives the same value to all the entries of the covariance matrix.
	inherit = .cf,
	#** public
	public = list(
		#*** methods
		initialize = function (name, k) {
			#_DOC_
			#Initialisation method
			#_ARGUMENTS_
			#name: name/description (short) the covariance function
			#k: constant 
			#_MAIN_
			k = r6.list$new(name = paste0('%KAPPA@', name, '%'), objs = list(k), cl = 'uvrv')
			private$.hp = r6.list$new(objs = list('%KAPPA%' = k), cl = 'uvrv')
			self$name = name
		}
	),
	#** private
	private = list(
		#*** attributes
		.diag = FALSE,
		.symb = 'Const'
	)
)

#* WHITE COVARIANCE CLASS
cf.white = R6Class('white',
	#_DOC_
	#It gives the same value (v) to all the diagonal entries of the covariance matrix. 
	#Off-diagonal elements are 0.
	inherit = .cf,
	#** public
	public = list(
		#*** methods
		#**** initialize
		initialize = function (name, v) {
			#_DOC_
			#Initialisation method
			#_ARGUMENTS_
			#name: name describing the covariance function
			#v: variance value 
			#_MAIN_
			v = r6.list$new(name = paste0('%SIGMA@', name, '%'), objs = list(v), cl = 'uvrv')
			private$.hp = r6.list$new(objs = list('%SIGMA%' = v), cl = 'uvrv')
			self$name = name
		}
	),
	private = list(
		.diag = TRUE,
		.symb = 'White'
	)
)

#* PARAMETRISED WHITE COVARIANCE CLASS
cf.whitePar = R6Class('whitepar',
	#_DOC_
	#It attributes to the diagonal elements of the covariance matrix 1/lam (lam is the precision). 
	#Off-diagonal elements are 0.
	inherit = .cf,
	#** public
	public = list(
		#*** methods
		#**** initialize
		initialize = function (name, lam) {
			#_DOC_
			#Initialisation method
			#_ARGUMENTS_
			#name: name describing the covariance function
			#lam: precision value 
			#_MAIN_
			lam = r6.list$new(name = paste0('%SIGMA@', name, '%'), objs = list(lam), cl = 'uvrv')
			private$.hp = r6.list$new(objs = list('%SIGMA%' = lam), cl = 'uvrv')
			self$name = name
		}
	),
	#** private
	private = list(
		#*** attributes
		.diag = TRUE,
		.symb = 'Whitepar'
	)
)

#* PARAMETRISED WHITE COVARIANCE CLASS WITHIN [0,1]
cf.whitePar01 = R6Class('whitepar01',
	#_DOC_
	#The same as 'whitePar' but the precision lam is parameterized so to vary within [0, 1].
	inherit = .cf,
	#** public
	public = list(
		#*** methods
		#**** initialize
		initialize = function (name, lam) {
			#_DOC_
			#Initialisation method
			#_ARGUMENTS_
			#name: name describing the covariance function
			#lam: precision value 
			#_MAIN_
			lam = r6.list$new(name = paste0('%SIGMA@', name, '%'), objs = list(lam), cl = 'uvrv')
			private$.hp = r6.list$new(objs = list('%SIGMA%' = lam), cl = 'uvrv')
			self$name = name
		}#,
		#.nhp = function(z) return(1)
	),
	#** private
	private = list(
		#*** attributes
		.diag = TRUE,
		.symb = 'Whitepar01'
	)
)

#* DIAGONAL COVARIANCE CLASS
cf.dgn = R6Class('dgn',
	#_DOC_
	#Attributes potentially a different value to each intry of the diagonal of the covariance matrix.
	#Off-diagonal terms are 0.
	inherit = .cf,
	#** public
	public = list(
		#*** methods
		#**** initialize
		initialize = function (name, v) {
			#_DOC_
			#Initialisation method
			#_ARGUMENTS_
			#name: name describing the covariance function
			#v: a list of uvrv obects representing the entry of the diagonal
			#_MAIN_
			v = r6.list$new(name = paste0('%SIGMA@', name, '%'), objs = v, cl = 'uvrv')
			private$.hp = r6.list$new(objs = list('%SIGMA%' = v), cl = 'uvrv')
			self$name = name
		}
	),
	#** private
	private = list(
		#*** attributes
		.diag = TRUE,
		.symb = 'dgn'
	)
)

#* SQUARED EXPONENTIAL COVARIANCE CLASS
cf.se = R6Class('se',
	#_DOC_
	#CM_{i,j} = a * exp(-b * (x_i - x_j)^2)
	#Reference: Rasmussen C & Williams, C. Gaussian Process for Machine Learning. The MIT Press, 2006
	inherit = .cf,
	#** public
	public = list(
		#*** methods
		#**** initialize
		initialize = function (name, b, a) {
			#_DOC_
			#Initialisation method
			#_ARGUMENTS_
			#name: describing the covariance function
			#a: amplitude parameter
			#b: rate parameters
			#_MAIN_
			b = r6.list$new(name = paste0('%RHO@', name, '%'), objs = b, cl = 'uvrv')
			a = r6.list$new(name = paste0('%ALPHA@', name, '%'), objs = list(a), cl = 'uvrv')
			private$.hp = r6.list$new(objs = list('%RHO%' = b, '%ALPHA%' = a), cl = 'uvrv')
			self$name = name
		}
	),
	#** private
	private = list(
		#*** attributes
		.diag = FALSE,
		.symb = 'SE'
	)
)

#* PARAMETRISED SQUARED EXPONENTIAL COVARIANCE CLASS
cf.sePar = R6Class('separ',
	#_DOC_
	#CM_{i,j} = tau^-1 * rho*(4 * (x_i - x_j)**2) 
	#where the parameter rho is within [0, 1].
	#Reference to: Higdon D, Kennedy M, Cavendish J C, Cafeo J A & Ryne R D. 
	#Combining Field Data and Computer Simulations for Calibration and Prediction. 
	#SIAM Journal on Scientific Computing, Society for Industrial and Applied Mathematics, 2004, 26, 448-466
	inherit = .cf,
	#** public
	public = list(
		#*** methods
		#**** initialize
		initialize = function (name, l, s) {
			#_DOC_
			#Initialisation method
			#_ARGUMENTS_
			#name: describing the covariance function
			#s: inverse amplitude parameter
			#l: correlation parameters
			#_MAIN_
			l = r6.list$new(name = paste0('%RHO@', name, '%'), objs = l, cl = 'uvrv')
			s = r6.list$new(name = paste0('%ALPHA@', name, '%'), objs = list(s), cl = 'uvrv')
			private$.hp = r6.list$new(objs = list('%RHO%' = l, '%ALPHA%' = s), cl = 'uvrv')
			self$name = name
		}
	),
	#** private
	private = list(
		#*** attributes
		.diag = FALSE,
		.symb = 'SE*'
	)
) 

#* PARAMETRISED SQUARED EXPONENTIAL BETWEEN [0,1]
cf.sePar01 = R6Class('separ01',
	#_DOC_
	#Same as 'sePar', but also the parameter tau is parametrised so as to be within [0, 1].
	inherit = .cf,
	#** public
	public = list(
		#*** methods
		#**** initialize
		initialize = function (name, l, s) {
			#_DOC_
			#Initialisation method
			#_ARGUMENTS_
			#name: describing the covariance function
			#s: inverse amplitude parameter
			#l: correlation parameters
			#_MAIN_
			l = r6.list$new(name = paste0('%RHO@', name, '%'), objs = l, cl = 'uvrv')
			s = r6.list$new(name = paste0('%ALPHA@', name, '%'), objs = list(s), cl = 'uvrv')
			private$.hp = r6.list$new(objs = list('%RHO%' = l, '%ALPHA%' = s), cl = 'uvrv')
			self$name = name
		}
	),
	#** private
	private = list(
		#*** attributes
		.diag = FALSE,
		.symb = 'sePar01'
	)
)

#* GAMMA EXPONENTIAL COVARIANCE CLASS
cf.ge = R6Class('ge',
	#_DOC_
	#CM_{i,j} = a * exp(-b * |x_i - x_j|^g)
	#Reference: Rasmussen, C. & Williams, C.. Gaussian Process for Machine Learning. The MIT Press, 2006
	inherit = .cf,
	#** public
	public = list(
		#*** methods
		#**** initialize
		initialize = function (name, b, a, g) {
			b = r6.list$new(name = paste0('%RHO@', name, '%'), objs = b, cl = 'uvrv')
			g = r6.list$new(name = paste0('%GAMMA@', name, '%'), objs = g, cl = 'uvrv')
			a = r6.list$new(name = paste0('%ALPHA@', name, '%'), objs = list(a), cl = 'uvrv')
			private$.hp = r6.list$new(objs = list('%RHO%' = b, '%GAMMA%' = g, '%ALPHA%' = a), cl = 'uvrv')
			self$name = name
		}#,
		#.nhp = function(z) return(1 + 2 * length(z))
	),
	#** private
	private = list(
		#*** attributes
		.diag = FALSE,
		.symb = 'GE'
	)
)

#* MATERN 1,2 COVARIANCE CLASS
cf.matern12 = R6Class('matern12',
	#_DOC_
	#CM_{i,j} = a * exp(-b * |x_i - x_j|)
	#Reference: Rasmussen, C. & Williams, C.. Gaussian Process for Machine Learning. The MIT Press, 2006
	inherit = .cf,
	#** public
	public = list(
		#*** methods
		#**** initialize
		initialize = function (name, b, a) {
			#_DOC_
			#Initialisation.
			#Argumants:
			#b: rate parameters
			#a: amplitude parameters
			#_MAIN_
			b = r6.list$new(name = paste0('%RHO@', name, '%'), objs = b, cl = 'uvrv')
			a = r6.list$new(name = paste0('%ALPHA@', name, '%'), objs = list(a), cl = 'uvrv')
			private$.hp = r6.list$new(objs = list('%RHO%' = b, '%ALPHA%' = a), cl = 'uvrv')
			self$name = name
		}
	),
	#** private
	private = list(
		#*** attributes
		.diag = FALSE,
		.symb = 'Matern12'
	)
)

#* MATERN 3,2 COVARIANCE CLASS
cf.matern32 = R6Class('matern32',
	#_DOC_
	#Reference: Rasmussen, C. & Williams, C.. Gaussian Process for Machine Learning. The MIT Press, 2006
	inherit = .cf,
	#** public
	public = list(
		#*** methods
		#**** initialize
		initialize = function (name, a, b) {
			b = r6.list$new(name = paste0('%RHO@', name, '%'), objs = b, cl = 'uvrv')
			a = r6.list$new(name = paste0('%ALPHA@', name, '%'), objs = list(a), cl = 'uvrv')
			private$.hp = r6.list$new(objs = list('%RHO%' = b, '%ALPHA%' = a), cl = 'uvrv')
			self$name = name
		}
	),
	#** private
	private = list(
		#*** attributes
		.diag = FALSE,
		.symb = 'Matern32'
	)
)

#* MATERN 5,2 COVARIANCE FUNCTION
cf.matern52 = R6Class('matern52',
	#_DOC_
	#Reference: Rasmussen, C. & Williams, C.. Gaussian Process for Machine Learning. The MIT Press, 2006
	inherit = .cf,
	public = list(
		initialize = function (name, a, b) {
			b = r6.list$new(name = paste0('%RHO@', name, '%'), objs = b, cl = 'uvrv')
			a = r6.list$new(name = paste0('%ALPHA@', name, '%'), objs = list(a), cl = 'uvrv')
			private$.hp = r6.list$new(objs = list('%RHO%' = b, '%ALPHA%' = a), cl = 'uvrv')
			self$name = name
		}
	),
	private = list(
		.diag = FALSE,
		.symb = 'Matern52'
	)
)

#* GAUSSIAN AUTOCOVARIANCE FUNCTION
cf.autoGauss = R6Class('autogauss',
	#_DOC_
	#Reference: Boyle, P. & Frean, M. Dependent Gaussian processes In Advances in Neural Information Processing Systems 17, MIT Press, 2005, 217-224 
	inherit = .cf,
	public = list(
		initialize = function (name, b, a) {
			b = r6.list$new(name = paste0('%RHO@', name, '%'), objs = b, cl = 'uvrv')
			a = r6.list$new(name = paste0('%ALPHA@', name, '%'), objs = list(a), cl = 'uvrv')
			private$.hp = r6.list$new(objs = list('%RHO%' = b, '%ALPHA%' = a), cl = 'uvrv')
			self$name = name
		}
	),
	private = list(
		.diag = FALSE,
		.symb = 'AG'
	)
)

#* GAUSSIAN CROSS-COVARIANCE CLASS
cf.crossGauss = R6Class('crossgauss',
	#_DOC_
	#Reference: Boyle, P. & Frean, M. Dependent Gaussian processes In Advances in Neural Information Processing Systems 17, MIT Press, 2005, 217-224 
	inherit = .cf,
	public = list(
		initialize = function (name, b1, b2, mu, a1, a2) {
			b1 = r6.list$new(name = paste0('%RHO@', name, '%'), objs = b1, cl = 'uvrv')
			a1 = r6.list$new(name = paste0('%ALPHA@', name, '%'), objs = list(a1), cl = 'uvrv')
			b2 = r6.list$new(name = paste0('%RHO@', name, '%'), objs = b2, cl = 'uvrv')
			a1 = r6.list$new(name = paste0('%ALPHA@', name, '%'), objs = list(a2), cl = 'uvrv')
			mu = r6.list$new(name = paste0('%MU@', name, '%'), objs = mu, cl = 'uvrv')
			private$.hp = r6.list$new(objs= list('%RHO%1' = b1, '%RHO%2'= b2, '%MU%' = mu, '%ALPHA%1' = a1, '%ALPHA%2' = a2), cl = 'uvrv')
			self$name = name
		}
	),
	private = list(
		.diag = FALSE,
		.symb = 'CG'
	)
)

#* PERIODIC COVARIANCE FUNCTION CLASS
cf.periodic = R6Class('periodic',
	#_DOC_
	#Reference: Rasmussen, C. & Williams, C.. Gaussian Process for Machine Learning. The MIT Press, 2006	
	inherit = .cf,
	public = list(
		initialize = function (name, b, f, a) {
			b = r6.list$new(name = paste0('%RHO@', name, '%'), objs = b, cl = 'uvrv')
			f = r6.list$new(name = paste0('%PHI@', name, '%'), objs = f, cl = 'uvrv')
			a = r6.list$new(name = paste0('%ALPHA@', name, '%'), objs = list(a), cl = 'uvrv')
			private$.hp = r6.list$new(objs = list('%RHO%' = b, '%PHI%' = f, '%ALPHA%' = a), cl = 'uvrv')
			self$name = name
		}
	),
	private = list(
		.diag = FALSE,
		.symb = 'Periodic'
	)
)

#* SPECTRAL MIXTURE COVARIANCE CLASS
cf.sm  =R6Class('sm',
	#_DOC_
	#Reference: Wilson, A. G. & Adams, R. P. Gaussian Process Kernels for Pattern Discovery and Extrapolation International 
	#Conference on Machine Learning (ICML), JMLR W&CP, 2013, 28, 1067-1075
	inherit = .cf,
	public = list(
		initialize = function (name, b, f, a) {
			b = r6.list$new(name = paste0('%RHO@', name, '%'), objs = b, cl = 'uvrv')
			f = r6.list$new(name = paste0('%PHI@', name, '%'), objs = f, cl = 'uvrv')
			a = r6.list$new(name = paste0('%ALPHA@', name, '%'), objs = list(a), cl = 'uvrv')
			private$.hp = r6.list$new(objs = list('%RHO%' = b, '%PHI%' = f, '%ALPHA%' = a), cl = 'uvrv')
			self$name = name
		}
	),
	private = list(
		.diag = FALSE,
		.symb = 'SM'			
	)
)

#* METHODS FOR COVARIANCE FUNCTION OBJECTS
#_DOC_
#Methods called by the objects of the class '.cf'
#In the following CF indicates a '.cf' object.
.mthd.bld_hp.cf <- function (CF, p.nms) {
	#_DOC_	
	#Builds a set of rates having an exponential prior probability distribution
	#_ARGUMENTS_
	#_MAIN_
	for (nm in .LNKHP) {
		if (!is.null(CF$hp$list[[nm]])) {
			hp.nms = CF$hp$list[[nm]]$get.attr('name', mode = 'sapply', exp = T, cp.rm = F, wrap = F)
			p.nms = paste0('%', gsub('%','', nm, fixed = T), '@', p.nms, '%@', CF$name)
			toadd = which(!(p.nms %in% hp.nms))
			if (length(toadd) > 0) {
				toadd.hp = r6.rep(CF$hp$list[[nm]]$expand()[[1]], n = length(toadd), deep = T)
				toadd.hp$set.attr('name', p.nms[toadd], all = F, exp = T)
				CF$hp$list[[nm]]$append(toadd.hp$expand())
				CF$hp$list[[nm]]$pop(.DUMMY, nl = 2, kp = F)
			}
		}
	}
	for (nm in .UNLNKHP) {
		if (!is.null(CF$hp$list[[nm]])) {
			n = length(CF$hp$list[[nm]]$expand(cp.rm = T))
			CF$hp$list[[nm]]$set.attr('name', paste0('%', gsub('%','', nm, fixed = T), 1:n, '@', CF$name), all = F, exp = T)
		}
	}
}

#* PREDEFINE KERNELS
KRN0 = krn$new(
	#_DOC_
	#Null kernel (return 0)
	#_MAIN_
	name = paste0('#KRN0#') , 
	cfs = list(cf.const$new(name = 'zero', k = uvrv.const$new(name = '%zero%', map = 0)))
)
