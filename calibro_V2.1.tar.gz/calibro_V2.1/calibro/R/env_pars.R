#  This file is part of Calibro.
#
#  Calibro is free software; you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation; either version 2 of the License, or
#  (at your option) any later version.
#  
#  Calibro is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#  
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software
#  Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
#  MA 02110-1301, USA.

#_DOC_
#CALIBRO ENVIRONMENT PARAMETERS

#* PARAMETERS
.NSNAME = 'calibro'		#namespace name
.DUMMY = '.DUMMY'		#name for nummy variables.
calibro_version = 'calibro-V2.1'	#calibro version
cat.calibro_version <- function() cat(paste0(calibro_version), sep = '\n')	#prints calibro version
calibro.citation <- function () {
	#_DOC_
	#Prints a citation for Calibro
cat('@Conference{Monari2017,
	Title                    = {Calibro an R package for the automatic calibration of building energy models.},
	Author                   = {Monari, F and Strachan, P A},
	Booktitle                = {Proceedings of Building Simulation 2017},
	Year                     = {2017},
	Address                  = {San Francisco (US)},
	Organization             = {International Building Simulation Association (IBPSA)},
	Doi                      = {https://doi.org/10.26868/25222708.2017.224},
}\n'
)}


.quasi1 <- function () {
	#_DOC_
	#Returns 1 - sqrt(epsilon(dlbe(0))
	#_MAIN_	
	1 - .intrf.env_par__get('tol')
}

#* FUNCTIONS

.intrf.env_par__get <- function (par) {
	#_DOC_
	#Interface fucntion to Fortran.
	#Returns the environment paramtere 'par' defined in the Fortran environment.
	#_ARGUMENTS_
	#par: character indicating parameteer name
	.C(paste0('__env_pars_MOD_intrf_', par, '__get'), double(1))[[1]]
}
