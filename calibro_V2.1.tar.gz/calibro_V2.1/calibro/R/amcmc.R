#  This file is part of Calibro.
#
#  Calibro is free software; you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation; either version 2 of the License, or
#  (at your option) any later version.
#  
#  Calibro is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#  
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software
#  Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
#  MA 02110-1301, USA.

#_DOC_
#ADAPTIVE MARKOV CHAIN MONTE CARLO.
#General functions, methods and classes to run adaptive Markov Chain Monte Carlo (amcmc) simulation.

#* PARAMETERS
#_DOC_
#Parameters to run a generic amcmc simulation.

.par.default_args.amcmc = list(
	#_DOC_
	#List containing default values for the arguments necessary to undertake an amcmc simulation.
	#_FIELDS_
	m = 1,						#number of cores = number of parallel simulations 
	n = '<until converged>', 	#number of trials per simulation (if '<until converged>' it runs until convergenece is reached)
	nBatches = 100, 			#number of bathces per simulation trial
	lBatch = 4, 				#number of cicles for each batch
	brn = 0.1, 					#burnin in fraction
	adapt = 1, 					#adapt flag (> 0 => adapts proposal distribution)
	vrb = 3, 					#verbose level
	prntstep = 5				#print result summary to scree every x simulation
) 
.par.ans_skel.amcmc = list(
	#_DOC_
	#Skeleton list for the output of an amcmc simulation
	#_FIELDS_
	'Z' = NULL,							#matrix containing the sampled values
	'lnpd' = NULL, 						#log-likelihood values correspdonding to the sampled values
	'bestLnpd' = -.Machine$double.xmax, #best log-likelihood value
	'bestz' = NULL						#varaible combination corresponding to the best log-likelihood value
)
.par.ans_upd_mthds.amcmc = list(
	#_DOC_
	#List containing the function for the updating of an amcmc output list.
	#Each filed updates the corresponding one in the output list.
	#_FIELDS_
	Z = function (ansi, ANSi) {
		Z = rbind(ansi[['Z']], ANSi[['Z']])
		ansi[['Z']] = Z
		return(ansi)
	},
	lnpd = function (ansi, ANSi) {
		lnpd = c(ansi[['lnpd']], ANSi[['lnpd']])
		ansi[['lnpd']] = lnpd
		return(ansi)
	},
	bestLnpd = function (ansi, ANSi) {
		if (max(ANSi[['bestLnpd']]) > ansi[['bestLnpd']]) {
			ansi[['bestz']] = ANSi[['bestz']]
			ansi[['bestLnpd']] = ANSi[['bestLnpd']]
		}
		return(ansi)
	},
	bestz = function (ansi, ANSi) {return(ansi)}	#it does nothing bestz z is set in bestLnpd but the function is needed for compatibility
)

#* AMCMC CLASS
amcmc = R6Class('amcmc',
	#_DOC_
	#Class representing an amcmc simulation
	inherit = calibro.obj,
	#** public
	public = list(
		#*** attributes
		args = NULL,
		#*** methods
		#**** initialize
		initialize = function (mdl, ...) {
			#_DOC_
			#Initilise the 'amcmc' class.
			#_ARGUMENTS_
			#mdl: model to simulate
			#args: simualtion arguments
			#state: initial state
			#_MAIN_
			x = list(...)
			self$args = private$.default_args
			for (nm in names(x)) if (nm %in% names(self$args)) self$args[[nm]] = x[[nm]]
			private$.state = lapply(1:self$args[['m']], function(i)return(private$.state_skel))
			private$.mdl = mdl
			private$.ans = lapply(1:self$args[['m']], function(i)return(private$.ans_skel))
			self$name = paste0(class(self)[1], '@', mdl$name)
		},
		#**** run
		run = function () {
			#_DOC_
			#Runs the 'amcmc' simulation. 
			#It start from the stored state so that the simulation can be continued in different times
			#_MAIN_
			.mthd.run.amcmc(self)
		},
		plot = function (...) {
			#_DOC_
			#Plots the 'amcmc' simulation by calling the 'plot.mcmc' of the 'coda' pacakge.
			.mthd.plot.amcmc(self, ...)
		}, 
		stat = function (s, ...) .mthd.stat.amcmc(self, s, ...),
		set.maps = function () .actmthd.set_maps.opt(self),
		set.MAPs = function () .actmthd.set_MAPs.opt(self),
		print = function () .mthd.print.amcmc(self),
		summary =  function (...) .mthd.summary.amcmc(self, ...)
	),
	#*** active
	active = list(
		#**** mdl
		mdl = function () {
			#_DOC_
			#Returns the simulated mdl
			#_MAIN_
			return(private$.mdl)
		},
		state = function () {
			#_DOC_
			#Returns the current state
			#_MAIN_
			return(private$.state)
		},
		ans = function () {
			#_DOC_
			#Returns the raw 'output' of the amcmc simulation.
			#_MAIN_
			return(private$.ans)
		},
		Z = function () {
			#_DOC_
			#Return the sampled matrix after burning the burnin fraction.
			#_MAIN_
			.mthd.get_Z.amcmc (self)
		},
		bestLnpd = function () {
			#_DOC_
			#Returns the best log-likelihood value found among all the undertaken simulation.
			#_MAIN_
			.mthd.get_bestLnpd.amcmc(self)
		},
		bestz = function () {
			#_DOC_
			#Returns the parameters corresponding to the best log-likelihood among all the undertaken simulation.
			#_MAIN_
			.mthd.get_bestz.amcmc(self)
		}
	),
	#** private
	private = list(
		#*** attributes
		.mdl = NULL,	#model to simulate
		.ans = NULL,	#output list
		.ans_skel = .par.ans_skel.amcmc,	#output skeleton list
		.ans_upd_mthds = .par.ans_upd_mthds.amcmc,	#updating methods for output list
		.ans_upd = function(ANS).prvmthd.ans_upd.amcmc(self, ANS),
		.state = NULL,		#current sate
		.state_skel = NULL,	#state skeleton list
		.state_upd = function (ANS) .prvmthd.state_upd.amcmc(self, ANS),	#methods for updating the state list
		.default_args = .par.default_args.amcmc,							#default argument list						
		.default_state = NULL,	#list of function returning the defualt values for the state (defined for ech kind of 'amcmc' algorithm)
		.run = function () .prvmthd.run.amcmc(self),			#only run the simulation (no updating no storing results)
		.cnv_single = function (...) ..cnv_single.amcmc(...),	#convergence criterion for single chain simulation
		.cnv_multi = function (...) ..cnv_multi.amcmc(...)		#convergence criterion for multi-chain simulation
	)
)

#* METHODS
#_DOC_
#functions called by the methods of the 'amcmc' class.
#In the following 'AMCMC' indicated an 'amcmc' class object.

.mthd.stat.amcmc <- function (AMCMC, s, ...) {
	#_DOC_
	#Applies the statistic 's' to the sampling matrix
	#_ARGUMENTS_
	#s: statistic (function) to apply
	#...: additional arguments for the 's' function or 'apply'
	#_MAIN_ 
	apply(AMCMC$Z, 2, s, ...)
}
.mthd.plot.amcmc <- function (AMCMC, ...) {
	#_DOC_
	#Plots the simulation by calling the plot.mcmc function from the package 'coda'
	#_ARGUMENTS_
	#...:additional parameters for the plot function.
	#_MAIN_
	if (all(is.na(AMCMC$Z))) {
		stop('plot not available.')
	} else {
		plot(AMCMC$Z, ...)
	}
}
.mthd.print.amcmc <- function (AMCMC) {
	#_DOC_
	#Printing method for the amcmc class
	#_MAIN_
	cat(paste0('\nAMCMC_', class(AMCMC)[1], ': ', AMCMC$name, '\n'))
	Z = AMCMC$Z
	if (all(is.na(Z))) {
		cat('\nNo information on the sample is available.\n', sep = '\n')
	} else {
		summary(Z)
	}
	
}
.mthd.summary.amcmc <- function (AMCMC, ...) {
	#_DOC_
	#Printing method for the amcmc class
	#_MAIN_
	Z = .mthd.get_Z.amcmc(AMCMC, bind = F)
	if (all(is.na(Z))) {
		stop('summary not available.')
	} else {
		summary(Z, ...)
	}
}
.mthd.get_Z.amcmc <- function (AMCMC, bind = T) {
	#_DOC_
	#Returns the matrix of sampled values
	#_ARGUMENTS_
	#bind: if T in case of multiple chains it binds the respective matrices together row-wise
	#_MAIN_
	fp = AMCMC$mdl$.fp
	Z = lapply(AMCMC$ans, function (x) {
		if (is.null(x[['Z']])) {return(NA)} else {..burn.amcmc(x[['Z']][,fp], brn = AMCMC[['args']][['brn']], thin = AMCMC$args[['lBatch']])}
	})
	if (all(is.na(Z))) return(NA)
	if (bind) {
		return(coda::mcmc(rbind.list(Z), thin = AMCMC$args[['lBatch']]))
	} else {
		return(coda::mcmc.list(Z))
	}	
}
.mthd.get_bestLnpd.amcmc <- function (AMCMC) {
	#_DOC_
	#Returns the overall best log-likelihood found among all the chains.
	#_MAIN_
	max(sapply(AMCMC$ans, function(x)x[['bestLnpd']]))
}
.mthd.get_bestz.amcmc <- function (AMCMC) {
	#_DOC_
	#Returns the paramters corresponding the the overall best log-likelihoos values found
	#_MAIN_
	besti = which.max(sapply(AMCMC$ans, function(x)x[['bestLnpd']]))
	return(AMCMC$ans[[besti]][['bestz']])
}
.mthd.run.amcmc <- function (AMCMC) {
	#_DOC_
	#Runs the 'amcmc' simulation and updates its output and state.
	#_MAIN_
	ANS = AMCMC$.get.private('.run')()
	AMCMC$.get.private('.state_upd')(ANS)
	AMCMC$.get.private('.ans_upd')(ANS)
	invisible(AMCMC)
}
.prvmthd.state_upd.amcmc <- function (AMCMC, ANS) {
	#_DOC_
	#Updates the state of the chain/chains.
	#_ARGUMENTS_
	#ANS: result output list from runing the simulation (see '.prvmthd.run.amcmc')
	#_MAIN_
	state = AMCMC$state
	for (i in 1:length(state)) {
		for (nm in names(state[[i]])) {
			state[[i]][[nm]] = ANS[[i]][[nm]]
		}
	}
	AMCMC$.set.private('.state', val = state)
}
.prvmthd.ans_upd.amcmc <- function (AMCMC, ANS) {
	#_DOC_
	#Updates the resul
	ans = AMCMC$ans
	for (i in 1:length(ans)) {
		for (nm in names(ans[[i]])) {
			ans[[i]][[nm]] = ANS[[i]][[nm]]
		}
	}
	AMCMC$.set.private('.ans', val = ans)
}
.prvmthd.run.amcmc <- function (AMCMC) {
	#_DOC_
	#Run an 'amcmc' simulation and return a raw output list.
	#_MAIN_
	..amcmc.single <- function () {
		#_DOC_
		#Runs a single chain until the required convergence criteria are met.
		#_MAIN_		
		state = state[[1]] #only one chain	
		args[['mdl']]$.get.private('.init')() 	#initialises the model
		do.call(AMCMC$.get.private('.init_alg'), c(args, state))	#initialises the variables for the algorithm
		ANS = AMCMC$ans[[1]]#.get.private('.ans_skel')
		#~runs the chains until convergence or until the max number of simulation is reached
		nsim = 0
		while (T) {
			nsim = nsim + 1
			ANSi = do.call(AMCMC$.get.private('.run_alg'), c(args, state))
			for (nm in names(ANS)) ANS = AMCMC$.get.private('.ans_upd_mthds')[[nm]](ANS, ANSi)
			time.elapsed = signif(as.numeric(Sys.time() - args[['start.time']], units = 'mins'), 3)
			if (nsim %% args[['prntstep']] == 0) {
				if (args[['vrb']] > 0) cat(paste('*** Simulation', nsim, '/', args[['n']], '(elapsed time:', time.elapsed, 'mins) ***\n'))
				if (do.call(AMCMC$.get.private('.cnv_single'), c(args, ANS))) break 
			}
			if (is.numeric(args[['n']]) && nsim > args[['n']]) break  
			if (..usr.cmd() == 'stop') break
		}
		#~
		#~packs the results
		states = names(AMCMC$.get.private('.state_skel'))
		for (nm in states) ANS[[nm]] = ANSi[[nm]]
		return(list(ANS))
		#~
	}
	..amcmc.multi <- function () {
		#_DOC_
		#Runs multiple chains in parallel.
		#_MAIN_
		cl = makeCluster(args[['m']])							#initilaises the cluster of workers
		clusterCall(cl, args[['mdl']]$.get.private('.init'))	#initialises the model (workers)
		parLapply(cl, 1:args[['m']], function(x)do.call(AMCMC$.get.private('.init_alg'), c(args, state[[i]])))	#initialises the algorithm (workers)
		ANS = AMCMC$ans#lapply(1:args[['m']], function(i)return(AMCMC$.get.private('.ans_skel'))) 
		#~Runs the chains untils convergence or the the maximum number of simulations is reached
		nsim = 0
		while (T) {
			nsim = nsim + 1
			ANSi = parLapply(cl, 1:args[['m']], function(i)do.call(AMCMC$.get.private('.run_alg'), c(args, state[[i]])))	#runs the chains (workers)
			for (i in 1:length(ANS)) for (nm in names(ANS[[i]])) ANS[[i]] = AMCMC$.get.private('.ans_upd_mthds')[[nm]](ANS[[i]], ANSi[[i]])
			time.elapsed = signif(as.numeric(Sys.time() - args[['start.time']], units = 'mins'), 3)
			#~checks convergence
			if (nsim %% args[['prntstep']] == 0) {
				if (args[['vrb']] > 0) cat(paste('*** Simulation', nsim, '/', args[['n']], '(elapsed time:', time.elapsed, 'mins) ***\n'))
				if (do.call(AMCMC$.get.private('.cnv_multi'), c(args, 'ANS' = ANS))) break 
			}
			if (is.numeric(args[['n']]) && nsim > args[['n']]) break  
			if (..usr.cmd() == 'stop') break
		}
		#~
		stopCluster(cl)
		#~packs the results
		states = names(AMCMC$.get.private('.state_skel'))
		for (i in 1:length(ANS)) for (nm in states) ANS[[i]][[nm]] = ANSi[[i]][[nm]]
		return(ANS)
		#~
	}
	args = AMCMC$args
	state = AMCMC$state
	args[['mdl']] = AMCMC$mdl
	args[['fp']] = args[['mdl']]$.fp
	for (nm in names(args)) if (is(args[[nm]], 'function')) args[[nm]] = do.call(args[[nm]], args)
	for (i in 1:args[['m']]) {
		for (nm in names(state[[i]])) {
			if (is.null(state[[i]][[nm]])) state[[i]][[nm]] = do.call(AMCMC$.get.private('.default_state')[[nm]], args)
		}
	}
	#~convergence thresholds
	args[['t.max']] = sapply(args[['mdl']]$pars$get.attr('cnv.rule1', exp = T, mode = 'lapply', wrap = F, cp.rm = T)[args[['fp']]], 
		function(x)x[['t.max']])
	args[['size.min']] = sapply(args[['mdl']]$pars$get.attr('cnv.rule1', exp = T, mode = 'lapply', wrap = F, cp.rm = T)[args[['fp']]], 
		function(x)x[['size.min']])
	#~	
	args[['start.time']] = Sys.time()	#starting time
	if (args[['vrb']] > 0) {
		do.call(AMCMC$.get.private('.print_start'), args)
	}
	#~initialises and runs the chains
	if (args[['m']] > 1) {	#multiple chains (only workers node)
		ANS = .exe.safeFort(..amcmc.multi)
	} else { 		#single chains (only on master)
		ANS = .exe.safeFort(..amcmc.single)
	}
	#~
	return(ANS)		
}

#* AUXILIARY FUNCTIONS
..z.default <- function (mdl, ...) {
	#_DOC_
	#Returns default values for the paramters
	#_ARGUMENTS_
	#mdl: model to simulate
	#...: additional ignored parameters
	#_MAIN
	mdl$pars$exe.mthd('r', n = 1, exp = T, cp.rm = T, mode = 'sapply', wrap = F)
}
..cnv_single.amcmc <- function (Z, fp, brn, lBatch, t.max, size.min, vrb, ...) {
	#_DOC_
	#Convergence criterion for single chains.
	#_ARGUMENTS_
	#Z: matrix of sampled values
	#fp: model free parameters
	#brn: burnin fraction
	#lBatch: number ciclt per batch
	#t.max: maximum threshold for the se of the mean extimate
	#size.min: minimum saple size
	#vrb: if T print feedback to screen
	#...: additional ignored parameters
	#_MAIN_
	Z = ..burn.amcmc(Z[,fp], brn = brn, thin = lBatch)
	ANS = try(..cnv.rule1(Z = Z, t.max = t.max, size.min = size.min, vrb = vrb), silent = T)
	if (is(ANS, 'try-error')) {
		cat('impossible to assess convergence')
		return(F)
	} else {
		return(ANS)
	}	
}
..cnv_multi.amcmc <- function (m, fp, brn, lBatch, vrb, t.max, size.min, ...) {
	#_DOC_
	#Convergence criterion for multiple chains.
	#_ARGUMENTS_	
	#m: number of chains
	#fp: model pree parameters
	#lBatch: number of cycles per batch
	#vrb: it T print feedback to screen
	#t.max: maximum threshold for the se of the mean extimate
	#size.min: minimum saple size
	#...: additional ignored parameters
	#_MAIN_
	X = list(...)
	Z = lapply(1:m, function(i) ..burn.amcmc(X[[paste0('ANS', i)]][['Z']][,fp], brn = brn, thin = lBatch))
	if (..cnv.rule2(mcmc.list(Z), vrb) && ..cnv.rule1(mcmc(rbind.list(Z)), t.max = t.max, size.min = size.min, vrb = vrb)) {
		return(T)
	}
	return(F)
}
..burn.amcmc <- function (Z, brn, thin) {
	#_DOC_
	#Burns the first brn fraction of the chains in the matrix Z and returns an mcmc object
	#_MAIN_
	Z = as.matrix(Z)
	brn = ceiling(nrow(Z) * brn)
	if (thin > 0) {
		Z = mcmc(Z[-(1:brn),], start = brn, thin = thin)
	} else {
		Z = Z[-(1:brn),]
	}
	return(Z)
}
..usr.cmd <- function () {
	#_DOC_
	#Looks for files with specific names in the working folder.
	#To each file names correspond an action.
	#_MAIN_
	if (file.exists('stop')) {
		return('stop')
	} else {
		return('keep going')
	}
}
..cnv.rule1 <- function (Z, t.max, size.min, vrb) {
	#_DOC_
	#Evaluate the convergence of a Markov chain according to the corrected sa / mean  ratio and to the minimum effective sie to achieve.
	#_ARGUMENTS_
	#Z: mcmc object
	#t.max: max allowed ratio se/mean (vector)
	#min.size: minimum allowed effective sizes of the chain (vector)
	#logic: character indicating which logic (&& or ||) should be used for combining the two criteria (vector)
	#vrb: verbose level 1, 2, or 3.
	#_MAIN_
	smr = summary(Z)
	t = abs(smr$statistics[,'Time-series SE'] / smr$statistics[,'Mean'])
	smr$statistics = cbind(smr$statistics, t)
	cnv1 = t <= t.max
	s = effectiveSize(Z)
	eff = s / nrow(Z) 
	smr$statistics = cbind(smr$statistics, eff, s)
	cnv2 = s >= size.min 
	cnv = all(cnv1 & cnv2)
	#~printing output
	if (vrb == 1) {
		t.stat = t - t.max
		t.stat[t.stat < 0] = 0
		s.stat = size.min - s
		s.stat[s.stat < 0] = 0
		cat('\rConvergence measures (-> 0):', paste('t =', nrm(t.stat), '; s = ', nrm(s.stat), '\n\n'))
	} else if (vrb == 2) { 
		smr$statistics = smr$statistics[,c('Mean', 'SD', 't', 's')]
		print(smr)
	} else if (vrb == 3) {
		print(smr)
	}
	#~
	return(cnv)
}
..cnv.rule2 <- function (Z, vrb) {
	#_DOC_
	#Evaluate the convergence of multiple chains to the same stationary distribution with the 
	#Gelman-Rubin diagnostic from the 'coda' package.
	#@NOTE the value 0.5 it has been chosen by the author and it seems reasonable accorting to the tested cases.
	#_ARGUMENTS_
	#Z: mcmc object
	#vrb: if T => prints the output of the Gelman-Rubin diagnostic
	#_MAIN_
	gd = try(gelman.diag(Z), silent = F)
	if (is(gd, 'try-error')) {
		return(F)
	} else {
		if (is.null(gd$mpsrf)) {
			cnv = gd$psrf - 1 < 0.5
		} else {
			cnv = gd$mpsrf - 1 < 0.5
		}
		if (vrb) print(gd)
		return(cnv)
	}
}

#* INTERFACES TO FORTRAN SUBROUTINE 
.intrf.amcmc__set_nlevels <- function (nlevels) {
	#_DOC_
	#Sets the number of levels
	#_ARGUMENTS_
	#nlevels: number of levels
	#_MAIN_
	ANS = .C('__amcmc_MOD_intrf_amcmc__set_nlevels', 
		'nLevels' = as.integer(nlevels)
	)
}
.intrf.amcmc__set_alg <- function (alg) {
	#_DOC_
	#Sets the algorithm id flag
	#_ARGUMENTS_
	#alg: algorithm id
	#_MAIN_
	ANS = .C('__amcmc_MOD_intrf_amcmc__set_alg', 
		'alg' = as.integer(alg)
	)
}
.intrf.amcmc__set_adapt <- function (adapt) {
	#_DOC_
	#Sets the adapt flag
	#_ARGUMENTS_
	#adapt: value to give to the flag
	#_MAIN_
	ANS = .C('__amcmc_MOD_intrf_amcmc__set_adapt', 
		'adapt' = as.integer(adapt)
	)
}
.intrf.nBatches__init <- function (nBatches) {
	#_DOC_
	#Initialises the vector containing the number of batches for each level.
	#_ARGUMENTS_
	#nBathces: number of batches for each level
	#_MAIN_
	ANS = .C('__amcmc_MOD_intrf_nbatches__init', 
		'nLevels' = as.integer(length(nBatches)), 
		'nBatches' = as.integer(nBatches)
	)
}
.intrf.lBatch__init <- function (lBatch) {
	#_DOC_
	#Initialises the vector contaning the batch lengths for each level
	#_ARGUMENTS_
	#lBatch: vector containing the length of the bathces of each level
	#_MAIN_
	ANS = .C('__amcmc_MOD_intrf_lbatch__init', 
		'nLevels' = as.integer(length(lBatch)), 
		'lBatch' = as.integer(lBatch)
	)
}
.intrf.iter__init <- function (iter) {
	#_DOC_
	#Initialises the vector containing the number of iterations for each level
	#iter: vector with the values of iterations from which is level has to start
	#_MAIN_
	ANS = .C('__amcmc_MOD_intrf_iter__init', 
		'nLevels' = as.integer(length(iter)), 
		'iter' = as.integer(iter)
	)
}
.intrf.iter__size <- function () {
	#_DOC_
	#returns the size of the array used to store the number of iteration for each batch.
	#_MAIN_
	.C('__amcmc_MOD_intrf_iter__size', integer(1))[[1]]
}
.intrf.iter__get <- function () {
	#_DOC_
	#Retrieves the array containing the number of iteration for each batch.
	#_MAIN_
	n = .intrf.iter__size()
	.C('__amcmc_MOD_intrf_iter__get', integer(n), as.integer(n))[[1]]
}
.intrf.beta__init <- function (beta) {
	#_DOC_
	#Initialises the array containing the beta factors for each level.
	#_ARGUMENTS_
	#breta: vector wih the initial values of the betas
	#_MAIN_
	ANS = .C('__amcmc_MOD_intrf_beta__init', 
		'nLevels' = as.integer(length(beta)), 
		'beta' = as.double(beta)
	)
}
.intrf.amcmc__z_init <- function (z) {
	#_DOC_
	#Initialises the vectors z, bestz, newz, and the variables lnpd, bestLnpd, newlnpd.
	#_ARGUMENTS_
	#z: the initial z vector
	#_MAIN_
	ANS = .C('__amcmc_MOD_intrf_amcmc__z_init', 
		'lz' = as.integer(length(z)), 
		'z' = as.double(z)
	)
}
.intrf.fp__init <-function (fp) {
	#_DOC_
	#Initialises the mask that contains the indexes of the free parameters of a model
	#_MAIN_
	ANS = .C('__amcmc_MOD_intrf_fp__init', 
		'n' = as.integer(length(fp)),
		'fp' = as.integer(fp)
	)
}


