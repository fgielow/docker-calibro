#  This file is part of Calibro.
#
#  Calibro is free software; you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation; either version 2 of the License, or
#  (at your option) any later version.
#  
#  Calibro is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#  
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software
#  Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
#  MA 02110-1301, USA.
#

#* CALIBRO OBJECT
#All object in calibro inherit this class
calibro.obj = R6Class('calibro.obj',
	#** public
	public = list(
		#*** methods
		#**** .get.private
		.get.private = function (what) {
			#_DOC_
			#Can be used to retrieve private attributes and methods.
			#_ARGUMENTS_
			#what: the name of the method/attribute to retrieve
			#_MAIN_
			if (!(what %in% names(private))) {
				stop(paste(what, 'is not in the private fileds of the object', self$name))
			} else {
				return(private[[what]])
			}
		},
		#**** .set.private
		.set.private = function (what, val) {
			#_DOC_
			#Can be used to set the value of private attributes.
			#_ARGUMENTS_
			#what: name of the attribute to set
			#val: value to give to the attribute
			#_WARNING_: this method does not perform any checking on val. It is up to the user to know what it is going on when using this method.
			#_MAIN_
			if (!(what %in% names(private))) {
				stop(paste(what, 'is not in the private fileds of the object', self$name))
			} else {
				private[[what]] = val
			}
		}
	),
	#** active
	active = list(
		#*** name
		name = function (nm) {
			#_DOC_
			#Sets return the name of the object.
			#_ARGUMENTS_
			#nm: name of the object
			#_MAIN_
			if (missing(nm)) {return(private$.name)} else {.actmthd.wrp(self, nm, .actmthd.set_name)}
		}
	),
	#** private
	private = list(
		#** attributes
		.name = NULL	#name of the object
	)
)

#* ACTIVE METHODS
#Functions called by the active bindins of the 'calibro.obj' class.
#In the following CO stands for Calibro Object.
.actmthd.set_name <- function (CO, nm) {
	#_DOC_
	#Sets the name of the object.
	#_ARGUMENTS_
	#nm: object name.
	#_MAIN_
	CO$.set.private('.name', val = ifelse(is.null(nm), .DUMMY, nm))
	invisible()
}
