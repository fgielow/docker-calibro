# ROOT CLASS FOR OPTIMISATION SIMULATIONS AND GENERAL FUNCTION

#  This file is part of Calibro.
#
#  Calibro is free software; you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation; either version 2 of the License, or
#  (at your option) any later version.
#  
#  Calibro is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#  
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software
#  Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
#  MA 02110-1301, USA.

#OPT CLASS
opt = R6Class('opt',
	#_DOC_
	#Root class for objects representing optimisation algorithms.
	inherit = calibro.obj,
	#** public
	public = list(
		#*** attributes
		args = NULL,	#list of parameters for running the optimisation algorithm
		#*** methods
		#**** initialize
		initialize = function (mdl, ...) {
			#_DOC_
			#Initialises the 'opt' class object.
			#_ARGUMENTS_
			#mdl: model to optimise
			#...: argument values to sobstitute the default ones
			#_MAIN_
			x = list(...)
			self$args = private$.default_args
			for (nm in names(x)) if (nm %in% names(self$args)) self$args[[nm]] = x[[nm]]
			private$.mdl = mdl
		},
		#**** run
		run = function () {
			#_DOC_
			#Runs the optimisation algorithm.
			#_MAIN_
			.mthd.run.opt(self)
		},
		#**** set.maps
		set.maps = function () {
			#_DOC_
			#Softly sets/returns the MAP values of the model parameters.
			#_MAIN_
			ANS = .actmthd.set_maps.opt(self)
		},
		#****
		set.MAPs = function () {
			#_DOC_
			#Strongly sets/returns the MAP values of the model parameters.
			#_MAIN_
			ANS = .actmthd.set_MAPs.opt(self)
		},
		print = function () {
			#_DOC_
			#Printing method
			#_MAIN_
			.mthd.print.opt(self) 	
		}
	),
	#** active
	active = list(
		#*** mdl
		mdl = function () {
			#_DOC_
			#Returns the model to optimise.
			#_MAIN_
			return(private$.mdl)
		},
		#*** ans
		ans = function () {
			#_DOC_
			#returns the list containing the results of the optimisation
			return(private$.ans)
		},
		#*** besty
		besty = function () {
			#_DOC_
			#Returns the best function values found.
			#_MAIN_
			return(private$.ans[['besty']])
		},
		#*** bestz
		bestz = function () {
			#_DOC_
			#Returns the combination of model parameters corresponding to the best value.
			#_MAIN_
			return(private$.ans[['bestz']])
		}
	),
	#** private
	private = list(
		#attributes
		.mdl = NULL,	#model to optimise
		.ans = list(),	#result list
		.default_args = list(),	#defualt arguments for the optimisation algorithm
		#*** methods
		#**** .run
		.run = function () {
			#_DOC_
			#Only runs the optimisation algorithm.
			#_MAIN_
			.prvmthd.run.opt(self)
		}
	)
)

#* METHODS FUNCTIONS
#In the following OPT indicate and object of the 'opt' class.

.mthd.run.opt <- function (OPT) {
	#_DOC_
	#Runs the optimisation algorithm and store the results.
	#_MAIN_
	ANS = OPT$.get.private('.run')()
	OPT$.set.private('.ans', val = ANS)
	invisible(OPT)
}
.mthd.print.opt <- function (OPT) {
	#_DOC_
	#Printing method for the amcmc class
	#_MAIN_
	cat(paste0('\nOPT_', class(OPT)[1], ': ', OPT$name, '\n'))
	if (is.null(OPT$bestz) || is.null(OPT$besty)) {
		cat('\nSummary not available.\n\n')
	} else {
		cat(paste('best y:', OPT$besty, '\n')) 
		cat('best z:\n')
		for (i in 1:length(OPT$bestz)) cat(paste0('\t', names(OPT$bestz)[i], ' = ', OPT$bestz)[i], '\n')
		cat('\n')
	}
}
.actmthd.set_maps.opt <- function (OPT) {
	#_DOC_
	#Softly sets MAP values of the model parameters.
	#_MAIN_
	mdl = OPT$.get.private('.mdl')
	if (is.null(OPT$bestz)) stop("'bestz' not available.")
	mdl$maps = OPT$bestz
	invisible(OPT)
}
.actmthd.set_MAPs.opt <- function (OPT) {
	#_DOC_
	#Strongly sets MAP values of the model parameters.
	#_MAIN_
	mdl = OPT$.get.private('.mdl')
	if (is.null(OPT$bestz)) stop("'bestz' not available.")
	mdl$MAPs = OPT$bestz
	invisible(OPT)
}
.prvmthd.run.opt <- function (OPT) {
	#_DOC_
	#Runs the optimisation within the 'opt' class object.
	#_CONTAINS_
	..print.best <- function () {
		#_DOC_
		#Prints the output of a simulation to screen
		#_MAIN_
		cat(paste('\n*** Simulation', nsim, '/', args[['n']], '(elapsed time:', time.elapsed, 'mins) ***\n'))
		cat(paste('\n best y:', besty))
		cat('\n best z:\n')
		sapply(args[['fp']], function(i)cat(paste('\t', p.nms[i], '=', signif(bestz[i], 4), '\n')))
	}
	..opt.single <- function () {
		#_DOC_
		#Runs a single optimisation.
		#_MAIN_		
		args[['mdl']]$.get.private('.init')() 	#initialises the model
		do.call(OPT$.get.private('.init_alg'), args)	#initialises the variables for the algorithm
		#~runs the chains until convergence or until the max number of simulation is reached
		B = list(rbind(
			rep(0, length(args[['mdl']]$pars$expand(cp.rm = T))), 
			rep(1, length(args[['mdl']]$pars$expand(cp.rm = T)))
		)) 
		while (T) {
			nsim <<- nsim + 1
			ANS = do.call(OPT$.get.private('.run_alg'), c(args, bnd = B))
			time.elapsed <<- signif(as.numeric(Sys.time() - args[['start.time']], units = 'mins'), 3)
			if (ANS[['besty']] > besty) {
				besty <<- ANS[['besty']]
				bestz <<- ANS[['bestz']]
			}
			if (nsim %% args[['prntstep']] == 0) {
				if (args[['vrb']] > 0) ..print.best()
			}
			ybs = c(ybs, besty)
			if (length(ybs) > 2) {
				if (..stop.rule2(ybs, args[['ftol']])) break
			}
			if (is.numeric(args[['n']]) && nsim > args[['n']]) break  
			if (..usr.cmd() == 'stop') break
		}
		return(list('bestz' = bestz, 'besty' = besty))
	}
	..opt.multi <- function () {
		#_DOC_
		#Runs multiple optimisation in parallel. @TODO update as direct
		#_MAIN_
		cl = makeCluster(args[['m']])							#initilaises the cluster of workers
		clusterCall(cl, args[['mdl']]$.get.private('.init'))	#initialises the model (workers)
		parLapply(cl, 1:args[['m']], function(x)do.call(OPT$.get.private('.init_alg'), args))	#initialises the algorithm (workers)
		nsim = 0
		SS = list(rbind(
			rep(0, length(args[['mdl']]$pars$expand(cp.rm = T))), 
			rep(1, length(args[['mdl']]$pars$expand(cp.rm = T)))
		))
		VOL = sapply(SS, dom.vol)
		W = 1
		Y = c(NA)
		active = 1
		while (T) {
			nsim <<- nsim + 1
			B = split.domain(SS[[active]], 3)
			ANS = parLapply(cl, 1:args[['m']], function(i)do.call(OPT$.get.private('.run_alg'), 
				c(args, bnd = B[1]))) #runs the chains (workers)
			time.elapsed <<- signif(as.numeric(Sys.time() - args[['start.time']], units = 'mins'), 3)
			ybi = sapply(ANS, function(x)x[['besty']])
			Y = c(Y, ybi)
			Y = Y[-active]
			SS = c(SS, B)
			SS = SS[-active]
			VOL = sapply(SS, dom.vol)
			W1 = exp(Y - logSumExp(Y))
			plot(W1)
			W2 = VOL 
			points(W2, col = 2)
			W = W1 * W2
			W = W/sum(W)
			active = sample(1:length(SS), 1, prob = W)
			abline(v = active, col = 4)
			if (max(ybi) > besty) {
				besty <<- ANS[[which.max(ybi)]][['besty']]
				bestz <<- ANS[[which.max(ybi)]][['bestz']]
			}
			if (nsim %% args[['prntstep']] == 0) {
				if (args[['vrb']] > 0) ..print.best()
			}
			ybs = c(ybs, besty)
			if (length(ybs) > args[['m']] * length(args[['fp']])) {
				if (..stop.rule2(ybs, args[['ftol']])) break
			}
			if (is.numeric(args[['n']]) && nsim > args[['n']]) break  
			if (..usr.cmd() == 'stop') break
		}
		#~
		stopCluster(cl)
		#~packs the results
		return(list('bestz' = bestz, 'besty' = besty))
		#~
	}
	#_MAIN_
	args = c(OPT$args, OPT$ans)
	args[['mdl']] = OPT$mdl 
	args[['fp']] = OPT$mdl$.fp
	for (nm in names(args)) if (is(args[[nm]], 'function')) args[[nm]] = do.call(args[[nm]], args)
	nsim = 0
	ybs = c()
	time.elapsed = 0
	nsim = 0
	besty = args[['besty']]
	if (is.null(besty)) besty = -.Machine$double.xma
	bestz = args[['bestz']]
	p.nms = args[['mdl']]$pars$get.attr('name', cp.rm = T)
	args[['start.time']] = Sys.time()	#starting time
	if (args[['vrb']] > 0) do.call(OPT$.get.private('.print_start'), args)
		if (args[['m']] > 1) {	#multiple chains (only workers node)
		ANS = .exe.safeFort(..opt.multi)
	} else { 		#single chains (only on master)
		ANS = .exe.safeFort(..opt.single)
	}
	#~
	names(ANS[['bestz']]) = p.nms
	return(ANS)		
}

#* AUXILIARY FUNCTIONS
#** STOP RULES
..stop.rule1 <- function (v, tol, vrb = F) {
	#_DOC_
	#The ration between mean difference function of the outputs of the optimisaiton and the mean of the 
	#of the output of the optimiation must be lower than a tol.
	#_ARGUMENTS_
	#v: optimisation outputs
	#tol: tollerance
	#_MAIN_
	t = abs(mean(diff(v))/mean(v))
	if (vrb) cat(paste('t:', t, '\n'))
	return(t < tol)
}
..stop.rule2 <- function (v, tol, vrb = F) {
	#_DOC_
	#Like ..stop.rule1 but the differences are weighted linearly.
	#_ARGUMENTS_
	#v: optimisation output
	#tol: tollerance
	#_MAIN_
	w = 1:(length(v) - 1)
	w = w / sum(w)
	t = abs(sum(diff(v) * w)/mean(v))
	if (vrb) cat(paste('\nt:', t, '(<', tol, ')\n'))
	return(t < tol)
}
..stop.rule3 <- function (v, tol, vrb = F) {
	#_DOC_
	#Like ..stop.rule1 but the differences are weighted logarithmically.
	#_ARGUMENTS_
	#v: optimisation output
	#tol: tollerance
	#_MAIN_
	w = log(1:(length(v) - 1))
	w = w / sum(w)
	t = abs(sum(diff(v) * w)/mean(v))
	if (vrb) cat(paste('t:', t, '\n'))
	return(t < tol)
}
..stop.rule4 <- function (v, tol, vrb = F) {
	#_DOC_
	#Like ..stop.rule1 but the differences are weighted geometrically.
	#_ARGUMENTS_
	#v: optimisation output
	#tol: tollerance
	#_MAIN_
	w = (1 + 1/(length(v) - 1))**(1:(length(v) - 1))
	w = w / sum(w)
	t = abs(sum(diff(v) * w)/mean(v))
	if (vrb) cat(paste('t:', t, '\n'))
	return(t < tol)
}
..stop.rule5 <- function (v, tol, vrb = F) {
	#_DOC_
	#Like ..stop.rule1 but the differences are weighted geometrically.
	#_ARGUMENTS_
	#v: optimisation output
	#tol: tollerance
	#_MAIN_
	t = abs(tail(diff(v), 1)/mean(v))
	if (vrb) cat(paste('t:', t, '\n'))
	return(t < tol)
}

#** DOMAIN EXPLORATION
split.domain <- function (B, ns) {
	#_DOC_
	#Split a domain in a number of subdomains.
	#_ARGUMENTS_
	#B: matrix of boundaries (the ith column contains the boundaries for the ith dimension).
	#ns: vector containing the number of section in which divide each dimension.
	#MAIN
	D = apply(B, 2, diff)
	if (length(ns == 1)) {
		ns = rep(ns, length(D))
		ns[-which.max(D)] = 1
	}
	sec1 = lapply(1:length(D), function(x)return(seq(B[1,x], B[2,x] - D[x] / ns[x], D[x] / ns[x])))
	sec2 = lapply(1:length(D), function(x)return(seq(B[1,x] + D[x] / ns[x], B[2,x], D[x] / ns[x])))
	dom.grid = expand.grid(lapply(1:length(ns), function(x)1:ns[x]))
	return(
		lapply(1:nrow(dom.grid), 
			function(i)sapply(1:ncol(B), 
				function(j)return(c(sec1[[j]][dom.grid[i,j]], sec2[[j]][dom.grid[i,j]]))
			)
		)
	)
}
dom.vol <- function (B) {
	#_DOC_
	#Calculates the volume of a domain/sub-domain/
	#B: matrix having a rows the the corners of the hypercube.
	#_MAIN_
	prod(apply(B, 2, diff))
}
