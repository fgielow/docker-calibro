#  This file is part of Calibro.
#
#  Calibro is free software; you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation; either version 2 of the License, or
#  (at your option) any later version.
#  
#  Calibro is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#  
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software
#  Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
#  MA 02110-1301, USA.

#* CALENV CLASS
calEnv = R6Class('calEnv',
	#_DOC_
	#Class representing a calibration environment. 
	inherit = calibro.obj,
	public = list(
		#*** methods
		#**** intialize
		initialize = function (name) {
			#_DOC_
			#Initialeses the calibration environment with the chosen name.
			#If a saved calibration environment with the same name is found in the working directory,
			#it is loaded as current calibration environemnt
			#_ARGUMENTS_
			#name: name/description (short) for the calibration environemnt
			#_MAIN_
			self$name = name
			private$.dss = r6.list$new(cl = 'ds')
		},
		#**** add.ds
			add.ds = function (name, Y.star, TT, Y) {		#this line to turn off boundary conditions
#			add.ds = function (name, Y.star, X, TT, Y) {	#this line to turn on boundary conditions
			#_DOC_
			#Adds a calibration dataset to the environment.
			#_ARGUMENTS_
			#name: dataset name or short descritpion
			#Y.star: path to observations file
			#X: path to boundary conditions file
			#TT: path to model inputs file
			#Y: path to simulation output file
			#_MAIN_
			.mthd.add_ds.calEnv(self, name, Y.star, TT, Y)		#this line to turn off boundary conditions
#			.mthd.add_ds.calEnv(self, name, Y.star, X, TT, Y)	#this line to turn on boundary conditions
		},
		#**** cal.res
		cal.res = function (mode = 'summary', ...) {
			#_DOC_
			#Returns a set of results according to the given mode.
			#_ARGUMENTS_
			#mode: result mode
			#...: additional arguments to be passed to the called result mode.
			#_MAIN_
			.mthd.cal_res.calEnv(self, mode, ...)
			#private[[paste0('res.', mode)]](...)
		},
		theta = function (val = NULL, ...) {
			#_DOC_
			#Returns the wanted value with respect to the calibration parameters.
			#_ARGUMENTS_
			#val: wnated value
			#...: additional parameters for the function
			#_MAIN_
			if(is.null(val)){return(private$.theta)}else{private[[paste0('theta.', val)]](...)}
		},
		train.gof = function (gof) {
			#_DOC_
			#Returns the wanted GOF with repsect to the trianed models.
			#_ARGUMENTS_
			#gof: wanted GOF
			#_MAIN_
			.mthd.train_gof.calEnv(self, gof)
		},
		calibrate = function () {
			#_DOC_
			#Runs the whole calibration process
			#_MAIN_
			.mthd.run_cal_prc.calEnv(self)
		},
		genReport = function (type, out = c('sa', 'cal'), wrt = T) {
			#_DOC_
			#Generates a report according to given format type.
			#_ARGUMENTS_
			#type: type of report ('json' or 'pdf')
			#out: outputs to include in the report ('sa': sensitivity, 'cal': calibration, 'ds': datasets (only 'pdf'), 'train': training)
			#wrt: only for 'json'. If T => write the JSON report to file.
			#_MAIN_
			genrep.fun = getFromNamespace(paste0('.mthd.genReport_', type, '.calEnv'), ns = .NSNAME)
			genrep.fun(self, out, wrt)	
		}
	),
	#** active
	active = list(
		#*** dss
		dss = function (x) {
			#_DOC_
			#Returns the stored calibration datasets.
			#_MAIN_
			if (missing(x)) {return(private$.dss)} else {}
		},
		#*** rd
		rd = function (type) {
			#_DOC_
			#Returns/sets the reduction procedure for the stored datasets.
			#_ARGUMENTS_
			#type: type of reduction to apply (at the moment only 'pca')
			#_MAIN_
			if(missing(type)){.actmthd.get_rd.calEnv(self)}else{.actmthd.wrp(self, type, .actmthd.set_rd.calEnv)}
		},
		#*** sa
		sa = function (type) {
			#_DOC_
			#Returns/sets the sensitivity analysis procedure.
			#_ARGUMENTS_
			#type: type of sensitivity analysis (at the moment only 'sobolSmthSpl')
			#_MAIN_
			if(missing(type)){.actmthd.get_sa.calEnv(self)}else{.actmthd.wrp(self, type, .actmthd.set_sa.calEnv)}
		},
		#*** ret
		ret = function (type) {
			#_DOC_
			#Retains the/sets the procedure for reatineg the model parameters.
			#_ARGUMENTS_
			#type: type of retention criterion (at the moment only 'ng.screening')
			#_MAIN_
			if(missing(type)){.actmthd.get_ret.calEnv(self)}else{.actmthd.wrp(self, type, .actmthd.set_ret.calEnv)}
		},
		#*** mdls
		mdls = function (type) {
			#_DOC_
			#Returns/creates the models for the given cdatasets.
			#_ARGUMENTS_
			#type: type of models
			#_MAIN_
			if(missing(type)){return(.actmthd.get_mdls.calEnv(self))}else{.actmthd.wrp(self, type, .actmthd.set_mdls.calEnv)}
		},
		#*** train				
		train = function (pars) {
			#_DOC_
			#Return the training objs/trains the models.
			#_ARGUMENTS_
			#pars: parameters for the creation of the training objects.
			#_MAIN_
			if(missing(pars)){.actmthd.get_train.calEnv(self)}else{.actmthd.wrp(self, pars, .actmthd.set_train.calEnv)}
		},
		#*** cals
		cals = function (type) {
			#_DOC_
			#Creates/returns the calibration models.
			#_ARGUMENTS_
			#type: type of calibration model
			#_MAIN_
			if(missing(type)){.actmthd.get_cals(self)}else{.actmthd.wrp(self, type, .actmthd.set_cals.calEnv)}
		},
		#*** calibrate
		cal.mcmc = function (pars) {
			#_DOC_
			#Returns/ creates and run the amcmc obj performing the calibration.
			#_ARGUMENTS_
			#pars: parameters for creating and running the amcmc obj.
			#_MAIN_
			if(missing(pars)){return(private$.cal.mcmc)}else{.actmthd.wrp(self, pars, .actmthd.set_calMcmc.calEnv)}
		}
	),
	#** private
	private = list(
		#*** attributes
		.dss = NULL,		#datasets
		.theta = NULL,		#calibration parameters
		.mdls = NULL,		#training models
		.cals = NULL,		#calibration models
		.train = NULL,		#training
		.cal.mcmc = NULL,	#stores the output of MCMC for the calibration models
		#*** methods
		theta.nms = function () .prvmthd.theta_nms.calEnv(self),
		theta.rngs = function () .prvmthd.theta_rngs.calEnv(self),
		theta.bld = function (fit = F) if(fit){.prvmthd.bld2_thetas.calEnv(self)}else{.prvmthd.bld1_thetas.calEnv(self)},
		res.summary = function (gof) .prvmthd.res_summary.calEnv(self, gof),
		res.theta = function () .prvmthd.res_theta.calEnv(self),
		res.predict = function (n = 100) .prvmthd.res_predict.calEnv(self, n),
		res.gof = function (mdl, gof) .prvmthd.res_gof.calEnv(self, mdl, gof)
	)
)

#* ACTIVE METHODS
#_DOC_
#Function called by active bindings of the 'calEnv' class.
#In the following 'CE' indicates a 'calEnv' class object.

.actmthd.get_rd.calEnv <- function (CE) {
	#_DOC_
	#Retrieve the dataset reduction object.	
	#_MAIN_
	CE$.get.private('.dss')$get.attr('rd', exp = T, cp.rm = T, mode = 'lapply', wrap = T)
}
.actmthd.set_rd.calEnv <- function (CE, type) {
	#_DOC_
	#Set the reduction type and performs it.
	#_ARGUMENTS_
	#type: type of reduction.
	#_MAIN_
	ANS = CE$.get.private('theta.rngs')() #set ranges for calibration prameters
	CE$.get.private('.dss')$set.attr('rd', val = type, exp = T, all = T)
	invisible()
}
.actmthd.get_sa.calEnv <- function (CE) {
	#_DOC_
	#Retrieve the sensitivity analysis objects.
	#_MAIN_
	CE$rd$get.attr('sa', exp = T, cp.rm = T, mode = 'lapply', wrap = F)
}
.actmthd.set_sa.calEnv <- function (CE, type) {
	#_DOC_
	#Sets the sensitivity object and performs the analysis.
	#_MAIN_
	CE$dss$set.attr('sa', val = type, exp = T, all = T)
	invisible()
}
.actmthd.get_ret.calEnv <- function (CE) {
	#_DOC_
	#Retrieves the retained parameters and bases for each dataset.
	#_MAIN_
	CE$rd$get.attr('ret', exp = T, cp.rm = T, mode = 'lapply', wrap = F)
}
.actmthd.set_ret.calEnv <- function (CE, type) {
	#_DOC_
	#Set and perform factor retention.
	#_ARGUMENTS_
	#type: list of parameters to pass to the retention method.
	#_MAIN_
	CE$dss$set.attr('ret', val = type, exp = T, all = T)
	invisible()
}
.actmthd.set_mdls.calEnv <- function (CE, type) {
	#_DOC_
	#Sets and bild the metha-models.
	#_ARGUMENTS_
	#type: type of metha-model to build.
	#_MAIN_
	CE$dss$set.attr('mdls', val = type, exp = T, all = T)
	invisible()
}
.actmthd.get_mdls.calEnv <- function (CE) {
	#_DOC_
	#Retreves the metha-models.
	#_MAIN_
	mdls = CE$dss$get.attr('mdls', exp = T, mode = 'lapply', cp.rm = T, wrap = T, cl = 'gprVec')
	mdls = unlist(mdls$exe.mthd('expand', exp = F, mode = 'lapply', cp.rm = T, wrap = F))
	return(gprVec$new(name = paste0(CE$name, '.mdl'), gprs = mdls))	
}
.actmthd.get_train.calEnv <- function (CE) {
	#_DOC_
	#Retrieves the training objects.
	#_MAIN_
	CE$dss$get.attr('train', exp = T, mode = 'lapply', cp.rm = T, wrap = T)	
}
.actmthd.set_cals.calEnv <- function (CE, type) {
	#_DOC_
	#Sets and builds the calibration models.
	#_ARGUMENTS_
	#type: type of calibrators to build
	#_MAIN_
	#~if needed build the calibration parameters					
	if (is.null(CE$theta())) CE$theta('bld')
	#~
	#~creates a lists with the calibration parameters of each datasets
	theta = lapply(
		CE$dss$get.attr('TT.nms', exp = T, mode = 'lapply', cp.rm = T, wrap = F),
		function(nms)CE$theta()$extract(name = nms, grep = F, wrap = F)
	)
	#~
	CE$dss$set.attr('theta', val = theta, all = F)	#attributes the lists of thetas	
	CE$dss$set.attr('cals', val = type, all = T)	#creates the calibrators for each dataset
	invisible()
}
.actmthd.get_cals <- function (CE) {
	#_DOC_
	#Retrieves the calibrators.
	#_MAIN_
	cals = CE$dss$get.attr('cals', exp = T, mode = 'lapply', cp.rm = T, wrap = T, cl = 'gprCalVec')
	cals = unlist(cals$exe.mthd('expand', exp = F, mode = 'lapply', cp.rm = T, wrap = F))
	return(gprCalVec$new(name = paste0(CE$name, '.cal'), gprCals = cals))
}
.actmthd.set_train.calEnv <- function (CE, pars) {
	#_DOC_
	#Train the model emulator/Returns the results from training.
	#_ARGUMENTS_
	#pars: list specifying the parameters for the training algorithm. Use NULL to use default settings
	#_MAIN_
	CE$dss$set.attr('train', val = pars, all = T, exp = T)
	invisible()
}
.actmthd.set_calMcmc.calEnv <- function (CE, pars) {
	#_DOC_
	#Infers the calibration parameters by appling MCMC algorithms to the calibration models.
	#_MAIN_
	alg = pars[['alg']]
	pars[['alg']] = NULL
	AMCMC = getFromNamespace(alg, ns = .NSNAME)
	AMCMC = do.call(AMCMC$new, c(mdl = CE$cals, pars))
	CE$.set.private('.cal.mcmc', val = AMCMC)
	CE$cal.mcmc$run()
	invisible()
}

#* METHODS
#_DOC_
#Function called by the methods of the class 'calEnv'.
.mthd.add_ds.calEnv <- function (CE, name, Y.star, TT, Y) { 	#this line to turn off boundary conditions
#.mthd.add_ds.calEnv <- function (CE, name, Y.star, X, TT, Y) { #this line to turn on boundary conditions	
	#_DOC_
	#Adds a dataset to the calibration environment
	#_ARGUMENTS_
	#name: dataset name
	#Y.star: csv file names for the observation matrices
	#X: csv file names for the boundary condition matrices
	#input.csv: input list
	#sims.csv: simulation list
	CE$dss$append(objs = list(
		ds$new(
			name = name,
			Y.star = read.list.csv(Y.star),
			Y = read.list.csv(Y),
			X = NULL, #replace NULL with read.list.csv(X) to enable boundary conditions
			TT = as.matrix(read.csv(TT, header = T))
		)
	))
	invisible(CE)
}	
.mthd.calibrate.calEnv <- function (CE) {
	#_DOC_
	#Undertakes the whole calibration process
	#_MAIN_
	cat('\n\nSTARTING CALIBRATION PROCESS\n\n')
	cat('Reducing datasets...')
	CE$rd = 'pca'				
	cat('done\n')
	cat('Performing SA...')
	CE$sa = 'sobolSmthSpl'
	cat('done\n')
	cat('Performing factor retention...')
	CE$ret = list(mthd = 'ng.screening')
	cat('done\n')
	cat('Building emulators...')						
	CE$mdls = 'gpr.ng.sePar01_whitePar01'
	cat('done\n')
	cat('Training emulators...')
	CE$train = list(type = 'fw_training', alg = 'amoeba', vrb = 0)
	CE$train$exe.mthd('set.MAPs')
	cat('done\n')	
	cat('Building calibrators...')
	CE$cals = 'cal.gpr.ng'
	cat('done\n')
	cat('Calibrating with:\n')
	CE$cal.mcmc = list(alg = 'amg', n = 1000)	
	cat('\ndone\n')
	invisible(CE)	
}

.mthd.train_gof.calEnv <- function (CE, gof = 'Rscore3') {
	#~calculates and stores a global R score
	Y.hat = CE$rd$exe.mthd('predict', mdl = 'mdls', Z.star = NULL, n = 0, exp = T, cp.rm = T, wrap = F, mode = 'lapply')
	Y = CE$rd$get.attr('Y', exp = T, cp.rm = T, wrap = F, mode = 'lapply')
	ANS = sapply(1:length(Y.hat), function(i)do.call(gof, list(y = as.vector(Y[[i]]), y.hat = as.vector(Y.hat[[i]][['pMu']]))))
	names(ANS) = CE$dss$get.attr('name', cp.rm = T)
	return(ANS)
	#~
}
.prvmthd.theta_nms.calEnv <- function (CE) {
		unique(unlist(CE$dss$get.attr('TT.nms', mode = 'lapply', exp = T, cp.rm = T, wrap = F)))
}
.prvmthd.theta_rngs.calEnv <- function (CE) {
	#_DOC_
	#Returns the lower bounds of the calibration parameter ranges.
	#_MAIN_
	CE$dss$set.attr('TT.rngs', val = NULL, exp = T, all = T)
	nms = CE$.get.private('theta.nms')()
	rngs = CE$dss$get.attr('TT.rngs', mode = 'lapply', exp = T, cp.rm = T, wrap = F)
	rngs = sapply(nms, function(nm)range(sapply(rngs, function(x)if(nm %in% colnames(x)){return(x[,nm])}else{return(c(NA, NA))}), na.rm = T))
	rngs = as.matrix(rngs)
	nms = CE$dss$get.attr('TT.nms', exp = T, cp.rm = F, mode = 'lapply', wrap = F)
	rngs.list = lapply(nms, function(nms)as.matrix(rngs[,nms]))
	CE$dss$set.attr('TT.rngs', val = rngs.list, exp = T, all = F)		
	return(rngs)
}
.prvmthd.bld1_thetas.calEnv <- function (CE) {
	theta = lapply(CE$.get.private('theta.nms')(), function(nm)uvrv.beta$new(name = nm, shape1 = 1, shape2 = 1))
	theta = r6.list$new(name = paste0(CE$name, '.theta'), objs = theta, cl = 'uvrv')
	CE$.set.private('.theta', val = theta)
	invisible()
}		
.prvmthd.bld2_thetas.calEnv <- function (CE) {
	.prvmthd.bld1_thetas.calEnv(CE)
	TT = CE$rd$get.attr('X', exp = T, cp.rm = T, wrap = F, mode = 'lapply')
	nms = CE$.get.private('theta.nms')()
	TT = lapply(nms, function(nm)na.omit(unlist(lapply(TT, function(x)if(nm %in% colnames(x)){return(x[,nm])}else{return(NA)}))))
	theta = CE$theta()$expand(cp.rm = T)
	ANS = lapply(1:length(theta), function(i)theta[[i]]$update(pars = TT[[i]], lower = rep(0.000001, 2)))	
	theta = r6.list$new(name = paste0(CE$name, '.theta'), objs = theta, cl = 'uvrv')
	CE$.set.private('.theta', val = theta)
	invisible()
}	
.mthd.cal_res.calEnv <- function (CE, mode, ...) {
	res.fun = getFromNamespace(paste0('..res_', mode, '.calEnv'), ns = .NSNAME)
	res.fun(CE, ...)	
}
..res_summary.calEnv <- function (CE, gof) {
	#_DOC_
	#Retunrs a summary of the calibration results consisting of statistics about calibration parameters
	#and comparison between GOF before and after calibration.
	#_MAIN_
	if (missing(gof)) gof = rmse
	theta.stats = ..res_theta.calEnv(CE)
	GOF.prior = ..res_gof.calEnv(CE, mdl = 'sim', gof = gof)
	GOF.post = ..res_gof.calEnv(CE, mdl = 'cals', gof = gof)
	GOF = cbind(GOF.prior, GOF.post)
	return(list('CALIBRATION_RESULTS' = theta.stats, 'CALIBRATED_MODEL_GOF' = GOF))
}
..res_theta.calEnv <- function (CE) {
	#_DOC_
	#Returns estimates and qunatiles from the posterior distribution of the calibration parameters.
	#_MAIN_
	#retrieves calibration parameters ranges
	theta.nms = CE$cals$theta$get.attr('name', cp.rm = T, exp = T, wrap = F, mode = 'sapply')
	theta.rngs = as.matrix(CE$theta('rngs')[,theta.nms])
	Q = CE$cal.mcmc$stat(s = hdi.mcmc, smp = F)[,theta.nms]
	Q = normalize(Q, MAXS = theta.rngs[2,], MINS = theta.rngs[1,], inv = T)				
	MAP = matrix(CE$cal.mcmc$stat(s = hsm, bw = 0.5)[theta.nms], nrow = 1)						
	MAP = normalize(MAP, MAXS = theta.rngs[2,], MINS = theta.rngs[1,], inv = T)						
	#creates the result table
	ANS = data.frame(theta.nms, t(MAP), t(Q))
	rownames(ANS) = NULL
	names(ANS) = c('PARAMETER', 'ESTIMATE', 'LOWER', 'UPPER') 
	return(ANS)
}
..res_thetaPlot.calEnv <- function (CE) {
	tt.nms = CE$cals$theta$get.attr('name', cp.rm = T)
	Z = CE$cal.mcmc$Z[,tt.nms, drop = F]
	rngs = CE$theta('rngs')[,tt.nms, drop = F]
	Z = normalize(Z, MAXS = rngs[2,], MINS = rngs[1,], inv = T)
	calibro.pairs(Z)
}
..res_predict.calEnv <- function (CE, n) {
	#_DOC_
	#Calls the predict methods of each datasets, which return the predictions for the input in Z.star.
	#_ARGUMENTS_
	#mdl: which model? ('sim' for simulations, 'mdls' for training models, 'cals' for calibrations models)
	#Z.star: list containing the input matrices
	#n: size of the sample (in case you want to calculate the quantiles and confidence intervals).
	#_MAIN_
	return(CE$dss$exe.mthd('predict', mdl = 'cals', Z.star = NULL, n = n, exp = T, cp.rm = T, wrap = F, mode = 'lapply'))
}
..res_gof.calEnv <- function (CE, mdl, gof) {
	#_DOC_
	#Claas the gof methods for each dataset, which returns the wanted gof for the given model.
	#_ARGUMENTS_
	#mdl: which model? ('sim' for simulations, 'mdls' for training models, 'cals' for calibrations models)
	#gof: which gof? (currently only rmse is available)
	#_MAIN_
	CE$cal.mcmc$set.maps()
	ANS = CE$dss$exe.mthd('gof', mdl = mdl, gof = gof, exp = T, cp.rm = T, wrap = F, mode = 'lapply')
	cals = CE$.get.private('.cals')
	cals$maps = NULL
	ANS = t(as.data.frame(ANS))
	colnames(ANS) = mdl
	return(ANS)
}	
..gen.res_list.calEnv <- function (CE, out) {
	#_DOC_
	#Generates a list with the required results.
	#_ARGUMENTS_
	#out: outputs to include in the list (sa, cal, train, ret).
	#_MAIN_
	ANS = list()
	if ('sa' %in% out) { 
		ANS[['SENSITIVITY_ANALYSIS']] = lapply(CE$sa, function(x) {
			ANS = as.data.frame(x$global$S)
			ANS = cbind(rownames(x$global$S), ANS)
			rownames(ANS) = NULL
			colnames(ANS) = c('PARAMETER', colnames(x$global$S))
			return(ANS)
		})
	}
	if ('ret' %in% out) ANS[['FACTOR_RETENTION']] = lapply(CE$ret, function(x) {
		ANS = summary.ans.ng.screening(x)
		ANS = cbind(rownames(ANS), ANS)
		rownames(ANS) = NULL
		colnames(ANS) = c('PARAMETER', colnames(ANS)[-1])
		return(ANS)
	})
	if ('train' %in% out) {
		ANS[['TRAININIG_GOF']] = CE$train.gof('Rscore3')
		ANS[['TRAININIG_GOF']] = as.data.frame(t(ANS[['TRAININIG_GOF']]))
	}	
	if ('cal' %in% out) {
		ANS = c(ANS, CE$cal.res(gof = 'rmse'))
		ANS[['CALIBRATED_MODEL_GOF']] = as.data.frame(ANS[['CALIBRATED_MODEL_GOF']])
		ANS[['CALIBRATED_MODEL_GOF']] = cbind(rownames(ANS[['CALIBRATED_MODEL_GOF']]), ANS[['CALIBRATED_MODEL_GOF']])
		rownames(ANS[['CALIBRATED_MODEL_GOF']]) = NULL
		colnames(ANS[['CALIBRATED_MODEL_GOF']]) = c('DATASET', 'BEFORE', 'AFTER')
	}
	ANS = c('CALIBRO' = calibro_version, 'CALIBRATION' = CE$name, ANS)
	return(ANS)	
	return(ANS)	
}

.mthd.genReport_json.calEnv <- function (CE, out, wrt) {
	#_DOC_
	#Generates a report of the calibration in JSON format.
	#_ARGUMENTS_
	#out: outputs to include in the report
	#wrt = write to file?
	#_MAIN_
	require(jsonlite, quietly = T)
	ANS = ..gen.res_list.calEnv(CE, out)
	ANS = toJSON(ANS, pretty = T, auto_unbox = T)
	if (wrt) {
		write(ANS, 'calibro_report.json')
	} else {
		return(ANS)
	}
}

.mthd.genReport_pdf.calEnv <- function (CE, out, wrt) {
	#_DOC_
	#Generates a report of the calibration in pdf format.
	#_ARGUMENTS_
	#out: outputs to include in the report.
	#wrt = write to file?
	#_MAIN_
	require(knitr, quietly = T)
	ANS = ..gen.res_list.calEnv(CE, out)
	sf = system.file('calibro_report.Rnw', package = .NSNAME)
	knit2pdf(input = sf)
}
