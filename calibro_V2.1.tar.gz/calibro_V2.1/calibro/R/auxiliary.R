#  This file is part of Calibro.
#
#  Calibro is free software; you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation; either version 2 of the License, or
#  (at your option) any later version.
#  
#  Calibro is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#  
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software
#  Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
#  MA 02110-1301, USA.

#* AUXILIARY FUNCTIONS

#** TO MODIFY ARRAYS AND AMTRICES

split.mat <- function (X, L, last = T, dms = 2) {
	#_DOC_
	#Splits the colums of a matrix ('X') into vectors of length 'L' and bind them together into 
	#an array. If the number of rows of 'X' is not multiple of 'L' the needed number of elements is discarded 
	#from the beginning or the end of each row of 'X' accodring to the argument 'last'.
	#_ARGUMENTS_
	#X: Matrix to split.
	#L: length of the split vector.
	#last: if TRUE points are discarded from the end of the rows and vice versa.
	#dms: number of dimensions of the  resulting matrix. If 2 a matrix is returned, if 3 an array is returned.
	#_MAIN_
	X = as.matrix(X)	#makes sure that X is a matrix
	N = nrow(X)			#period length	
	M = floor(N/L)		#number of periods
	D = N - M * L		#number of discarded points
	if (D > 0) {
		if (last) {
			X = as.matrix(X[1:(N-D),])
			position = 'end'
		} else {
			X = as.matrix(X[-(1:D),])
			position = 'beginning'
		}
		warning(paste('the total dimension of the data sets is not multiple of the specified time: ', 
			D, 'points per column will be discarded'))		
	}
	if (dms == 2) {
			dim(X) = c(L, M*ncol(X))
	} else if (dms == 3) {
			dim(X) = c(L, M, ncol(X))
	} else {
			stop('dms can be 2 or 3')
	}
	return(X)
} 
split.mat.list <- function (X, L, nm = NULL) {
	#_DOC_
	#Splits the colums of a matrix ('X') into vectors of length 'L' and create a list. 
	#If the number of rows of 'X' is not multiple of 'L' the last chop will be adjusted accordingly. 
	#_ARGUMENTS_
	#X: a matrix
	#L: splitting length
	#_MAIN_
	X = as.matrix(X)
	M = nrow(X)
	if (length(L) > 1) {
		b = cumsum(L)
		a = b - L + 1
	} else {
		b = seq(L, M, L)
		a = b - L + 1
		if (b[length(b)] != M) b[length(b)] = M
	}
	ANS = lapply(1:length(a), function(i)as.matrix(X[a[i]:b[i],]))
	if (!is.null(nm)) names(ANS) = paste0(nm, 1:length(ANS))
	return(ANS)
}
symm.indexes <- function (a, b) {
	#_DOC_
	#Returns the indexes of the lower tringular part conprehensive of diagonal of the  that is
	#within X[a,b]
	#_ARGUMENTS_
	#a, b: row and columns indexes
	#_MAIN_
	ANS = parallel::mclapply(b, function(j)sapply(a[a<=j], function(i)c(i, j)))	#multicore
#	ANS = sapply(b, function(j)sapply(a[a<=j], function(i)c(i, j)))	#single core
	return(t(cbind.list(ANS)))	#multicore
#	return(ANS)
}	

split.na = function (x, indx = F) {
	#_DOC_
	#Splits a vector according to the NAs that it contais.
	#_ARGUMENTS_
	#x: vector
	#_MAIN_
	noNa = which(!is.na(x))
	breaks = which(diff(noNa) > 1)
	breaks = c(breaks, length(noNa))
	breaks = c(breaks[1], diff(breaks))
	nonas = split.mat.list(noNa, breaks)
	if (!indx) nonas = lapply(nonas, function(i)x[i])
	return(nonas)
}
rbind.list <- function (ml) {
	#_DOC_
	#rbind the matrices in the list 'ml'
	#_ARGUMENTS_
	#ml: list of matrices
	#_MAIN_
	return(do.call('rbind', ml))
}
cbind.list <- function (ml) {
	#_DOC_
	#cbind the matrix in the list 'ml'
	#_ARGUMENTS_
	#ml: list of matrices
	#_MAIN_
	return(do.call('cbind', ml))
}

blockDiag.list <- function (A) {
	m = sapply(A, nrow)
	b1 = cumsum(m)
	a1 = b1 - m + 1
	n = sapply(A, ncol)
	b2 = cumsum(n)
	a2 = b2 - n + 1
	D = matrix(0, nrow = sum(m), ncol = sum(n))
	for (i in 1:length(A)) D[a1[i]:b1[i],a2[i]:b2[i]] = A[[i]]
	return(D)
}  

#** TO MODIFY LISTS

list.null.rm <- function (ls) {
	#_DOC_
	#Removes NULL elemetns from a list (ls)
	#_MAIN_
	return(ls[which(!(sapply(ls, is.null)))])
}

#** TO READ FROM FILES

read.list.csv <- function (csv.ls, as.mat = TRUE, hd = TRUE) {
	#_DOC_
	#Reads the csv files in 'csv.ls' and returna list of data frames.
	#If 'as.mat' = T the data frames are converted to matrices.
	#If 'hd' = T it assumes that the files contain a header.
	#_MAIN_
	if (as.mat) {
		fun = function (x) return(as.matrix(read.csv(x, header = hd)))
	} else {
		fun = function (x) return(read.csv(x, header = hd))
	}
	list.csv = lapply(csv.ls, fun)
	names(list.csv) = sapply(strsplit(csv.ls, '.', fixed = T), function(x)x[1])
	return(list.csv)
}

#* PLOTTING

plotWerror <- function (y.avg, y.lw, y.up, ...) {
	#_DOC_
	#Scatter plot with error bars
	#_MAIN_
	args = list(...)
	args[['y']] = y.avg
	if (is.null(args[['x']])) args[['x']] = 1:length(y.avg)
	if (is.null(args[['ylim']])) args[['ylim']] = range(c(y.lw*0.95, y.up*1.05))
	do.call(plot, args)
	# hack: we draw arrows but with very special "arrowheads"
	arrows(args[['x']], y.lw, args[['x']], y.up, length=0.05, angle=90, code=3)
}	
panel.hist <- function(x, ...) {
	#_DOC_
	#Called by calibro.pairs. Plot histograms on the diagonal panel
	#_MAIN_
	 usr <- par('usr'); on.exit(par(usr))
	 par(usr = c(usr[1:2], 0, 1.5) )
	 h <- hist(x, plot = FALSE)
	 breaks <- h$breaks; nB <- length(breaks)
	 y <- h$counts; y <- y/max(y)
	 rect(breaks[-nB], 0, breaks[-1], y, col = 'darkgrey', ...)
}
calibro.pairs <- function (X, ...) {
	#_DOC_
	#Calibro customised pairs plot.
	#_ARGUMENTS_
	#X: matrix of data.
	#_MAIN_
	if (ncol(X) < 2) {
		hist(X, xlab = colnames(X), ...)
	} else {
		pairs(X, 
			diag.panel =  panel.hist, 
			upper.panel = panel.smooth,
			lower.panel = function(x, y){DNS = kde2d(x, y, n = 125); image(DNS, add = T); contour(DNS, add = T)},
			...
		)
	}
}
	
	
	
	
	
	
