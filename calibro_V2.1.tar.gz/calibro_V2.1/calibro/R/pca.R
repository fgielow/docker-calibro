#PRINCIPAL COMPONENENT ANALYSIS

#  This file is part of Calibro.
#
#  Calibro is free software; you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation; either version 2 of the License, or
#  (at your option) any later version.
#  
#  Calibro is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#  
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software
#  Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
#  MA 02110-1301, USA.

#* pca CLASS
pca = R6Class('pca',
	#_DOC_
	#This class implements PCA and methods appicable to its outputs to perform sensitivity analysis
	#factor retention and modelling.
	inherit = calibro.obj,
	#** public
	public = list(
		#*** attributes
		Y.star.se = NULL,
		obs.cnf = NULL,
		#*** methods
		initialize = function (name, Y, X = NULL, BC = NULL, C = F, S = F, mu = T) { 
			#_DOC_
			#Initialises the PCA obj and actually perform the decomposition
			#Argumantes:
			#name: name/description (short) for the PCA object
			#Y: n x m matrix having as columns the data to decompose according to PCA
			#X: m x  n matrix hving as rows unidimensional variables that are correlated with the time series (columns) of Y. For example the input of a regeession model.
			#C: if T Y is centred so that each row as mean 0
			#S: if T Y is scaled so that each row as standard deviation 1
			#mu: if T each column of Y is centred. In this case the first pc represents the mean of each simulation
			#_MAIN_
			self$name = name
			private$.Y = Y
			private$.BC = BC 
			private$.X = X
			private$pca.vec(Y, C, S, mu)
			private$ret.no0s()	#retain only non zeros
		},
		#**** predict
		predict = function (mdl, Z.star = NULL, n = 0) {
			#_DOC_
			#Makes predictions for the test locations in Z.star
			#_ARGUMENTS_
			#mdl: character indicating which model to use (mdl or cal)
			#Z.star: list of matrices containing the inputs for the test locations.
			#n: size of the sample.
			#_MAIN_
			.mthd.predict.pca(self, mdl,  Z.star, n)
		},
		summary = function () {
			.mthd.summary.pca(self)		
		}, 
		plot =  function (which = NULL, ...) {
			.mthd.plot.pca(self, which, ...)
		},
		print =  function () {
			.mthd.print.pca(self)
		}
	),
	#** active
	active = list(
		#*** eiVals
		eiVals = function () {
			#_DOC_
			#Returns the eigen values of the reteined principal componenets.
			#_MAIN_
			.mthd.get_eiVals.pca(self)
		},
		K = function (x) {
			#_DOC_
			#Returns the basis of the reteined principal componenets.
			#_MAIN_
			if (missing(x)) {.mthd.get_K.pca(self)} else {}
		},
		W = function (x) {
			#_DOC_
			#Returns the coefficients of the reteined principal componenets
			if (missing(x)) {.mthd.get_W.pca(self)} else {}
		},
		D = function (x) {
			#_DOC_
			#Returns the singular values of the reteined principal compoenents
			#_MAIN_
			if (missing(x)) {.mthd.get_D.pca(self)} else {}
		},
		NRM = function (val) {
			#_DOC_
			#Sets/returns the kind of normalisation adopted.
			#'w' => coefficent are orthonormal, 'k' => bases are orthonomal, 'h' => Higdon normalisation.
			if(missing(val)){return(private$.NRM)}else{.actmthd.set_NRM.pca(self, val)}
		},
		Y = function (x) {
			#_DOC_
			#Returns the dataset.
			#_MAIN_
			if (missing(x)) {return(private$.Y)} else {}
		},
		X = function (x) {
			#_DOC_
			#Returns the variable covariate with the dataset.
			#_MAIN_
			if (missing(x)) {return(private$.X)} else {}
		},
		C = function (x) {
			#_DOC_
			#Returns the centers adopted for the row of Y.
			#_MAIN_
			if (missing(x)) {return(private$.C)} else {}
		},
		S = function (x) {
			#_DOC_
			#Returns the scales adopted for the row of Y.
			#_MAIN_
			if (missing(x)) {return(private$.S)} else {}
		},
		mu = function (x) {
			#_DOC_
			#Returns the flag mu: T => columns were centered and mean componenet attached at the beginning of K, W and D
			#_MAIN_
			if (missing(x)) {return(private$.mu)} else {}
		}, 
		sa = function (mthd) {
			#_DOC_
			#Returns/performs sensitivity analysis.
			#mthd: sensitivity analysis method.
			#_MAIN_
			if(missing(mthd)){.actmthd.get_sa.pca(self)}else{.actmthd.set.sa.pca(self, mthd)}
		},
		ret = function (pars) {
			#_DOC_
			#Returns/performs factor retention.
			#_MAIN_
			#pars: list of parameter to adopt for factor retention.
			if(missing(pars)){return(private$.ret)}else{.actmthd.set_ret.pca(self, pars)}
		},
		mdls =  function (mdl) {
			#_DOC_
			#Returns/builds the models for each retained principal componenet.
			#mdl: kind of model to build.
			#_MAIN_
			if(missing(mdl)){return(private$.mdls)}else{.actmthd.bld_mdl.pca(self, mdl)}
		},
		train =  function (pars) {
			if (missing(pars)) {return(private$.train)} else {.actmthd.wrp(self, pars, .actmthd.train.pca)}
		},
		theta = function (vars) {
			#_DOC_
			#Returns/sets the calibration prameters for each principal componenet.
			#_ARGUMENTS_
			#vars: r6.list of uvrv representign the calibration parameters.
			#_MAIN_
			if(missing(vars)){return(private$.theta)}else{private$.theta = vars}
		},
		Y.star = function (Y) {
			#_DOC_
			#Sets/returns the calibration targets.
			#_MAIN_
			if(missing(Y)){return(private$.Y.star)}else{private$.Y.star = Y}
		},
		cals = function (mdl) {
			#_DOC_
			#Returns/builds the calibrators for each retained principal componenets.
			#_MAIN_
			if(missing(mdl)){return(private$.cals)}else{.actmthd.wrp(self, mdl, .actmthd.set_cals.pca)}
		},
		BC = function (x) {
			#_DOC_
			#Returns the boundary conditions.
			#_MAIN_
			if (missing(x)) {return(private$.BC)} else {}
		}
	),
	#** private
	private = list(
		#*** attributes
		.Y = NULL,		#original
		.X = NULL, 		#correlated unidimensional variables
		.BC = NULL,		#boundary conditions
		.K = NULL,		#bases
		.W = NULL,		#coefficients
		.D = NULL,		#singular values
		.C = NULL,		#center
		.S = NULL,		#scale
		.mu = NULL,		#flag. If T => columns are centred and the mean is attached as first column of K and W
		.train = NULL,	#'opt' object for the training of the models
		.pc.nms = NULL,	#principal componenets names
		.NRM = 'w',		#normalisation adopted
		.ret = list(),	#retained factors	
		.sa = list(),	#senstivity analysis results
		.theta = NULL,	#calibration parameters uvrv
		.Y.star = NULL,	#target observations
		.mdls = NULL,	#models
		.cals = NULL,	#calibrators
		N = NULL,		#total number of principal componenets
		#*** methods
		pca.vec = function (Y, C, S, mu) {
			#_DOC_
			#Vectorial PCA
			#_ARGUMENTS_
			#Y: dataset
			#C: if T => centers the row to 0
			#S: if T => scales the row to 1
			#mu: if T => centers the columns to 0
			#_MAIN_
			.prvmthd.pca.vec.pca(self, Y, C, S, mu)
		},
		sa.sobolSmthSpl = function () {
			#_DOC_
			#Sensitivity analysis through the function sobolSmthSpl.
			#_MAIN_
			.prvmthd.sobolSmthSpl.pca(self)
		},
		ret.no0s = function () {
			#_DOC_
			#Retains only the principal componenets higher than max(D) * eps * max(dim(Y))
			#_MAIN_
			.prvmthd.ret.no0s.pca(self)
		},
		ret.ths = function (th) {
			#_DOC_
			#Threshold retention criterion. Reteins all pricipal componenets explaind at leas ths*total_variance.
			#_ARGUMENTS_
			#th: threshold value. Fraction of variance within [0,1]
			#_MAIN_
			.prvmthd.ret.ths.pca(self, th)
		},
		ret.ng.screening = function () {
			#_DOC_
			#Reteins principal componenets according to ng-screen algorithm.
			#Also the covariate variables are reteined.
			#_MAIN_
			.prvmthd.ret.ng_screening.pca(self)
		},
		#***** ret.X.default
		ret.X.default = function () {
			#_DOC_ @TODO make function
			#Sets the fields of ret relative to X to default values.
			#_MAIN_
			private$.ret[['pars.pc']] = lapply(private$.ret[['pcs']], function(i)return(1:ncol(private$.X)))
			private$.ret[['pars']] = 1:ncol(private$.X)
			private$.ret[['Si.ret']] = rep(NA, length(private$.ret[['pcs']]))
			private$.ret[['Si.dsc']] = rep(NA, length(private$.ret[['pcs']]))
			private$.ret[['shp']] = update.shp(shp = 1, Y = private$.Y, K = self$K)
			private$.ret[['rate']] = update.rate.ort3(rt = .intrf.env_par__get('tol')	* ssq(self$D), D = private$.D[-private$.ret[['pcs']]])
		}
	)
)
.mthd.predict.pca <- function (PCA, mdl, Z.star = NULL, n = 0) {
	#_DOC_
	#Uses the gpr model built on the pcs to provide predictions
	#Arguements:
	#mdl: which model? ('mdls' for training, 'cals' for calibration')
	#Z.star: list of input matrices
	#n: sample size (in case you need statistics like confidence intervals)
	#_MAIN_
	mdls = PCA$.get.private(paste0('.', mdl))
	predict = mdls$exe.mthd('predict', Z.star = Z.star, exp = T, cp.rm = T, wrap = F, mode = 'lapply')
	pMu = PCA$K %*% t(cbind.list(lapply(predict, function(x)x$pMu))) * PCA$S + PCA$C
	if (n > 0) {
		SMP = PCA$K %*% t(sapply(predict, function(x) as.vector(mvrnorm(n = n, mu = x$pMu, Sigma = x$pCm)))) * PCA$S + PCA$C
	} else {
		SMP = NULL
	}
	return(list('pMu' = pMu, 'SMP' = SMP))
}
.mthd.plot.pca <- function (PCA, which, ...) {
	#_DOC_
	#Plots the rpiuncipla componenets.
	#_ARGUMENTS_
	#which: indexes of the principal componenets to plot
	#...: additional arguments for the plot function
	#_MAIN_
	K = PCA$K
	mu = rep(0, nrow(K))
	if (PCA$mu) {
		mu = K[,1]
		K = K[,-1]
	}
	yl = c(max(K) + max(mu), -max(K) + max(mu))
	plot(mu, ty = 'l', lwd = 2, ylim = yl, ...)
	if (is.null(which)) which = 1:ncol(K)
	for (i in which) {
		points(pch = '+', mu + K[,i], col = 4)
		points(pch = '-', mu - K[,i], col = 2)
	}
	
}
.mthd.summary.pca <- function (PCA) {
	#_DOC_
	#Prints a summary of principal componenet analysis object.
	#_MAIN_
	ANS = list()
	ANS[['name']] = PCA$name
	ANS[['K']] = summary(PCA$K)
	ANS[['W']] = summary(PCA$W)
	ANS[['V']] = PCA$eiVals /  sum(PCA$.get.private('.D')** 2 / PCA$.get.private('N'))
	class(ANS) = 'summary.pca'
	return(ANS)
}
.mthd.print.pca <- function (PCA) {
	#_DOC_
	#Prints the principal componenent analysis object.
	#_MAIN_
	print(PCA$summary())	
}
print.summary.pca <- function (smpca) {
	#_DOC_
	#Prints the summary of the principal componenet object.
	#_MAIN_
	cat(paste0('\nPCA: ', smpca$name, '\n'), sep = '\n')
	cat('\nStatistics on principal componenet bases:\n', sep = '\n')
	print(smpca$K)		
	cat('\n\nStatistics on principal componenet coefficient:\n', sep = '\n')
	print(smpca$W)		
	cat('\n\nPrincipal componenet relative variances:\n', sep = '\n')
	print(smpca$V)		
	
}
.mthd.get_eiVals.pca <- function (PCA) {
	#_DOC_
	#Retrieves the eigen values for the reteined principal componenets.
	#_MAIN_
	r = PCA$.get.private('.ret')[['pcs']]
	ev = PCA$.get.private('.D')[r] ** 2 / PCA$.get.private('N')
	names(ev) = PCA$.get.private('.pc.nms')[r]
	return(ev)
}
.mthd.get_K.pca <- function (PCA) {
	#_DOC_
	#Returns the principal basis vectors as columns of a matrix.
	#_ARGUMENTS_:
	#NRM: if T => the vectors are normalised: t(k) %*% k = 1
	#_MAIN_
	r = PCA$.get.private('.ret')[['pcs']]
	K = as.matrix(PCA$.get.private('.K')[,r])
	if (PCA$NRM == 'w') {
		K = sapply(1:ncol(K), function(i)K[,i] * PCA$.get.private('.D')[r[i]])
	} else if (PCA$NRM == 'k') {
		#pass
	} else if (PCA$NRM == 'h') {
		K = sapply(1:ncol(K), function(i)K[,i] * PCA$.get.private('.D')[r[i]] / sqrt(PCA$.get.private('N')))
	}
	colnames(K) = PCA$.get.private('.pc.nms')[r]
	return(K)
}
.mthd.get_W.pca <- function (PCA) {
	#_DOC_
	#Returns the coefficients of the principal basis vectors as column of a matrix (i.e. w_1 coefficient of k_1 is in the column 1).
	#_ARGUMENTS_:
	#NRM: if T => the vectors are normalised: t(w_i) %*% w_i = 1
	#_MAIN_
	r = PCA$.get.private('.ret')[['pcs']]
	W = as.matrix(PCA$.get.private('.W')[,r])
	if (PCA$NRM == 'w') {
		#pass
	} else if (PCA$NRM == 'k') {
		W = sapply(1:ncol(W), function(i)W[,i] * PCA$.get.private('.D')[r[i]])
	} else if (PCA$NRM == 'h') {
		W = W * sqrt(PCA$.get.private('N'))
	} else {
		stop('unknown NRM.')
	}
	colnames(W) = PCA$.get.private('.pc.nms')[r]
	return(W)
}
.mthd.get_D.pca <- function (PCA) {
	#_DOC_
	#Returns the sqrt of inner products of the basis vectors (t(k_i)%*%k_i). 
	#_MAIN_
	r = PCA$.get.private('.ret')[['pcs']]
	if (PCA$NRM == 'h') {
		D = PCA$.get.private('.D')[r] / sqrt(PCA$.get.private('N'))
	} else if (PCA$NRM == 'w') {
		D = PCA$.get.private('.D')[r]
	} else if (PCA$NRM == 'k') {
		D = rep(1, length(r))
	}
	names(D) = PCA$.get.private('.pc.nms')[r]
	return(D)
}
.actmthd.set_NRM.pca <- function (PCA, val) {
	#_DOC_
	#Sets the kind of normalisation used of the principal componenets.
	#_ARGUMENTS_
	#val: kind of normalisation ('w' => all variance on K, 'k' => all variance on W, 'h' => K*D/sqrt(N) W/sqrt(N))
	#_MAIN_
	if (val %in% c('w', 'k', 'h')) {
		private$.NRM = val
	} else {
		stop('unknown normalisation!!!')
	}
}
.actmthd.get_sa.pca <- function (PCA) {
	#_DOC_
	#Retrieves the sensitivity analysis results.
	#_MAIN_
	r = PCA$.get.private('.ret')[['pcs']]
	return(list('global' = PCA$.get.private('.sa')[['global']], 'pcs' = PCA$.get.private('.sa')[['pcs']][r]))
}
.actmthd.set.sa.pca <- function (PCA, mthd) {
	#_DOC_
	#Sets and perform sensitivity analysis.
	#_ARGUMENTS_
	#mthd: sensitivity analysis method
	#_MAIN_
	PCA$.get.private(paste0('sa.', mthd))()
	invisible()
}
.actmthd.set_ret.pca <- function (PCA, pars) {
	#_DOC_
	#Sets and perform factor retention.
	#_ARGUMENTS_
	#pars: parameters for the method
	#_MAIN_
	if (is.null(pars)) {
		PCA$.get.private('ret.no0s')()
	} else {
		ret = paste0('ret.', pars[['mthd']])
		pars[['mthd']] = NULL
		do.call(PCA$.get.private(ret), pars)
	}
	invisible()
}
.prvmthd.pca.vec.pca <- function (PCA, Y, C, S, mu) {
	#_DOC_
	#Performs PCA of the matrix Y according to SVD decomposition.
	#_ARGUMENTS_
	#name: name of the dataset
	#Y: matrix on which to perform PCA (ncol(X) > 3)
	#C: TRUE or vector => rows of Y are centred (mean = 0)
	#S: TRUE or vector => rows of Y are scaled (sd = 1)
	#_MAIN_
	if (ncol(Y) < 2) stop('ncol(X) < 2')
	N = ncol(Y)
	#row centring ans caling
	if (C || S) {
		Y = scaleT(Y, C = C, S = S)
	}
	if (C) {
		N = N - 1
		PCA$.set.private('.C', val = attr(Y, 'scaled:center'))
		attr(Y, 'scaled:center') = NULL
	} else {
		PCA$.set.private('.C', val = rep(0, nrow(Y)))
	}
	if (S) {
		PCA$.set.private('.S', val = attr(Y, 'scaled:scale'))
		attr(Y, 'scaled:scale') = NULL
	} else {
		PCA$.set.private('.S', val = rep(1, nrow(Y)))
	}
	D = c()
	K = c()
	W = c()
	pc.nms = c()
	if (mu) {	#column centring
		Y = scale(Y, center = T, scale = F)
		k.m = rep(1, nrow(Y))/sqrt(nrow(Y))
		w.m = attr(Y, 'scaled:center')
		attr(Y, 'scaled:center') = NULL
		d.m = nrm(w.m)
		w.m = w.m / d.m
		d.m = d.m * sqrt(nrow(Y))
		D = d.m
		K = as.matrix(k.m)
		W = as.matrix(w.m)
		pc.nms = 'pc.mu'
		PCA$.set.private('.mu', val = mu)
	}
	
	SVD = svd(Y)
	D = c(D, SVD$d)
	K  = cbind(K, SVD$u)
	W = cbind(W, SVD$v)
	pc.nms = c(pc.nms, paste0('pc', 1:N))
	#~store
	PCA$.set.private('.D', val =  D)
	PCA$.set.private('.K', val = K)
	PCA$.set.private('.W', val = W)
	PCA$.set.private('.pc.nms', val = pc.nms)
	PCA$.set.private('N', val = N)
	#~
}
.prvmthd.sobolSmthSpl.pca <- function (PCA) {
	#_DOC_
	#Applies Hodrick–Prescott filter to each PC and calculate the variance weighted Si indexes.
	#_MAIN_
	#~performs SA foe each PC
	SA = lapply(1:ncol(PCA$W), function(i)sobolSmthSpl(PCA$W[,i], PCA$X))
	SA.pcs = lapply(SA, function(x)x[['S']])
	SA.fi = lapply(SA, function(x)x[['SMTH']])
	
	names(SA) = c(paste0('pc', 1:ncol(PCA$W)))
	#~
	#~Calculates the global Si by variace weighted average
	w = PCA$eiVals / sum(PCA$eiVals)	#weights for each PC 
	SA.global = 0
	for (i in 1:length(SA.pcs)) SA.global = SA.global + SA.pcs[[i]] * w[i]
	colnames(SA.global) = c('Si', 'se', 'q0.05')
	#~
	#~saves list with results
	ANS = list(S = SA.global)
	class(ANS) = 'sobolSmthSpl'
	SMTHyin = lapply(1:ncol(PCA$X), function(j) {
		apply(sapply(1:length(SA.fi), function(i)SA.fi[[i]][[j]][['yin']] * PCA$D[i]**2), 1, sum) / sum(PCA$D**2)
	})
	SMTHy =  lapply(1:ncol(PCA$X), function(j) { 
		apply(sapply(1:length(SA.fi), function(i)SA.fi[[i]][[j]][['y']] * PCA$D[i]**2), 1, sum) / sum(PCA$D**2)
	})
	ANS[['SMTH']] = list()
	for (i in 1:ncol(PCA$X)) {
		ANS[['SMTH']][[i]] = list()
		ANS[['SMTH']][[i]][['yin']] = SMTHyin[[i]]
		ANS[['SMTH']][[i]][['y']] = SMTHy[[i]]
		ANS[['SMTH']][[i]][['x']] = sort(PCA$X[,i])
	}
	names(ANS[['SMTH']]) = colnames(PCA$X)
	sa.list = list('global' = ANS, 'pcs' = SA)
	PCA$.set.private('.sa', val = sa.list)
	#~
} 
.prvmthd.ret.no0s.pca <- function (PCA) {
	#_DOC_
	#Retains all the non 0 principal componenets. Non 0 PCs are those having eigenvalue > than eps * max(eigenvalues).
	#It is the basic retention criterion and is applied by default when the object is initialised or self$ret = NULL.
	#_MAIN_ 
	ret.list = PCA$.get.private('.ret')
	D = PCA$.get.private('.D')
	t = D[ifelse(PCA$mu, 2, 1)] * .intrf.env_par__get('eps_dbl') * max(dim(PCA$Y))
	ret.list[['pcs']] = which(D > t) 
	PCA$.set.private('.ret', val = ret.list)
#	if (!is.null(PCA$X)) PCA$.get.private('ret.X.default')()
}
.prvmthd.ret.k1.pca <- function (PCA) {
	#_DOC_
	#k1 criterion retain all the PCs having eigenvalues > 1.
	#_MAIN_
	ret.list = PCA$.get.private('.ret')
	ret.list[['pcs']] = which(PCA$eiVals > 1)
	PCA$.set.private('.ret', val = ret.list)
	if (!is.null(PCA$X)) PCA$.get.private('ret.X.default')()
}
.prvmthd.ret.num.pca = function (PCA, n) {
	#_DOC_
	#Retains the PCs corresponding to the indexes provided (n).
	#_ARGUMENTS_:
	#n: vector of indexes
	#_MAIN_
	ret.list = PCA$.get.private('.ret')
	ret.list[['pcs']] = n
	if (!is.null(PCA$X)) PCA$.get.private('ret.X.default')()
}
.prvmthd.ret.ths.pca <- function (PCA, t) {
	#_DOC_
	#Retains all the PCs up to a certain fraction of the total data variance (t).
	#_ARGUMENTS_:
	#t: fraction of data varaince (usually 0.90 or >)
	#_MAIN_
	ev = PCA$eiVals
	if (PCA$mu) ev = ev[-1]
	r = which(cumsum(ev)/sum(ev) <= t)
	if (length(r) == 0) r = 1
	if (PCA$mu) r = c(1, r + 1)
	ret.list = PCA$.get.private('.ret')
	names(r) = colnames(PCA$K)[r]
	ret.list[['pcs']] = r
	pars.pc = lapply(r, function(i) 1:ncol(PCA$X))
	for (i in 1:length(pars.pc)) names(pars.pc[[i]]) = colnames(PCA$X)
	ret.list[['pars.pc']] = pars.pc
	ret.list[['pars']] = 1:ncol(PCA$X)
	ret.list[['Si.ret']] = rep(1, length(r))
	ret.list[['Si.dsc']] = rep(0, length(r))
	names(ret.list[['pars']]) = colnames(PCA$X)		
	shp0 = 2
	rate0 = shp0 * .intrf.env_par__get('tol') * PCA$D[ifelse(PCA$mu, 2, 1)]**2	
	shp = update.shp(shp = shp0, Y = PCA$Y, K = PCA$K[,r])
	rate = update.rate.ort3(rt = rate0, D = PCA$D[-r])
	ret.list[['shp']] = shp
	ret.list[['rate']] = rate
	class(ret.list) = 'ans.ng.screening'
	PCA$.set.private('.ret', val = ret.list)
}	
.prvmthd.ret.ng_screening.pca <- function (PCA) {
	#_DOC_
	#Solves the strctural identifiability (identifiability of model paramters in the training model).
	#Depeding on the pcs and paramter considered the uncertainty (quantified by the variance = rt/shp) in the training model changes.
	#This function iteratively removes parameters according to the probabilty to identify them (PI) and conseq_dbuentely updates the 
	#rt and shp parameters, untill it finds a set up wherein all the retainined parametersa re identifiables (PI > 0.95)
	#_MAIN_
	PCA$ret = NULL
	W = PCA$W
	K = PCA$K
	D = PCA$D
	SA = lapply(PCA$.get.private('.sa')[['pcs']], function(x)x$S)
	#~calculates the initial probabilities to identify model parameters
	Si.ret = 1
	Si.dsc = 0												
	shp0 = 2
	rate0 = shp0 * .intrf.env_par__get('tol') * D[ifelse(PCA$mu, 2, 1)]**2	
	Si.min = rate0/shp0/ D**2 / apply(W, 2, var)			
	#~
	pcs = 1:length(SA)
	pars.pc = lapply(1:length(SA), function(i) return(NA))
	#~iterative process
	cnv = F
	while (!cnv) {
		#retains parameters and principal componenets
		pars.pc[pcs] = lapply(pcs, function(i)which(SA[[i]][,'q0.05'] > Si.min[i]))	#parameters retained per pc
		pcs = which(sapply(pars.pc, length) > 0)
		if (length(pcs) == 0) {
			warning(paste0('ng.screening failed for ', PCA$name, '. Adopting threshold approach.'))
			break
		}
		Si.ret = sapply(1:length(SA), 
			function(i) min(sum(SA[[i]][pars.pc[[i]],'Si']), .quasi1())	#fractions of variance due to considered main effects
		)	
		Si.dsc = sapply(1:length(SA), 
			function(i) max(sum(SA[[i]][-pars.pc[[i]],'Si']), .intrf.env_par__get('tol'))	#fractions of variance due to neglected main effects
		)	
		#updates shape and rate
		shp = update.shp(shp = shp0, Y = PCA$Y, K = K[,pcs])
		rate = update.rate.ort3(rt = rate0, D = D[-pcs])
		#updates Si.min and checks convergence
		Si.min = rate / (shp - 1) / D**2 / apply(W, 2, var) #+ sapply(1:ncol(W), function(i) min(1-Si.ret[i], Si.dsc[i]))
		cnv = all(unlist(lapply(pcs, function(i) SA[[i]][pars.pc[[i]],'q0.05'] > Si.min[i])))
	}
	if (length(pcs) > 0) {
		#store ideintifiability list in ds	
		ret.list = list()
		names(pcs) = PCA$.get.private('.pc.nms')[pcs]
		ret.list[['pcs']] = pcs
		ret.list[['pars']] = unique(unlist(pars.pc))
		ret.list[['pars.pc']] = pars.pc[pcs] 
		ret.list[['Si.ret']] = Si.ret[pcs] 
		ret.list[['Si.dsc']] = Si.dsc[pcs] 
		ret.list[['shp']] = shp
		ret.list[['rate']] = rate
		class(ret.list) = 'ans.ng.screening'
		PCA$.set.private('.ret', val = ret.list)
	} else {
		PCA$ret = NULL
		PCA$ret = list(mthd = 'ths', t = 0.99)
	}
}
summary.ans.ng.screening <- function (ongs) {
	#_DOC_
	#Prints a summary of the retention results.
	#_ARGUMENTS_
	#ongs: factor retention output.
	#_MAIN_
	ANS = matrix(0, nrow = length(ongs[['pars']]), ncol = length(ongs[['pcs']]))
	for (i in 1:nrow(ANS)) {
		for (j in 1:ncol(ANS)) {
			ANS[i,j] = ifelse(i %in% ongs[['pars.pc']][[j]], 'ret', 'drop')
		}
	}
	ANS = rbind(ANS, signif(ongs$Si.ret, 2))
	ANS = rbind(ANS, signif(ongs$Si.dsc, 2))
	rownames(ANS) = c(unique(c(unlist(sapply(ongs[['pars.pc']], names)))), 'Si_r', 'Si_d')
	colnames(ANS) = names(ongs[['pcs']])
	return(as.data.frame(ANS))
}
print.ans.ng.screening <- function (ongs) {
	#_DOC_
	#Prints the factor retention output.
	#_ARGUMENTS_
	#ongs: factor retention output.
	#_MAIN_
	print(summary.ans.ng.screening(ongs))
}
.actmthd.bld_mdl.pca <- function (PCA, mdl.type) {
	#_DOC_
	#Builds models for the reteined principal componenets.
	#_ARGUMENTS_
	#mdl.type: type of model.
	#_MAIN_
	shp = PCA$ret[['shp']]
	rt = PCA$ret[['rate']]
	bld.fun = getFromNamespace(paste0('..bld.', mdl.type), ns = .NSNAME)
	mdls = lapply(1:ncol(PCA$W), function (i) {
		mdl.nm = paste0('pc', PCA$ret[['pcs']][i])
		bld.fun(
			mdl.name = colnames(PCA$W)[i], 
			Y = PCA$W[,i,drop = F], 
			Z = PCA$X[,PCA$ret[['pars.pc']][[i]], drop = F],  
			shape = shp, 
			rate = rt/PCA$D[i]**2
		)
	})
	mdls = gprVec$new(name = paste0(PCA$name, '.gprs'), gprs = mdls)
	PCA$.set.private('.mdls', val = mdls)
	invisible()
}
.actmthd.train.pca <- function (PCA, pars) {
	#_DOC_
	#Trains the creted principal componenets models.
	#_ARGUMENTS_
	#pars: parameters for the training
	#_MAIN_
	train.fun = getFromNamespace(paste0('..', pars[['type']], '.pca'), ns = .NSNAME)
	pars[['type']] = NULL
	ANS = train.fun(PCA, pars)
	invisible()
		
}
..fw_training.pca <- function (PCA, pars){
	#_DOC_
	#Perform forward training and additional parameter retention.
	#_ARGUMENTS_
	#pars: list of parameters for the training
	#_MAIN_
	ANS = lapply(PCA$mdls$expand(), function(mdl)..fw_training.gpr(mdl, pars, PCA$X))
	mdls = gprVec$new(name = paste0(PCA$name, '.gpr'), gprs = lapply(ANS, function(x)x[['mdl']]))
	OPTs = r6.list$new(name = paste0(PCA$name, '.train'), objs = lapply(ANS, function(x)x[['OPT']]), cl = pars[['alg']])
	ret.list = PCA$ret
	ret.list[['pars.pc']] = lapply(ANS, function(x)x[['p']])
	ret.list[['pars']] = unique(unlist(ret.list[['pars.pc']]))
	names(ret.list[['pars']]) = colnames(PCA$X)[ret.list[['pars']]]
	ret.list[['Si.ret']] = sapply(ANS, function(x)x[['Si.ret']])
	ret.list[['Si.dsc']] = 1 - ret.list[['Si.ret']]
	PCA$.set.private('.ret', val = ret.list)
	PCA$.set.private('.mdls', val = mdls)
	PCA$.set.private('.train', val = OPTs)
} 
..training.pca <- function (PCA, pars){
	#_DOC_
	#Perform forward training and additional parameter retention.
	#_ARGUMENTS_
	#pars: list of parameters for the training
	#_MAIN_
	ANS = lapply(PCA$mdls$expand(), function(mdl)..training.gpr(mdl, pars))
	mdls = gprVec$new(name = paste0(PCA$name, '.gpr'), gprs = lapply(ANS, function(x)x[['mdl']]))
	OPTs = r6.list$new(name = paste0(PCA$name, '.train'), objs = lapply(ANS, function(x)x[['OPT']]), cl = pars[['alg']])
	ret.list = PCA$ret
	ret.list[['Si.ret']] = sapply(ANS, function(x)x[['Si.ret']])
	ret.list[['Si.dsc']] = 1 - ret.list[['Si.ret']]
	PCA$.set.private('.ret', val = ret.list)
	PCA$.set.private('.mdls', val = mdls)
	PCA$.set.private('.train', val = OPTs)
} 
.actmthd.set_cals.pca <- function (PCA, mdl) {
	#_DOC_
	#Sets and builds the calibration models for the retenined proncipal componenets.
	#_ARGUMENTS_
	#mdl: type of models
	#_MAIN_
	bld.fun = getFromNamespace(paste0('..bld.', mdl, '.pca'), ns = .NSNAME)
	ANS = bld.fun(PCA)
	invisible()	
		
}
..bld.cal.gpr.ng.pca <- function (PCA) {
	#_DOC_
	#Builds a calibrator for a GPR-NGE model
	#_MAIN_
	#~selcts the calibration parameters for each pc
	theta = PCA$.get.private('.theta')
	theta = lapply(PCA$ret[['pars.pc']], function(p)theta$extract(name = colnames(PCA$X)[p], grep = F))	
	#~scales and decomposes the observation according to the principal components 
	Y.star = scaleT(PCA$Y.star, C = PCA$C, S = PCA$S)	
	W.star = lsq.fit(Y = Y.star, basis = PCA$K)	#least sqare fit: calibration targets
	#~sets the observation precision
	n = length(Y.star)
	e = PCA$obs.cnf * (1 - 2/n) + 2/n
	if (is.null(PCA$Y.star.se)) {
		Yh.star = smooth.spline(x = 1:nrow(Y.star), y = Y.star)$y
		rt = ssq(Y.star - Yh.star)
	} else {
		rt = n * PCA$Y.star.se
	}
	rt = rt * e  
	shp = n * e
	rt = update.rate.ort2(rt, Y.star, PCA$K, W.star)
	shp = update.shp(shp, Y.star, PCA$K)
	#calibration models
	mdls = PCA$mdls$expand()
	cals = lapply(1:ncol(W.star), function (i) {
		thetai = r6.list$new(NULL, objs = theta[[i]], cl = 'uvrv')
		..bld.cal.ng(gpr.ng = mdls[[i]], Y.star = W.star[,i, drop = F], theta = thetai, shape = shp, rate = rt / PCA$D[i]**2) 
	})
	cals = gprCalVec$new(name = paste0(PCA$name, '.cals'), gprCals = cals) 
	PCA$.set.private('.cals', val = cals) 
}
