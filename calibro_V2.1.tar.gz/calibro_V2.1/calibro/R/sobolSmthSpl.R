#  This file is part of Calibro.
#
#  Calibro is free software; you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation; either version 2 of the License, or
#  (at your option) any later version.
#  
#  Calibro is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#  
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software
#  Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
#  MA 02110-1301, USA.

sobolSmthSpl <- function (Y, X) {
	#_DOC_
	#Determines the Si coefficient for singular parameters through smoothing with roughness penalty.
	#Reference: Saltelli, A; Ratto, M; Andres, T; Campolongo, F; Cariboni, J; Gatelli, D; Saisana, M & Tarantola, S.
	#Global Sensitivity Analysis: The Primer Wiley-Interscience, 2008
	#_ARGUMENTS_
	#Y: matrix of model outputs (only one column)
	#X: matrix model parameters
	#_MAIN_
	ANS = list()
	ANS[['call']] = match.call()
	ANS[['X']] = X
	ANS[['Y']] = Y
	par.names = colnames(X)		#gets parameters names
	if (is.null(colnames(X))) par.names = paste0('X', 1:ncol(X))
	X = normalize(X)    		#normalize inpiuts between [0,1]
	Y = Y - mean(Y)     		#center model responses
	Y = sapply(1:ncol(X), function(i)return(Y[order(X[,i])]))    #order Y before X (or create a new variable for X)
	X = sapply(1:ncol(X), function(i)return(X[order(X[,i]),i]))   
	SMTH = optSmooth(Y, X, c(-1.5, 1.5))
	SA.tab = t(sapply(SMTH, est.Si))
	colnames(SA.tab) = c('Si', 'se', 'q0.05')
	rownames(SA.tab) = par.names
	ANS[['S']] = SA.tab 
	names(SMTH) = par.names
	ANS[['SMTH']] = SMTH
	class(ANS) = 'sobolSmthSpl'
	return(ANS)
}

est.Si <-function (SMTH) {
	#_DOC_
	#Estimates the Si indexes
	#_MAIN_
	gi = SMTH[['y']]
	yi = SMTH[['yin']]
	Si = var(gi) / var(yi)
	#calculates the standard error of the main effect estimates
	yi.sc = (yi - mean(yi)) / sd(yi)            	#scaled yi
	u = (yi - gi) / (sd(yi) * abs(1 - Si)**0.5)   #scales residuals
	Si.se = abs(1 - Si) * sd(yi.sc**2 - u**2) / length(yi)**0.5
	q0.05 = qnorm(0.05, Si, Si.se)
	return(c(Si, Si.se, q0.05))
}

optSmooth <- function (Y, X, interval) {
  #_DOC_
  #Optimises the spline smoothing across all the column of the matrix Y.
  #_ARGUMENTS_
  #Y: matrix containing the observation to smooth
  #X: matrix of inputs
  #interval: interval where to search for the spar smoothing parameter
  #_CONTAINS_
  objective = function(spar) {
    nc = min(ncol(Y), parallel::detectCores())
    ANS = try(parallel::mclapply(1:ncol(Y), function(i)smooth.spline(X[,i], Y[,i], spar = spar, all.knots = T), mc.cores = nc), silent = T)
    if (is(ANS, 'try-error')) { #Windows does not support mclapply...
		SMTH <<- lapply(1:ncol(Y), function(i)smooth.spline(X[,i], Y[,i], spar = spar, all.knots = T))
	} else {
		SMTH <<- ANS
	}
    return(sum(sapply(SMTH, function(x)x$cv)))
  }
  #_MAIN_
  SMTH = NULL
  ANS = optimize(f = objective, interval = interval, tol = sqrt(.Machine$double.eps), maximum = FALSE)
  return(SMTH)
}

plot.sobolSmthSpl <- function(x, ...) {
	#_DOC_
	#Plot function for 'sobolSmthSpl' objects.
	#_MAIN_
	yrng = range(c(1 + x[['S']][,'se'], x[['S']][,'q0.05']))
	#plot estimates
	plot(x = 1:nrow(x[['S']]), y = x[['S']][,'Si'], pch = 19, ylim = yrng, xaxt = 'n', xlab = 'parameter', ylab = 'Si and se', ...)
	#plot q 0.05
	points(x = 1:nrow(x[['S']]), y = x[['S']][,'q0.05'], pch = 19, col = 2)
	#plot se
	arrows(x0 = 1:nrow(x[['S']]), y0 = x[['S']][,'Si'], y1 = x[['S']][,'Si'] - x[['S']][,'se'], length = 0)	#lower
	arrows(x0 = 1:nrow(x[['S']]), y0 = x[['S']][,'Si'], y1 = x[['S']][,'Si'] + x[['S']][,'se'], length = 0)	#upper
	#plot 0
	abline(h = 0, lty = 2)
	#x axis
	axis(side = 1, at = 1:nrow(x[['S']]), labels = row.names(x[['S']]))
	#legend
	legend('topright', legend = c('Si', 'se', 'q0.05'), pch = c(19, NA, 19), lty = c(NA, 1, NA), col = c(1, 1, 2), horiz = T, bty = 'n')
}

plot.effects <- function (x) {
	#_DOC_
	#Plots the first order effects given a 'sobolSmthSpl' object.
	#_MAIN_
	x = x$SMTH
	cl = 2
	rw = ceiling(length(x) / 2)
	par(mfrow=c(rw, cl))
	for (i in 1:length(x)) {
		yl = range(x[[i]]$yin, x[[i]]$y)
		plot(x = x[[i]]$x, y = x[[i]]$yin, main = names(x[i]), ylim = yl, xlab = 'x', ylab = 'y')
		lines(x = x[[i]]$x, y = x[[i]]$y, col = 2)
	}
}

print.sobolSmthSpl <- function(x, ...) {
	#_DOC_
	#Print function for 'sobolSmthSpl' objects
	#_MAIN_
	cat("\nFirst order indices:\n")
	print(x[['S']])
} 
