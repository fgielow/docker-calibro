#  This file is part of Calibro.
#
#  Calibro is free software; you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation; either version 2 of the License, or
#  (at your option) any later version.
#  
#  Calibro is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#  
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software
#  Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
#  MA 02110-1301, USA.

#_DOC_
#CLASSES IMPLEMENTING DIFFERENT FRAMEWORK TO PERFORM GAUSSIAN PROCESS REGRESSION

#* GPRVEC CLASS
gprVec = R6Class('gprVec',
	#_DOC_
	#A gpr vector (gprVec) is built by a series of independent gpr that may share covariance structures and/or hyper parameters.
	inherit = r6.list,
	#** public
	public = list(
		#*** methods
		#**** initialize
		initialize = function (name, gprs) {
			#_DOC_
			#Initilaise the object.
			#_ARGUMENTS_
			#name: name or description of the object.
			#gprs: list of gpr or objects.
			#_MAIN_
			super$initialize(name = paste0(name, '^{gprv}'), objs = gprs, cl = private$.cl)
		},
		#**** add.z
		add.z =  function (Z) {
			#_DOC_
			#Adds an input parameter to all the models in the 'gprVec' object.
			#_MAIN_
			.mthd.add_z.gprVec(self, Z)
		},
		#**** evl
		evl = function (z = NULL) {
			#_DOC_
			#Evaluates the posterior and the prior of the 'gprVec' objec at the given input vector 'z'.
			#_ARGUMENTS_
			#z: input vector.
			#_MAIN_
			.mthd.evl.gpr(self, z)
		},			
		predict = function (Z.star) {
			#_DOC_
			#Makes predictions for the test set in Z.star. Returns a list with posterior mean and posterior covariance.
			#_ARGUMENTS_
			#Z,star: list of named matrices containing the test sets.
			#_MAIN_
			.mthd.predict.gprVec(self, Z.star)
		},
		print = function () {
			#_DOC_
			#Printing method.
			#_MAIN_
			.mthd.print.gprVec(self)
		},
		.fortPars = function () {
			#_DOC_
			#Returns a list of parameters necessary to represent the 'gprVec' in the Fortran environment.
			#_MAIN_
			.mthd.fortPars.gprVec(self)
		}
	),
	#** active
	active = list(
		#*** pars
		pars = function (x) {
			#_DOC_
			#Returns and r6.list with the parameters of the model.
			#_MAIN_
			if (missing(x)) {self$get.attr('pars', exp = T, mode = 'lapply', cp.rm = F, wrap = T, cl = 'uvrv')} else {}
		},
		#*** maps
		maps = function (vals) {
			#_DOC_
			#Softly sets/returns the MAP values for the gprVec parameters.
			#_MAIN_
			if (missing(vals)){..get.maps.pars(self)}else{.actmthd.wrp(self, vals, ..set.maps.pars)}
		},
		#*** MAPs
		MAPs = function (vals) {
			#_DOC_
			#Strongly sets/ returns the MAP values for the gprVec parameters.
			#_MAIN_
			if (missing(vals)){..get.MAPs.pars(self)}else{.actmthd.wrp(self, vals, ..set.MAPs.pars)}
		},
		#*** .fp
		.fp = function (x) {
			#_DOC_
			#Returns the free parameters of the model.
			#_MAIN_
			if (missing(x)) {.mthd.get_fp.gpr(self)} else {}
		}
	),
	#** private
	private = list(
		#*** attributes
		gprs = NULL,	#list of 'gpr' objects
		.cl = 'gpr',	#class attribute
		.cs = 'cs11',	#class of covariance structure
		#*** methods
		.init = function () {
			#_DOC_
			#Only initialises the 'gprVec' in the Fortran environment.
			#_MAIN_
			.prvmthd.init.gprVec(self)
		},
		.evl = function (z) {
			#_DOC_
			#Only evaluates (i.e. it crashes if 'gprVec' not initialises before'), the 'gprVec' object'
			#_ARGUMENTS_
			#z: input vector
			#_MAIN_
			.prvmthd.evl.gprVec(self, z)
		}
	)
)

#* GPR CLASS
gpr = R6Class('gpr',	
	#_DOC_
	#Class representing a Gaussian Proces Regression Model.
	#A gpr object stores all the information necessary to build a Gaussian Process Regression Model for a certain dataset.
	inherit = calibro.obj,
	#** public
	public = list(
		#*** methods
		#**** initialize
		initialize = function (name, Y, CS, mu = T) {
			#_DOC_
			#Initialises a new gpr object.
			#_ARGUMENTS_
			#name: name/description of the gpr object.
			#Y: named list of matrices containing the training observations (one per target)
			#CS: covariance structure
			#mu: if T => subtract the mean from Y 
			#_MAIN_
			self$name = name
			private$.Y = Y
			private$.CS = CS
			private$.mu = mu
		},
		add.z = function (Z) {
			#_DOC_
			#Adds an input column to the covariance structure.
			#_ARGUMENTS_
			#Z: colum to add
			#_MAIN_
			.mthd.add_z.gpr(self, Z)
		},
		#**** evl
		evl = function (z = NULL) {
			#_DOC_
			#Evaluates posterior and prior of the 'gpr' object at the given input vector 'z'.
			#_ARGUMENTS_
			#z: input vector
			#_MAIN_
			.mthd.evl.gpr(self, z)
		},
		predict = function (Z.star) {
			#_DOC_
			#Makes predictions for the test set 'Z.star'
			#_ARGUMENTS_
			#Z.star: named list containing the input matrices of the test set
			#_MAIN_
			.mthd.predict.gpr(self, Z.star)
		},
		gof = function (gof) {
			#_DOC_
			#Returns the given goodness of fit over the training set.
			#_ARGUMENTS_
			#gof: goodness of fit function
			#_MAIN_
			.mthd.gof.gpr(self, gof)	
		},
		print = function () {
			#_DOC_
			#Printing method
			#_MAIN_
			.mthd.print.gpr(self)
		},
		.fortPars = function () {
			#_DOC_
			#Generates the list of parameters necessary to represent the 'gpr' object in the Fortran environment.
			#_MAIN_
			.mthd.fortPars.gpr(self)	
		}		
	),
	#** active
	active = list(
		#*** pars
		pars = function () {
			#_DOC_
			#Returns the parameters of the 'gpr' object.
			#_MAIN_
			return(private$.CS$pars)
		},
		CS = function () {
			#_DOC_
			#Returns the covariance structure of the 'gpr' object.
			#_MAIN_
			return(private$.CS)
		},
		maps = function (vals) {
			#_DOC_
			#Returns/softly sets the MAP values of the parmeters.
			#_MAIN_
			if (missing(vals)){..get.maps.pars(self)}else{..set.maps.pars(self, vals)}
		},
		MAPs = function (vals) {
			#_DOC_ 
			#Returns/strongly sets the MAP values of the parameters.
			#_MAIN_
			if (missing(vals)){..get.MAPs.pars(self)}else{.actmthd.wrp(self, vals, ..set.MAPs.pars)}
		},
		Y = function () {
			#_DOC_
			#Return the training targets.
			#_MAIN_
			return(private$.Y)
		},
		mu = function () {
			#_DOC_
			#Return the mu attribute.
			#_MAIN_
			return(private$.mu)
		},
		summary =  function () {
			#_DOC_
			#Prints to screen a summary of the model
			#_MAIN_
			.mthd.summary.gpr(self)
		},
		.fp = function () {
			#_DOC_
			#Returns the free parameters of the model
			#_MAIN_
			.mthd.get_fp.gpr(self)
		}
	),
	#** private
	private = list(
		#*** attributes
		.Y = NULL,	#list of target vectors 
		.CS = NULL,	#covariance strcutre of the gpr model
		.mu = NULL,	#mean function
		#*** methods
		#**** .evl
		.evl = function (z) {
			#_DOC_
			#Only evaluates the 'gpr' object. If the object has not been initialises crashes.
			#_ARGUMENTS_
			#z: input vector
			#_MAIN_
			.prvmthd.evl.gpr(self, z)
		},
		.init = function () {
			#_DOC_
			#Only initialises the 'gpr' object.
			#_MAIN_
			.prvmthd.init.gpr(self)
		},
		.init.predict = function (Z.star) {
			#_DOC_
			#Initialises the model for prediction purposes.
			#_ARGUMENTS_
			#Z.star: list of input matrices for the test set.
			#_MAIN_
			.prvmthd.init.predict.gpr(self, Z.star)
		}
	)
)

#* GPRCALVEC CLASS
gprCalVec = R6Class('gprCalVec',
	#_DOC_
	#A 'gprCalVec' is avector of calibrators besed upon 'gpr' ('gprCal') objects shring all or some of the calibration parameters.
	inherit = r6.list,
	#** public
	public = list(
		#*** methods
		#**** initialize
		initialize = function (name, gprCals) {
			#_DOC_
			#Initilaise the object.
			#_ARGUMENTS_
			#name: name or description of the object.
			#gprs: R6.list of gprCal objects.
			#_MAIN_
			super$initialize(name = paste0(name, '^{gprcal}'), objs = gprCals, cl = 'gprcal')
		},
		#**** evl
		evl = function (z = NULL) {
			#_DOC_
			#Evaluates the posterior and prior of the 'gprCalVec' class object for a given combination of calibration
			#parameters 'z'.
			#_ARGUMENTS_
			#z: vector of calibration parameter values
			#_MAIN_
			.mthd.evl.gpr(self, z)
		},
		#**** predict
		predict = function (z = NULL) {
			#_DOC_
			#Makes prediction for the test location 'z'.
			#_ARGUMENTS_
			#z: input vector for the test location
			#_MAIN_
			.mthd.predict.gprCalVec(self, z)
		},
		.fortPars = function () {
			#_DOC_
			#Generates the a list with the parameters necessary to represent the 'gprCalVec' 
			#calss object in the Fortran environment.
			#_MAIN_
			.mthd.fortPars.gprCalVec(self)
		},
		print = function () {
			#_DOC_
			#Prints the gprVec object.
			#_MAIN_
			.mthd.print.gprCalVec(self)
		}
	),
	#** active
	active = list(
		#** pars
		pars = function () {
			#_DOC_
			#Returns the parameters of the 'gorCalVec' class object.
			#_MAIN_
			self$get.attr('pars', wrap = T, exp = T, cp.rm = T, mode = 'lapply')
		},
		theta = function () {
			#_DOC_
			#Returns only the calibration parameters.
			#_MAIN_
			self$get.attr('theta', exp = T, mode = 'lapply', cp.rm = T, wrap = T, cl = 'uvrv')
		},
		maps = function (vals) {
			#_DOC_
			#Returns/softly sets the MAP values of the 'gprCalVec' class object paramters.
			#_ARGUMENTS_
			#vals: vector of MAP values
			#_MAIN_
			if(missing(vals)){..get.maps.pars(self)}else{local(..set.maps.pars(self, vals))}
		},
		MAPs = function (vals) {
			#_DOC_
			#Retrurns/strongly sets the map values for the model parameters.
			#_ARGUMENTS_
			#vals: map values (same order as model parameters. If missing returns the stored map values
			#_MAIN_
			if(missing(vals)){..get.MAPs.pars(self)}else{..set.MAPs.pars(self, vals)}
		},
		.fp = function () {
			#_DOC_
			#Returns the indexes of the free parameters in the model
			#_MAIN_
			.mthd.get_fp.gpr(self)
		}
	),
	#** private
	private = list(
		#*** methods
		#**** .init
		.init = function () {
			#_DOC_
			#Initialises only the 'gprCalVec' class object in the Fortran environment
			#_MAIN_
			.prvmthd.init.gprCalVec(self)
		},
		#**** .evl
		.evl = function (z) {
			#_DOC_
			#Evaluates only the 'gprCalVec'. Ir crashes if not initialised first.
			.prvmthd.evl.gprVec(self, z)
		}
	)
)
#* gprCal CLASS
gprCal = R6Class('gprcal',
	#_DOC_
	#A gprCal object in composed of a gpr model, a set of observation (Y), a set of boundary conditions (X), 
	#a set of calibration parameters (theta) and a conditional covariance strcture (CS.cnd).
	#It is used to infer the values of the calibraton parameters most likely to return the observed values, 
	#depending on the gpr model conditioning the gprCal. 
	inherit = calibro.obj,
	#** public
	public = list(
		#*** methods
		#**** initialize
		initialize = function (name, gpr, theta, X, Y, rplCfs, appCfs, nl = 2) {
			#_DOC_
			#Initialises the object.
			#_ARGUMENTS_
			#name: name or descritpion for the object.
			#gpr: GPR model condition the calibration.
			#theta: list of r6.lists containing the calibration parameters.
			#X: list of matrices collecting the boundary conditions for different targets.
			#Y: list of matrices collecting the target varialbes.
			#_MAIN_
			self$name = name
			private$.theta = r6.list$new(name = paste0(name, '.theta'), objs = theta, cl = 'uvrv')
			private$.gpr = gpr
			private$.Y = Y
			if (is.null(X)) {
				Z.star = ..bld1.Z2(gpr$CS$Z, theta, Y)
			} else {
				Z.star = ..bld2.Z2(gpr$CS$Z, theta, X, Y)
			}
			private$.CCS = gpr$CS$bld.ccs(Z.star = Z.star)
			private$.CS.star = gpr$CS$bld.csstar(Z.star = Z.star, rplCfs = rplCfs, appCfs = appCfs, nl = nl)
		},
		#**** evl
		evl = function (z = NULL) {
			#_DOC_
			#Evaluates the 'gprCal' at the given input vector 'z'.
			#_ARGUMENTS_
			#z: vector of values of the input prameters
			#_MAIN_
			.mthd.evl.gpr(self, z)
		},
		#**** predict
		predict = function (Z.star = NULL) {
			#_DOC_
			#Predicts for the test set represented by the input matrice in the list Z.star.
			#_ARGUMENTS_
			#Z.star: list of matrices for the test set
			#_MAIN_
			.mthd.predict.gprCal(self, Z.star)
		},
		print = function () {
			#_DOC_
			#Printing method
			.mthd.print.gprCal(self)
		},
		.fortPars = function () {
			#_DOC_
			#Generates a list of fortran parameters necessary to represent the 'gorCal' 
			#object in the Fortran environment.
			#_MAIN_
			.mthd.fortPars.gprCal(self)
		},
		.theta.mapping = function (pars) {
			#_DOC_
			#Maps the calibration parameters to the overall vector of parameters.
			#_MAIN_
			..theta.mapping.gprCal(self, pars)
		}
	),
	#** active
	active = list(
		#*** pars
		pars = function () {
			#_DOC_
			#Returns the parameters.
			#_MAIN_
			return(r6.list$new(
				objs = list.null.rm(list(
					'theta' = private$.theta, 
					'CS' = private$.gpr$CS$pars, 
					'CCS' = private$.CCS$pars,
					'CS.star' = private$.CS.star$pars
				)), 
				cl = 'uvrv'
			))
		},
		#*** theta
		theta = function (x) {
			#_DOC_
			#Returns the calibration parameters
			#_MAIN_
			if (missing(x)) {return(private$.theta)} else {}
		},
		#*** gpr
		gpr = function (x) {
			#_DOC_
			#Returns the 'gpr' within the 'gprCal'.
			#_MAIN_
			if (missing(x)) {return(private$.gpr)} else {}
		},
		CS = function (x) {
			#_DOC_
			#Return the covariance structure of the 'gpr' within the 'gprCal'.
			#_MAIN_
			if (missing(x)) {return(private$.gpr$CS)} else {}
		},
		CCS = function (x) {
			#_DOC_
			#Returns the cross-covariance structure.
			#_MAIN_
			if (missing(x)) {return(private$.CCS)} else {}
		},
		CS.star = function (x) {
			#_DOC_
			#Returns the covariance structure of the calibration target.
			#_MAIN_
			if (missing(x)) {return(private$.CS.star)} else {}
		},
		Y = function (x) {
			#_DOC_
			#Returns the calibration targets.
			#_MAIN_
			if (missing(x)) {return(private$.Y)} else {}
		},
		maps = function (vals) {
			#_DOC_
			#Softly sets/returns the MAP values of the 'gprCal' parameters.
			#_MAIN_
			if(missing(vals)){..get.maps.pars(self)}else{..set.maps.pars(self, vals)}
		},
		MAPs = function (vals) {
			#_DOC_
			#Strongly sets/returns the MAP values of the 'gprCal' parameters.
			#_MAIN_
			if(missing(vals)){..get.MAPs.pars(self)}else{..set.MAPs.pars(self, vals)}
		},
		.fp = function (x) {
			#_DOC_
			#Returns the indexes of the free parameters of the 'gprCal'.
			#_MAIN_
			if (missing(x)) {.mthd.get_fp.gpr(self)} else {}
		}
	),
	#** private
	private = list(
		#** attributes
		.gpr = NULL,		#conditioning gpr model
		.theta = NULL,		#r6.list of uvrv representing the calibration parameters
		.Y = NULL, 			#list of matrices containing the target variables
		.CCS = NULL,		#cross-covariance structure
		.CS.star = NULL,	#observation covariance structure
		#** methods
		.evl = function (z) {
			#_DOC_
			#Evaluates only the 'gprCal' object. It crashes it not initialised first.
			#_ARGUMENTS_
			#z: vectors of parameter vlaues
			#_MAIN_
			.prvmthd.evl.gpr(self, z)
		},
		.init = function () {
			#_DOC_
			#Initialises only the 'gprCal' object.
			#_MAIN_
			.prvmthd.init.gprCal(self)
		}
	)
)

#* FUNCTIONS
..alloc.gprCals <- function (ngprs) {
	#_DOC_
	#Allocates a number of 'gprCal' objects in the Fortran environment.
	#_ARGUMENTS_
	#ngprs: number of gpr to allocate
	#_MAIN_
	#~covariance strcutures
	.intrf.CS__allocate(csId = 1, ncs = ngprs)
	.intrf.MOULD__allocate(csId = 1, ncs = ngprs)
	.intrf.CS__allocate(csId = 2, ncs = ngprs)
	.intrf.MOULD__allocate(csId = 2, ncs = ngprs)
	.intrf.CS__allocate(csId = 3, ncs = ngprs)
	.intrf.MOULD__allocate(csId = 3, ncs = ngprs)
	#~covariance matrices
	.intrf.CM__allocate(cmId = 1, n = ngprs)
	.intrf.CM__allocate(cmId = 2, n = ngprs)
	.intrf.CM__allocate(cmId = 3, n = ngprs)
	#~input matrices
	.intrf.Z__allocate(zId = 1, n = ngprs)
	.intrf.Z__allocate(zId = 2, n = ngprs)
	#~target matrices
	.intrf.Y__allocate(yId = 1, n = ngprs)
	.intrf.Y__allocate(yId = 2, n = ngprs)
	#~
	.intrf.thetaMapp__allocate(n = ngprs) 	#map for theta
	.intrf.pmu__allocate(ngprs = ngprs)		#posterior mean vector
}
..alloc.gprs <- function (ngprs, csId) {
	#_DOC_
	#Allocates a number of 'gpr' objects in the Fortran 90 environment.
	#_ARGUMENTS_
	#ngprs: number of gprs to allocate
	#csId: identifier of the kind of covariance structure used in the 'gpr'.
	#_MAIN_
	#~covariance structure
	.intrf.CS__allocate(csId = csId, ncs = ngprs)
	.intrf.MOULD__allocate(csId = csId, ncs = ngprs)
	#~
	.intrf.CM__allocate(cmId = csId, n = ngprs)	#covariance matrix
	.intrf.Z__allocate(zId = 1, n = ngprs)		#input matrices
	.intrf.Y__allocate(yId = 1, n = ngprs)		#target matrices
}
..bld.cal.ng <- function (gpr.ng, Y.star, theta, shape, rate) {
	#_DOC_
	#Automatically creates a gprCal for a 'gpr' according to a Normal-Gamma model.
	#_ARGUMENTS_
	#gpr.ng: 'gpr' with Normal gamma structure
	#Y.star: list of matrices with the target observations.
	#theta: r6.list containing uvrv obj representing the calibration parameters.
	#shape, rate: shape and rate parameters of the Gamma distribution representing the observation precision.
	#_MAIN_
	#observation precision parameter
	nm1 = paste0('wn2.', gpr.ng$name)	#replace this with this	
	nm2 = paste0('wn2*.', gpr.ng$name)	#with this
	lam = uvrv.gamma$new(name = paste0('%SIGMA@', nm2, '%'), shape = shape, rate = rate) 
	cfs = list()
	cfs[[nm1]] = cf.whitePar$new(name = nm2, lam = lam) 
	return(
		gprCal$new(
			name = 	paste0(gpr.ng$name, '.cal'),
			gpr = gpr.ng,
			theta = list(theta),
			Y = list('Y.star' = Y.star),
			X = NULL,
			rplCfs = cfs,
			appCfs = NULL
		)
	)
}
..bld.gpr.ng.sePar01_whitePar01 <- function (mdl.name, Y, Z, shape, rate) {
	#_DOC_
	#Builds a 'gpr' according to a Normal-Gamma model and kernel = sePar01 + whitePar01.
	#Arguemnts:
	#mdl.name: model name
	#Y: lsit of matrices containing the training pbservations.
	#Z: lsit of matrice containing the input vectors for the training observations.
	#shape, rate: shape and rate parameters of the Gamma distribution representing the model precision.
	#_MAIN_
	#~creates the kernel
	cfs = list()	#list of covariance functions
	cfs[[1]] = cf.sePar01$new(name = paste0('sePar01.', mdl.name), l = list(uvrv.beta$new(shape1 = 1, shape2 = 1)), s = uvrv.beta$new(shape1 = 1, shape2 = 1)) 
	cfs[[2]] = cf.whitePar01$new(name =  paste0('wn1.', mdl.name), lam = uvrv.beta$new(shape1 = 1, shape2 = 1)) 
	cfs[[3]] = cf.whitePar$new(name =  paste0('wn2.', mdl.name), lam = uvrv.gamma$new(shape = shape, rate = rate)) 	
	CS = cs$new(name = mdl.name, Z = Z, krns = krn$new(name = 'krn', cfs = cfs))
	CS$bld()
	return(gpr$new(name = mdl.name, Y = list('Y' = Y), CS = CS))
}
..fw_training.gpr <- function (mdl0, pars, Z) {
	#_DOC_
	#Perform a forward selection of the model input while training the 'gpr' model according.
	#Reference: Welch, W. J.; Buck, R. J.; Sacks, J.; Wynn, H. P.; Mitchell, T. J. & Morris, M. D. Screening, Predicting, 
	#and Computer Experiments Technometrics, Taylor & Francis, Ltd., American Statistical Association, 
	#American Society for Quality, 1992, 34, 15-25
	#_ARGUMENTS_
	#mdl.name: name or short description for the model
	#Y: list of matrices containing the training targets
	#Z: list of matrices containing the inputs
	#shape, rate: parameters of the gamma prior used for the nise precision
	#p: vector of indexes indicating the intial set of parameters (those to include absolutely)
	#pars: list of parameters indicating the algorithm to adop for optimisation
	#_MAIN_
	#~train base model
	alg = pars[['alg']]
	pars[['alg']] = NULL
	OPT.gen = getFromNamespace(alg, ns = .NSNAME)
	pars[['mdl']] = mdl0
	OPT0 = do.call(OPT.gen$new, pars)
	OPT0$run()
	#~prepares the set of potential additional parameters
	p0 = colnames(mdl0$CS$Z[[1]])
	p = sapply(p0, function(x)which(colnames(Z) == x))
	pp = 1:ncol(Z)
	pp = pp[-p]
	#~starts the forward training
	while (T) {
		if (length(pp) == 0) break	#if no parameters left to add exit
		#~creates a new iterations of the model
		mdli = r6.rep(mdl0, n = length(pp), deep = T, cl = 'gpr')
		for (i in 1:length(pp)) mdli$expand()[[i]]$add.z(Z[,pp[i],drop = F])
		#~optimises the created models
		OPTi = lapply(mdli$expand(), function(mdl){pars[['mdl']] = mdl; do.call(OPT.gen$new, pars)})
		OPTi = r6.list$new(name = NULL, objs = OPTi, cl = alg)
		OPTi$exe.mthd('run', mode = 'lapply', wrap = T, cl = alg)
		bestys = OPTi$get.attr('besty', wrap = F, cp.rm = T, exp = T)
		newp = which.max(bestys)
		#~check for significant improvements
		if (BF.2ln(OPT0$besty, bestys[newp]) >= 6) { #if found update the model and optimisation
			OPT0 = OPTi$expand()[[newp]]
			mdl0 = mdli$expand()[[newp]]
			p = c(p, pp[newp])
			pp = pp[-newp]
		} else {
			break	#if no parameter produced a significant improvement exit
		}
		#~
	}
	names(p) = colnames(Z)[p]
	OPT0$set.MAPs()
	Si.ret = mdl0$gof('Rscore3')
	return(list('mdl' = mdl0, 'OPT' = OPT0, 'p' = p, 'Si.ret' = Si.ret))
}
..training.gpr <- function (mdl, pars) {
	#_DOC_
	#Perform a forward selection of the model input while training the 'gpr' model according.
	#Reference: Welch, W. J.; Buck, R. J.; Sacks, J.; Wynn, H. P.; Mitchell, T. J. & Morris, M. D. Screening, Predicting, 
	#and Computer Experiments Technometrics, Taylor & Francis, Ltd., American Statistical Association, 
	#American Society for Quality, 1992, 34, 15-25
	#_ARGUMENTS_
	#mdl.name: name or short description for the model
	#Y: list of matrices containing the training targets
	#Z: list of matrices containing the inputs
	#shape, rate: parameters of the gamma prior used for the nise precision
	#p: vector of indexes indicating the intial set of parameters (those to include absolutely)
	#pars: list of parameters indicating the algorithm to adop for optimisation
	#_MAIN_
	#~train base model
	alg = pars[['alg']]
	pars[['alg']] = NULL
	OPT.gen = getFromNamespace(alg, ns = .NSNAME)
	pars[['mdl']] = mdl
	OPT = do.call(OPT.gen$new, pars)
	OPT$run()
	OPT$set.MAPs()
	Si.ret = mdl$gof('Rscore3')
	return(list('mdl' = mdl, 'OPT' = OPT, 'Si.ret' = Si.ret))
}
..bld1.Z2 <- function (Z1, tt, Y2) {
	#_DOC_
	#Creates a template to fill of the list of input matrices ('Z2') characterising the calibration targets.
	#All the colums of the 'Z2' matrices are considered as calibration parameters.
	#_ARGUMENTS_
	#Z1: list of imput matrices of the training set
	#tt: r6.list containing the 'uvrv' objects representing the calibration parameters
	#Y2: list of matrices containing the calibration targets
	#_MAIN_
	if (length(Z1) != length(tt) || length(Z1) != length(Y2)) stop('theta, Y and Z lists must have the same length!!!')
	for (i in 1:length(Z1)) {
		tt[[i]]$order(colnames(Z1[[i]]), nl = 2)
	}
	t = sapply(tt, function(x)length(x$expand(cp.rm = T)))
	Z2 = lapply(1:length(tt), function(i) matrix(0, nrow = nrow(Y2[[i]]), ncol = t[i]))
	names(Z2) = names(Z1)
	for (i in 1:length(Z1)) colnames(Z2[[i]]) = colnames(Z1[[i]])
	return(Z2)
}
..bld2.Z2 <- function (Z1, tt, X, Y2) {
	#_DOC_
	#Creates a template to fill of the list of input matrices ('Z2') characterising the calibration targets.
	#The matrices of calibration parameters are binded to the matrices of known values in 'X'.
	#_ARGUMENTS_
	#Z1: list of imput matrices of the training set
	#tt: r6.list containing the 'uvrv' objects representing the calibration parameters
	#X: list of matrices containing known parameter values
	#Y2: list of matrices containing the calibration targets
	#_MAIN_
	if (length(Z1) != length(tt) || length(Z1) != length(Y2) || length(Z1) != length(X)) stop('theta, Y, X and Z lists must have the same length!!!')
	if (any(sapply(X, nrow) != sapply(Y2, nrow))) stop('Y and X must have same number of rows!!!')
	Z2 = list()
	t = sapply(tt, function(x)length(x$expand(cp.rm = T)))
	for (i in 1:length(Z1)) {
		znms = colnames(Z1[[i]])
		t = length(tt[[i]]$expand(cp.rm = T))
		tt[[i]]$order(ord = znms[1:t], nl = 1)
		X[[i]] = X[[i]][,znms[-(1:t)]]
		TTi = matrix(tt[[i]]$exe.mthd('r', n = nrow(Y2[[i]]), cp.rm = T, wrap = F, exp = T, mode = 'sapply') * 0, ncol = t[i])
		Z2[[i]] = cbind(TTi, X[[i]])
	}
	return(Z2)
}
..get.maps.pars <- function (G) {
	#_DOC_
	#Retrieves the MAP values of the parameters.
	#_MAIN_
	G$pars$get.attr('map', exp = T, cp.rm = T, wrap = F, mode = 'sapply')
}
..get.MAPs.pars <- function (G) {
	#_DOC_
	#Retrieves the MAP values of the parameters.
	#_MAIN_
	G$pars$get.attr('MAP', exp = T, cp.rm = T, wrap = F, mode = 'sapply')
}
..init.Yi <- function (yId, i, fortPars) {
	#_DOC_
	#Initialises only the matrices of training or target observation.
	#_ARGUMENTS_
	#yId: 1 for trainingn observations, 2 for target observations
	#i: gpr index
	#fortPars: list of Fortran parameters for the ith gpr
	#_MAIN_
	.intrf.Y__init(yId = yId, i = i, Y = fortPars[[paste0('Y', yId)]]) 
}
..init.gprCali <- function (i, fortPars) {
	#_DOC_
	#Initialises the ith gprCal.
	#_ARGUMENTS_
	#i: gprCal index
	#fortPars: list of Fortran parameters
	#_MAIN_
	.init.csi(i = i, fortPars = fortPars[['CS11']])
	.init.csi(i = i, fortPars = fortPars[['CS12']])
	.init.csi(i = i, fortPars = fortPars[['CS22']])
	.init.CMi(i = i, fortPars = fortPars[['CS11']])
	.init.CMi(i = i, fortPars = fortPars[['CS12']])
	.init.CMi(i = i, fortPars = fortPars[['CS22']])
	.init.Zi(i = i, zId = 1, fortPars = fortPars[['CS11']])
	.init.Zi(i = i, zId = 2, fortPars = fortPars[['CS22']])
	..init.Yi(yId = 1, i = i, fortPars = fortPars)
	..init.Yi(yId = 2, i = i, fortPars = fortPars)
	..init.thetaMappi(i = i, fortPars) 
	m.star = nrow(fortPars[['Y2']])
	.intrf.pmu__init(i = i, pm = matrix(0, nrow = m.star, ncol = 1))
}
..init.gpri <- function (i, fortPars) {
	#_DOC_
	#Initialises the ith gpr.
	#_ARGUMENTS_
	#i: indexes corresponding to the gpr to initialise.
	#forPars: Fortran parameter list for the ith gpr
	#_MAIN_
	.init.csi(i = i, fortPars = fortPars[['CS11']])
	.init.CMi(i = i, fortPars = fortPars[['CS11']])
	.init.Zi(i = i, zId = 1, fortPars = fortPars[['CS11']])
	..init.Yi(i = i, yId = 1, fortPars = fortPars)
}
..init.nested <- function (fortPars) {
	#_DOC_
	#Sets the depedency of the model parameters from nested model parameters
	#_ARGUMENTS_
	#fortPars: list of Fortran parameters
	#_MAIN_
	.intrf.nested__allocate(length(fortPars[['nested']]))
	for (i in 1:length(fortPars[['nested']])) .intrf.nested__init(i, fortPars[['nested']][[i]])
}
..init.priors <- function (fortPars) {
	#_DOC_
	#Initialises the prior distributions for the gpr parameters
	#Arguemtns:
	#fortPars: list of Forttran parameters for the ith gpr
	#_MAIN_
	.intrf.prior__init(sapply(fortPars[['priors']], function(x)x[1]))
	.intrf.priorpars__allocate(length(fortPars[['priors']]))
	for (i in 1:length(fortPars[['priors']])) .intrf.priorpars__init(i, fortPars[['priors']][[i]][-1])
}
..init.thetaMappi <- function (i, fortPars) {
	#_DOC_
	#Initialises the vector mapping the calibration parameters
	#_ARGUMENTS_
	#i: gprCal index
	#fortPars: list of Fortran parameters
	#_MAIN_
	n = length(fortPars[['thetaMapp']])
	.intrf.thetaMapp__allocateMVi(i = i, n = n)
	for (j in 1:n) .intrf.thetaMapp__init(i = i, j = j, thetaMapp = fortPars[['thetaMapp']][[j]])   
}	
..set.maps.pars <- function (G, vals) {
	#_DOC_
	#Softly sets the MAP values of the parameters
	#_ARGUMENTS_
	#vals: vectors of values
	#_MAIN_
	G$pars$set.attr('map', val = vals, all = F, exp = T)
}
..set.MAPs.pars <- function (G, vals) {
	#_MAIN_
	#Strongly sets the MAP values of the parameters
	#_ARGUMENTS_
	#vals: vector of values
	#_MAIN_
	G$pars$set.attr('MAP', val = vals, all = F, exp = T)
}
..solve.priorNested <- function (pars, fortPars) { 
	#_DOC_
	#Solves the dependicies of hp from nested hp and creates the arrays for they treatment in Fortran
	#_ARGUMENTS_
	#pars: r6.list of mode parameters (uvrvs)
	#fortPars: list of Fortran parameters for the model
	#_MAIN_
	priors = pars$exe.mthd('.fortPars', wrap = F, cp.rm = T, mode = 'lapply')
	nested = priors
	for (i in 1:length(priors)) {
		for (j in 1:length(priors[[i]])) {
			if (is(priors[[i]][[j]], 'uvrv')) {
				nested[[i]][[j]] = find.hp.nst(priors[[i]][[j]], pars$expand(cp.rm = T))
				priors[[i]][[j]] = -1
			} else {
				nested[[i]][[j]] = 0
			}
		}
		priors[[i]] = unlist(priors[[i]])
		nested[[i]] = unlist(nested[[i]])
	}
	fortPars[['nested']] = lapply(nested, function(x)x[-1])
	fortPars[['priors']] = priors
	return(fortPars)
}
..theta.mapping.gprCal <- function (G, pars) {
	#_DOC_
	#Maps the calibration parameters w.r.t. pars
	#_ARGUMENTS_
	#pars: list of parameters
	#_MAIN_
	lapply(G$theta$get.attr('list', exp = F, cp.rm = F, mode = 'lapply'), function(x)pars.mapping(x, pars))
}

.mthd.add_z.gpr <- function (G, Z) {
	#_DOC_
	#Add inputs (Z) to a 'gpr' object'.
	#_ARGUMENTS_
	#Z: matrix with columns the imputs to add.
	#_MAIN_
	G$CS$add.z(Z)
}

.mthd.add_z.gprVec <- function (G, Z) {
	#_DOC_
	#Add inputs (Z) to all the 'gpr' object in a 'gprVec' object
	#_ARGUMENTS_
	#Z: matrix with columns the inputs to add
	#_MAIN_
	G$exe.mthd('add.z', Z = Z)
}

.mthd.evl.gpr <- function (G, z) {
	#_DOC_
	#Evaluates the posterior density distribution of the gpr for the input vector z.
	#_ARGUMENTS_
	#z: input vector. If NULL it randomly generated (NB: if uvrv have map random generation retunrs map values).
	#_MAIN_
	.evl = function () {
		G$.get.private('.init')()
		G$.get.private('.evl')(z)
	}
	return(.exe.safeFort(.evl))
}
.mthd.fortPars.gpr <- function (G) {
	#_DOC_
	#Returns a list containing all the parameters necessary to initialise the gpr in the Fortran environment.
	#_MAIN_
	fortPars = list()
	fortPars[['CS11']] = G$CS$.fortPars()
	Y = rbind.list(G$Y)
	if (G$mu) {
		fortPars[['mu']] = mean(Y)
	} else {
		fortPars[['mu']] = 0
	}
	fortPars[['Y1']] = Y - fortPars[['mu']]
	#priors
	priors = G$pars$exe.mthd('.fortPars', exp = T, wrap = FALSE, cp.rm = TRUE, mode = 'lapply')
	fortPars[['nested']] = lapply(fortPars[['nested']]$links, function(x)x[-1])
	fortPars = ..solve.priorNested(G$pars, fortPars)
	return(fortPars)
}
.mthd.fortPars.gprCal <- function (G) {
	#_DOC_
	#Builds a list containing all the parameters necessary to initialise the gprCal in the Fortran environment.
	#_MAIN_
	fortPars = G$gpr$.fortPars()	#gets the Fortran parameters for the conditioning gpr
	fortPars[['CS12']] = G$CCS$.fortPars()
	fortPars[['CS22']] = G$CS.star$.fortPars() 
	fortPars[['Y2']] = rbind.list(G$Y) - fortPars[['mu']]
	for (j in 1:length(G$CS$list)) {
		fortPars[['CS11']][['krns']][[j]][['hpMapp']] = G$CS$list[[j]]$.pars.mapping(G$pars$expand(cp.rm = T))
	}
	for (j in 1:length(G$CCS$list)) {
		fortPars[['CS12']][['krns']][[j]][['hpMapp']] = G$CCS$list[[j]]$.pars.mapping(G$pars$expand(cp.rm = T))
	}
	for (j in 1:length(G$CS.star$list)) {
		fortPars[['CS22']][['krns']][[j]][['hpMapp']] = G$CS.star$list[[j]]$.pars.mapping(G$pars$expand(cp.rm = T))
	}
	fortPars[['thetaMapp']] = G$.theta.mapping(G$pars$expand(cp.rm = T))
	fortPars = ..solve.priorNested(G$pars, fortPars)
	return(fortPars)
}
.mthd.fortPars.gprCalVec <- function (G) {
	#_DOC_
	#Return alist containing the parameters necessary to define the gprVec in the Fortran environment.
	#_MAIN_
	#create list with the fortPars for all the gprs
	gprs = G$exe.mthd('.fortPars', exp = T, mode = 'lapply', wrap = FALSE, cp.rm = FALSE)
	#remaps the parameters
	for (i in 1:length(gprs)) {
		for (j in 1:length(G$expand(cp.rm = T)[[i]]$CS$list)) {
			gprs[[i]][['CS11']][['krns']][[j]][['hpMapp']] = 
				G$expand(cp.rm = T)[[i]]$CS$list[[j]]$.pars.mapping(G$pars$expand(cp.rm = T))
		}
		for (j in 1:length(G$expand(cp.rm = T)[[i]]$CCS$list)) {
			gprs[[i]][['CS12']][['krns']][[j]][['hpMapp']] = 
				G$expand(cp.rm = T)[[i]]$CCS$list[[j]]$.pars.mapping(G$pars$expand(cp.rm = T))
		}
		for (j in 1:length(G$expand(cp.rm = T)[[i]]$CS.star$list)) {
			gprs[[i]][['CS22']][['krns']][[j]][['hpMapp']] = 
				G$expand(cp.rm = T)[[i]]$CS.star$list[[j]]$.pars.mapping(G$pars$expand(cp.rm = T))
		}
	}			
	for (i in 1:length(gprs)) {
		gprs[[i]][['thetaMapp']] = G$expand(cp.rm = T)[[i]]$.theta.mapping(G$pars$expand(cp.rm = T))
	}
	#create fortPars for grp.vec
	fortPars = list('ngprs' = length(gprs), 'gprs' = gprs)
	#define priors
	fortPars = ..solve.priorNested(G$pars, fortPars) 
	return(fortPars)
}
.mthd.fortPars.gprVec <- function (G) {
	#_DOC_
	#Return alist containing the parameters necessary to define the gprVec in the Fortran environment.
	#_MAIN_
	#create list with the fortPars for all the gprs
	gprs = G$exe.mthd('.fortPars', exp = T, mode = 'lapply', wrap = FALSE, cp.rm = FALSE)
	#remaps the parameters			
	for (i in 1:length(gprs)) {
		for (j in length(G$expand(cp.rm = T)[[i]]$CS$list)) {
			gprs[[i]][['CS11']][['krns']][[j]][['hpMapp']] = 
				G$expand(cp.rm = T)[[i]]$CS$list[[j]]$.pars.mapping(G$pars$expand(cp.rm = T))
		}
	}	
	#create fortPars for grp.vec
	fortPars = list('ngprs' = length(gprs), 'gprs' = gprs)
	#define priors
	fortPars = ..solve.priorNested(G$pars, fortPars) 
	return(fortPars)
}
.mthd.get_fp.gpr <- function (G) {
	#_DOC_
	#Returns the indexes of the free parameters of the model
	#_MAIN_
	which(G$pars$get.attr('.state', exp = T, wrap = F, cp.rm = T) != 0)
}
.mthd.gof.gpr <- function (G, gof) {
	#_DOC_
	#Calculates the goodness of fit on the training set.
	#_ARGUMENTS_
	#gof: goodness of fit to calculate.
	#_MAIN_
	y = rbind.list(G$Y)
	yh = G$predict(Z.star = NULL)[['pMu']]
	return(do.call(gof, list(y = y, y.hat = yh)))	
}
.mthd.predict.gpr <- function (G, Z.star) {
	#_DOC_
	#Provides the predictive distribution for the imput vectors in Z2.
	#_ARGUMENTS_
	#Z.star: list of input matrices for the test set
	#_MAIN_
	.predict = function () {
		G$.get.private('.init.predict')(Z.star)
		z = G$pars$exe.mthd('r', n = 1, wrap = F, cp.rm = T)
		.intrf.CS__evlCm(csId = .intrf.CS__id('cs11'), i = 1, hp = z)
		.intrf.CS__evlCm(csId = .intrf.CS__id('cs12'), i = 1, hp = z)
		.intrf.CS__evlCm(csId = .intrf.CS__id('cs22'), i = 1, hp = z)
		.intrf.gpr__predict(1)
		return(list('pMu' = .intrf.pmu__get(1) + G$.fortPars()[['mu']], 'pCm' = .intrf.CM__get(1, 3)))
	}
	.exe.safeFort(.predict)
}
.mthd.predict.gprCal <- function (G, Z.star = NULL) {
	#_DOC_
	#Evaluate the posterior logLkh and returns also the predictive mean and covaraince.
	#_ARGUMENTS_
	#Z.star: list of input matrices for the test set
	#_MAIN_
	.predict = function () {
		G$.get.private('.init')()
		p = G$.get.private('.evl')(Z.star)
		#predictive mean
		pMu = .intrf.pmu__get(1) + G$.fortPars()[['mu']]
		#pridictive covariance
		pCm = .intrf.CM__get(1, 3)
		return(list('p' = p, 'pMu' = pMu, 'pCm' = pCm))
	}
	return(.exe.safeFort(.predict))
}
.mthd.predict.gprCalVec <- function (G, z) {
	#_DOC_
	#Evaluate the posterior logLkh and returns alos the predictive mean and covaraince.
	#_ARGUMENTS_
	#z: input vector	
	#_MAIN_
	.predict = function () {
		G$.get.private('.init')()
		logLkh = G$.get.private('.evl')(z)
		#predictive mean
		mu = sapply(G$.fortPars()[['gprs']], function(x)x[['mu']])
		pMu = sapply(1:length(G$expand(cp.rm = T)), .intrf.pmu__get) + mu
		#pridictive covariance
		pCm = sapply(1:length(G$expand(cp.rm = T)), function(i).intrf.CM__get(i, 3))
		return(list('logLkh' = logLkh, 'pMu' = pMu, 'pCm' = pCm))
	}
	return(.exe.safeFort(.predict))
}
.mthd.predict.gprVec <- function (G, Z.star) {
	#_DOC_
	#Performs prediction for the given list of matrices of locations.
	#_ARGUMENTS_
	#Z.star: list of input matrices for the test set
	#_MAIN_
	G$exe.mthd('predict', Z.star = Z.star, exp = T, cp.rm = T, wrap = F, mode = 'lapply')
}
.mthd.print.gpr <- function (G) {
	#_DOC_
	#Prints a human friendly version of the object.
	#_MAIN_
	cat(paste('GPR model:', G$name, '\n'))
	cat('* Y:\n')
	for (i in length(G$Y)) {
		cat(paste0('\n** ', names(G$Y)[i], ': \n'))
		print(summary(G$Y[[i]]))
	}
	print(G$CS)
}
.mthd.print.gprCal <- function (G) {
	#_DOC_
	#Prints a human friendly version of the object.
	#_MAIN_
	cat(paste('\n GPR_CAL model:', G$name, '\n'))
	cat('* Y.star:\n')
	for (i in length(G$Y)) {
		cat(paste0('\n** ', names(G$Y)[i], ': \n'))
		print(summary(G$Y[[i]]))
	}
	print(G$gpr)
}
.mthd.print.gprVec <- function (G) {
	#_DOC_
	#Prints a human friendly version of the object.
	#_MAIN_
	cat('\n\t GPR vector:', G$name, '\n')
	cat('\t contained gpr models:', paste(G$get.attr('name')), '\n\n')
}
.mthd.print.gprCalVec <- function (G) {
	#_DOC_
	#Prints a human friendly version of the object.
	#_MAIN_
	cat('\n GPR_CAL vector:', G$name, '\n')
	cat(' contained gprCal models:', paste(G$get.attr('name'), collapse = ', '), '\n\n')
}
.prvmthd.evl.gpr <- function (G, z) {
	#_DOC_
	#Only evaluates the gpr for the inputs in z
	#_ARGUMENTS_
	#z: input vector. If NULL it is randomly generated (if map is set random generation returns map values).
	#_MAIN_
	if (is.null(z)) z = G$pars$exe.mthd('r', n = 1, wrap = F, cp.rm = T)
	return(.intrf.gpr__evlpd(class(G)[1], z)) 
}
.prvmthd.evl.gprVec <- function (G, z) {
	#_DOC_
	#Only evaluates the posterior probability density distribution
	#_ARGUMENTS_
	#z: input vector
	#_MAIN_
	if (is.null(z)) z = G$pars$exe.mthd('r', n = 1, wrap = F, cp.rm = T)
	.intrf.gpr__evlpd(G$.get.private('.cl'), z) 
}
.prvmthd.init.gpr <- function (G) {
	#_DOC_
	#Only initialises the model in the fortran environment.
	#_MAIN_
	fortPars = G$.fortPars()
	#set flags
	.intrf.mdl__set(class(G)[1])#.set.mdl(fortPars)
	#allocation
	..alloc.gprs(ngprs = 1, csId = G$CS$.id)
	#initialisation
	..init.gpri(i = 1, fortPars = fortPars)
	#initialise priors
	..init.priors(fortPars)
	..init.nested(fortPars)
}
.prvmthd.init.gprCal <- function (G) {
	#_DOC_
	#Only initialises the gprCal model in the Fortran environment.
	#_MAIN_
	fortPars = G$.fortPars()
	#~sets flags
	.intrf.mdl__set('gprcal')
	.intrf.flCM11inv__set(1)
	#~
	#~allocation
	..alloc.gprCals(ngprs = 1)
	#~
	#~initialisation
	..init.gprCali(i = 1, fortPars = fortPars)
	#~
	#~priors
	..init.priors(fortPars)
	..init.nested(fortPars)
	#~
	#~ evaluates the training covariance structure
	z = G$pars$exe.mthd('r', n = 1, wrap = F, cp.rm = T)
	..evl.csi(i = 1, fortPars = fortPars[['CS11']], hp = z, ans = F)
	#~
}
.prvmthd.init.gprCalVec <- function (G) {
	#_DOC_
	#Only inintialise the model in the Fortran environment
	#_MAIN_
	fortPars = G$.fortPars()
	.intrf.mdl__set(G$.get.private('.cl'))
	.intrf.flCM11inv__set(1)
	..alloc.gprCals(ngprs = fortPars[['ngprs']])
	for (i in 1:fortPars[['ngprs']]) ..init.gprCali(i = i, fortPars = fortPars[['gprs']][[i]])
	..init.priors(fortPars)
	..init.nested(fortPars)
	z = G$pars$exe.mthd('r', n = 1, exp = T, wrap = F, cp.rm = T, mode = 'sapply')
	for (i in 1:fortPars[['ngprs']]) ..evl.csi(i = i, fortPars = fortPars[['gprs']][[i]][['CS11']], hp = z, ans = F)
}
.prvmthd.init.gprVec <- function (G) {
	#_DOC_
	#Only inintialise the model in the Fortran environment
	fortPars = G$.fortPars()
	.intrf.mdl__set(G$.get.private('.cl'))
	..alloc.gprs(ngprs = fortPars[['ngprs']], csId = .intrf.CS__id(G$.get.private('.cs')))
	for (i in 1:fortPars[['ngprs']]) ..init.gpri(i = i, fortPars = fortPars[['gprs']][[i]])
	..init.priors(fortPars)
	..init.nested(fortPars)
}
.prvmthd.init.predict.gpr <- function (G, Z.star) {
	#_MAIN_
	#Only initialises the model for predictions in the Fortran environment.
	#_ARGUMENTS_
	#Z.star: list of matrices with the input vectors for which predictions are needed.
	#_MAIN_
	CCS = G$CS$bld.ccs(Z.star = Z.star)
	CS.star = G$CS$bld.csstar(Z.star = Z.star, rplCfs = 'diag0', appCfs = NULL)
	fortPars = G$.fortPars()
	fortPars[['CS12']] = CCS$.fortPars()
	fortPars[['CS22']] = CS.star$.fortPars()
	#remaps hyper parameters
	#remaps CS11
	for (j in 1:length(G$CS$list)) {
		fortPars[['CS11']][['krns']][[j]][['hpMapp']] = G$CS$list[[j]]$.pars.mapping(G$pars$expand(cp.rm = T))
	}
	#remaps CS12
	for (j in 1:length(CCS$list)) {
		fortPars[['CS12']][['krns']][[j]][['hpMapp']] = CCS$list[[j]]$.pars.mapping(G$pars$expand(cp.rm = T))
	}
	#remaps CS22
	for (j in 1:length(CS.star$list)) {
		fortPars[['CS22']][['krns']][[j]][['hpMapp']] = CS.star$list[[j]]$.pars.mapping(G$pars$expand(cp.rm = T))
	}
	#~Allocation
	#~~CSs
	.intrf.CS__allocate(csId = G$CS$.id, ncs = 1)
	.intrf.MOULD__allocate(csId = G$CS$.id, ncs = 1)
	.intrf.CS__allocate(csId = CCS$.id, ncs = 1)
	.intrf.MOULD__allocate(csId = CCS$.id, ncs = 1)
	.intrf.CS__allocate(csId = CS.star$.id, ncs = 1)
	.intrf.MOULD__allocate(csId = CS.star$.id, ncs = 1)
	#~~
	#~~CMs
	.intrf.CM__allocate(cmId = G$CS$.id, n = 1)
	.intrf.CM__allocate(cmId = CCS$.id, n = 1)
	.intrf.CM__allocate(cmId = CS.star$.id, n = 1)
	#~~
	#~~Zs
	.intrf.Z__allocate(zId = 1, n = 1)
	.intrf.Z__allocate(zId = 2, n = 1)
	#~~
	#~~Y
	.intrf.Y__allocate(yId = 1, n = 1)
	#~~
	#~~pm
	.intrf.pmu__allocate(ngprs = 1)
	#~~
	#~
	#~Initialisation
	#~~CSs
	.init.csi(i = 1, fortPars = fortPars[['CS11']])
	.init.csi(i = 1, fortPars = fortPars[['CS12']])
	.init.csi(i = 1, fortPars = fortPars[['CS22']])
	#~~
	#~~CMs
	.init.CMi(i = 1, fortPars = fortPars[['CS11']])
	.init.CMi(i = 1, fortPars = fortPars[['CS12']])
	.init.CMi(i = 1, fortPars = fortPars[['CS22']])
	#~~
	#~~Zs
	.init.Zi(i = 1, zId = 1, fortPars = fortPars[['CS11']])
	.init.Zi(i = 1, zId = 2, fortPars = fortPars[['CS22']])
	#~~Y
	..init.Yi(i = 1, yId = 1, fortPars = fortPars)
	#~~
	#~~pm & pcM
	m.star = sum(sapply(fortPars[['CS22']][['Z2']], nrow))
	.intrf.pmu__init(i = 1, pm = matrix(0, nrow = m.star, ncol = 1))
	#~~
	#~~calculates inv CM11
	.intrf.flCM11inv__set(1)
	#~~
	#~
}
