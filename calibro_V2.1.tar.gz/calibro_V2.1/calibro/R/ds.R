#  This file is part of Calibro.
#
#  Calibro is free software; you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation; either version 2 of the License, or
#  (at your option) any later version.
#  
#  Calibro is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#  
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software
#  Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
#  MA 02110-1301, USA.

#_DOC_
#CALIBRATION DATASET
#A calibration dataset collects all the information necessary to undertake a calibration.

#* DS CLASS
ds = R6Class('ds', 
	#_DOC_
	#A datasets consists of: observations (Y.star), simulations (Y), boundary conditions (X), simulated combinations of
	#calibration parameters (TT), observation error (obs.se).
	inherit = calibro.obj,
	#** public
	public = list(
		Y.star.se = NULL,
		obs.cnf = NULL,
		#*** methods
		#**** initialize
		initialize = function (name, Y.star, Y, X = NULL, TT, Y.star.se = NULL, obs.cnf = 0.8) {
			#_DOC_
			#Initialises the database object.
			#_ARGUMENTS_
			#name: name or short description of the databese
			#Y.star: list of matrices containing the observations (1 matrix per target variable)
			#Y: list of matrices containing the model predictions (1 matrix per model output)
			#X: list of matrices contaning the boundary conditions characterising the observations in Y.star
			#TT: matrin having as columns the values of the model inputs
			#Y.star.se: standard error to associate to the observed values
			#obs.cnf: relazation factor indicating the confidence of the analyst in the information used to define Y.star.se
			#_MAIN_
			self$name = name
			Y.star = private$chck.frmt.XY(Y.star)
			private$.Y.star = private$cln.XY(Y.star)
			Y = private$chck.frmt.XY(Y)
			private$.Y = private$cln.XY(Y)
			if (!is.null(X)) X = private$chck.frmt.XY(X)	#remove if statemnt to enable boudary conditions
			if (!is.null(X)) private$.X = private$cln.XY(X)	#remove if statement to enable boundary conditions
			private$.TT = private$chck.frmt.TT(TT)
			self$obs.cnf = obs.cnf
			self$Y.star.se = Y.star.se
			private$chck.dim()
		},
		#**** predict
		predict = function (mdl, Z.star = NULL, n = 0) {
			#_DOC_
			#Provides an interface to make predictions with the reduction object (only PCA now)
			#relatively to the dataset and the performed transformations.
			#_ARGUMENTS_
			#mdl: which model ('cals' for calibrators, 'mdls' for emulators)
			#Z.star: list of matrices containing the predictions locations
			#n: sample size
			#_MAIN_
			Y.hat = private$.rd$predict(mdl = mdl, Z.star = Z.star, n = n)
#			if (!is.null(private$.rm)) {
#				pMu = rep(0, nrow(rbind.list(private$.Y.star)))
#				pMu[private$.rm[,1]] = private$.rm[,2]
#				pMu[-private$.rm[,1]] = Y.hat[['pMu']]
#			} else {
				pMu = Y.hat[['pMu']]
#			}
			pMu.list = list()
			for (i in 1:length(private$.Y.star)) {
				pMu.list[[i]] = as.matrix(pMu[1:nrow(private$.Y.star[[i]])])
				pMu = pMu[-(1:nrow(private$.Y.star[[i]]))]
				colnames(pMu.list[[i]]) = colnames(private$.Y.star[[i]])
			}
			names(pMu.list) = names(private$.Y.star)
			if (!is.null(Y.hat[['SMP']])) {
				if (!is.null(private$.rm)) {
					SMP = matrix(0, nrow = nrow(rbind.list(private$.Y)), ncol = ncol(Y.hat[['SMP']]))
					SMP[private$.rmp[,1],] = private$.rm[,2]
					SMP[-private$.rmp[,1],] = Y.hat[['SMP']]
				} else {
					SMP = Y.hat[['SMP']]
				}
				SMP.list = list()
				for (i in 1:length(private$.Y.star)) {
					SMP.list[[i]] = as.matrix(SMP[1:nrow(private$.Y.star[[i]]),])
					SMP = SMP[-(1:nrow(private$.Y.star[[i]])),]
					colnames(SMP.list[[i]]) = paste0(colnames(private$.Y.star[[i]]), 1:ncol(SMP))
				}
				names(SMP.list) = names(private$.Y.star)
			} else {
				SMP.list = NULL
			}
			return(list('pMu' = pMu.list, 'SMP' = SMP.list))
		},
		#**** gof
		gof = function (mdl, gof) {
			#_DOC_
			#Calculates a Goodness Of Fit (gof) criterion relatively to the dataset
			#_ARGUMENSTS_
			#mdl: model for which to calcualte the gof. 'sim' provided simulations (returns the best value), 
			#	'mdl' trained model respect to simulations, 'cal' trained model respect to observations
			#gof: function or character indicating the kind of gof
			#_MAIN_ 
			.mthd.gof.ds(self, mdl, gof)
		},
		bestSim = function (ind = F) {
			#_DOC_
			#Returns the conbination of inputs corresponding to the best simulation.
			#_ARGUMENTS_
			#gof: gof criterion (character)
			#ind: T => return the index
			#_MAIN_
			.mthd.bestSim.ds(self, ind)	
		},
		plot = function (what = 'Y', int = T, ...) {
			.mthd.plot.ds(self, what, int, ...)	
		},
		#**** print
		print = function () {
			#_DOC_
			#Printign method
			#_MAIN_
			.mthd.print.ds(self)
		}		
	),
	#** active
	active = list(
		rd = function (type) {
			#_DOC_
			#Return/set the reduction for the dataset.
			#_ARGUMENTS_
			#type: kind of reduction (now only 'pca' available)
			#_MAIN_
			if(missing(type)){return(private$.rd)}else{.actmthd.wrp(self, type, .mthd.rd.ds)}
		},
		sa = function (type) {
			#_DOC_
			#Return/set the sensitvity analysis for the dataset.
			#_ARGUMENTS_
			#type: kinf of sensitivity analysis
			#_MAIN_
			if(missing(type)){return(private$.rd$sa)}else{.actmthd.wrp(self, type, .mthd.sa.ds)}
		},
		ret = function (type) {
			#_DOC_
			#Return the retained factors/set the retention criterion.
			#_MAIN_
			#type: kind of retention criterion.
			#_MAIN_
			if(missing(type)){return(private$.rd$ret)}else{.actmthd.wrp(self, type, .mthd.ret.ds)}
		},
		mdls = function (mdl) {
			#_DOC_
			#Returns/sets the models for the dataset
			#_ARGUMENTS_
			#mdl: kind of model
			#_MAIN_
			if(missing(mdl)){return(private$.rd$mdls)}else{.actmthd.wrp(self, mdl, .mthd.set_mdls.ds)}
		},
		cals = function (mdl) {
			#_DOC_
			#Sets/returns the calibration model.
			#_ARGUMENTS_
			#mdl: kind of model
			#_MAIN_
			if(missing(mdl)){return(private$.rd$cals)}else{.actmthd.wrp(self, mdl, .mthd.set_cals.ds)}
		},
		TT = function () {
			#_DOC_
			#Returns the input matrix.
			#_MAIN_
			return(private$.TT)
		},
		TT.nms = function () {
			#_DOC_
			#Returns the names of the parameters of the input matrix.
			#_MAIN_
			return(colnames(private$.TT))
		},
		TT.rngs = function (rngs) {
			#_DOC_
			#Sets/returns the rnages of the parameters (for scaling purposes).
			#_MAIN_
			if(missing(rngs)){.mthd.get_TT_rngs.ds(self)}else{.actmthd.wrp(self, rngs, .mthd.set_TT_rngs.ds)}
		},
		theta = function (vars) {
			#_DOC_
			#Sets/returns the calibration parameters.
			#_ARGUMENTS_
			#vars: r6.list containing the uvrv representign the calibration parameters
			#_MAIN_
			if(missing(vars)){return(private$.theta)}else{.actmthd.wrp(self, vars, .mthd.set_theta.ds)}
		},
		Y = function () {
			#_DOC_
			#Return training targets.
			#_MAIN_
			return(private$.Y)
		},
		X = function () {
			#_DOC_
			#Returns the boundary conditions.
			return(private$.X)
		},
		Y.star = function () {
			#_DOC_
			#Returns the observed values.
			#_MAIN_
			return(private$.Y.star)
		},
		train = function (pars) {
			#_DOC_
			#Returns/sets and perform the training of the meta-models.
			#_ARGUMENTS_
			#pars: list of paramters for the 'opt' class object.
			#_MAIN_
			if (missing(pars)) {return(private$.rd$train)} else {.actmthd.wrp(self, pars, .actmthd.train.ds)}
		}
	),
	#** private
	private = list(
		#*** attributes
		.Y.star = NULL,		#observation matrices 
		.X = NULL,			#boundary conditions matrices
		.TT = NULL,			#simulated calibration parameter matrices
		.Y = NULL,			#simulation matrices
		.TT.rngs = NULL,	#theta ranges
		.rd = NULL,			#reduction applied to the dataset
		.theta = NULL,		#r6.list containing the uvrvs for theta
		.rm = NULL,			#removed data
		#*** methods
		#**** chck.frmt.X
		chck.frmt.TT = function (X) {
			#_DOC_
			#Checks that the input matrix has the correct format.
			#_ARGUMENTS_
			#X: TT matrix
			#_MAIN_
			.prvmthd.chck_frmt_TT.ds(X)
		},
		chck.frmt.XY = function (Y) {
			#_DOC_
			#Checks that the boundary conditions (or Y or Y.star) has the correct format.
			#_ARGUEMNTS_
			#Y: X, Y, or Y.star
			#_MAIN_
			.prvmthd.chck_frmt_XY.ds(Y)
		},
		cln.XY = function (Y) {
			#_DOC_
			#Checks that the boundary conditions (or Y or Y.star) has the correct format.
			#_ARGUEMNTS_
			#Y: X, Y, or Y.star
			#_MAIN_
			.prvmthd.clean_XY.ds(Y)
		},
		#**** chck.dim
		chck.dim = function () {
			#_DOC_
			#Checks that the data in the dataset have the correct dimensions.
			#_MAIN_
			.prvmthd.chck_dim.ds(self)
		},
		#**** rd.pca
		rd.pca = function () {
			#_DOC_
			#Undertakes Principal Componenet Analysis on the dataset.
			#_MAIN_
			.prvmthd.pca.ds(self)
		},
		#**** gof.sim
		gof.sim = function (gof) {
			#_DOC_
			#Retuns the best simulation according to gof.
			#_MAIN_
			.prvmthd.gof_sim.ds(self, gof)
		}
	)
)

#* METHOD FUNCTIONS
#_DOC_
#Functions called as methods of the 'ds' class.
#In the following DS indicate a 'ds' class object.
.mthd.gof.ds <- function (DS, mdl, gof) {
	#_DOC_
	#Interface to calculated different gof criterion relatively to the dataset.
	#_ARGUMENTS_
	#mdl: which model ('cals' for calibrators, 'mdls' for emulators, 'sim' for simulations)
	#gof: which goodness of fit criterion
	#_MAIN_
	if (mdl == 'sim') {
		DS$.get.private('gof.sim')(gof)
	} else {
		Y.hat = DS$predict(mdl = mdl, Z.star = NULL, n = 0)
		sapply(names(Y.hat[['pMu']]), function(nm)do.call(gof, list(y = DS$Y.star[[nm]], y.hat = Y.hat[['pMu']][[nm]])))
	}
}
.mthd.print.ds = function (DS) {
	#_DOC_
	#Prints a human friendly version of the object.
	#_MAIN_
	Y.star.nms = paste(names(DS$Y.star), collapse = ', ')
	X.nms = paste(names(DS$X), collapse = ', ')
	TT.nms = paste(colnames(DS$TT), collapse = ', ')
	cat(paste('Calibration dataset:', DS$name, '\n')) 
	cat(paste('* targets/simulations:', paste(Y.star.nms, collapse = ', '), '\n'))  
	cat(paste('* boundary conditions:', paste(X.nms, collapse = ', '), '\n')) 
	cat(paste('* parameters:', paste(TT.nms, collapse = ', '), '\n'))
}	
.mthd.plot.ds <- function (DS, what, int, ...) {
	#_DOC_
	#Plots a componenet of the calibration dataset.
	#_ARGUMENTS_
	#what: what to plot ('Y': measuremtns/simulations, 'TT': inputs, 'X': boundary conditions)
	#int: interactive? ask to proceed to next plot each time.
	#_MAIN_
	plt.fun = getFromNamespace(paste0('..plot_', what, '.ds'), ns = .NSNAME)
	plt.fun(DS = DS, int = int, ...)
}
..plot_Y.ds <- function (DS, int, ...) {
	#_DOC_
	#Plots the measuremtns/simulation plot.
	#_ARGUMENTS_
	#int: interactive?
	#...: additional arguments for the 'plot' function.
	#_MAIN_
	for (i in 1:length(DS$Y)) {
		par(mar = c(4,5,1,1), bty = 'n')
		yl = range(DS$Y[[i]], DS$Y.star[[i]])
		y.name = paste0(names(DS$Y[i]), ' & ', names(DS$Y.star[i]))
		matplot(DS$Y[[i]], ty='l', col = 'darkgrey', lty = 1, main = '', ylab = y.name, xlab = 'time', ...)
		lines(DS$Y.star[[i]], lwd = 2, col = 2)
		if (int) {
			scan()
			dev.off()
		}
	}	
}
..plot_X.ds <- function (DS, int, ...) {
	#_DOC_
	#Plots the boundary conditions.
	#_ARGUMENTS_
	#int: interactive?
	#...: additional arguments for the 'plot' function.
	#_MAIN_
	for (i in 1:length(DS$X)) {
		par(mfrow=c(ncol(DS$X[[i]]), 1), mar = c(4,5,1,1), bty = 'n')#c(bottom, left, top, right)
		for (j in 1:ncol(DS$X[[i]])) {
			y.name = colnames(DS$X[[i]])[j]
			if (j == ncol(DS$X[[i]])) {
				xlb = 'time'
			} else {
				xlb = ''
			}
			plot(DS$X[[i]][,j], ty='l', main = '', ylab = y.name, xlab = xlb, ...)
		}
		if (int) {
			scan()
			dev.off()
		}
	}	
}
..plot_TT.ds <- function (DS, int, p, ...) {
	#_DOC_
	#Plots the inputs.
	#_ARGUMENTS_
	#int: interactive?
	#p: indexes of the inputs to plot.
	#_MAIN_
	if (missing(p)) {
		X = DS$TT
	} else {
		X = DS$TT[,p]
	}
	calibro.pairs(X, main = '', ...) 
}
..plot_fit.ds <- function (DS, int, ...) {
	#_DOC_
	#Plots the fit between calibrated model and measurements.
	#_ARGUMENTS_
	#int: interactive?
	#_MAIN_
	Y.hat = DS$predict(mdl = 'cals', Z.star = NULL, n = 300)
	for (i in 1:length(DS$Y.star)) {
		yl = range(Y.hat[['SMP']][[i]], DS$Y.star[[i]])
		y.name = paste0(names(DS$Y.star[i]))
		matplot(Y.hat[['SMP']][[i]], ty='l', col = 'darkgrey', lty = 1, main = '', ylab = y.name, xlab = 'time', ...)
		lines(DS$Y.star[[i]], lwd = 2, col = 2)
		lines(Y.hat[['pMu']][[i]], lwd = 1)
		if (int) {
			scan()
			dev.off()
		}
	}	
}
.mthd.rd.ds <- function (DS, type) {
	#_DOC_
	#Perform the reduction of the dataset.
	#_ARGUMENTS_
	#type: type of reduction.
	#_MAIN_
	DS$.get.private(paste0('rd.', type))()
	invisible()
}
.mthd.sa.ds <- function (DS, type) {
	#_DOC_
	#Performs/returns sensitivity analysis.
	#_ARGUMENTS_
	#type: which type of SA (currently only 'sobolSmthSpl' is allowed)
	#_MAIN_
	RD = DS$.get.private('.rd')
	RD$sa = type
	invisible()
}
.mthd.ret.ds <- function (DS, type) {
	#_DOC_
	#Performs parameter and componenet retention.
	#_ARGUMENTS_
	#type: type of retention cirterion
	#_MAIN_
	RD = DS$.get.private('.rd')
	RD$ret = type
	invisible()
}
.mthd.set_mdls.ds <- function (DS, mdl) {
	#_DOC_
	#Builds the model for the dataset.
	#_ARGUMENTS_
	#mdl: which kind of model (currenlty only 'gpr.ng')
	#_MAIN_
	RD = DS$.get.private('.rd')
	RD$mdls = mdl
	invisible()
}
.actmthd.train.ds <- function (DS, pars) {
	#_DOC_
	#Builds the model for the dataset.
	#_ARGUMENTS_
	#mdl: which kind of model (currenlty only 'gpr.ng')
	#_MAIN_
	RD = DS$.get.private('.rd')
	RD$train = pars 
	invisible()
}
.mthd.set_cals.ds <- function (DS, mdl) {
	#_DOC_
	#Builds the calibrator for the model.
	#_ARGUMENTS_
	#mdl: which kind of calibrator (currently 'gpr.ng' or 'gpr.ngd')
	#_MAIN_
	rm = DS$.get.private('.rm')
	if (!is.null(rm)) {
		Y.star = as.matrix(rbind.list(DS$Y.star)[-rm[,1],])
	} else {
		Y.star = rbind.list(DS$Y.star)
	}
	RD = DS$.get.private('.rd')
	RD$Y.star = Y.star
	RD$theta = DS$theta
	RD$obs.cnf = DS$obs.cnf
	RD$Y.star.se = DS$Y.star.se
	RD$cals = mdl
	invisible()
}
.mthd.get_TT_rngs.ds <- function (DS) {
	#_DOC_
	#Returns the ranges of the calibration parameters.
	#_MAIN_
	rngs = DS$.get.private('.TT.rngs')
	if (is.null(rngs)) {
		rngs = apply(DS$TT, 2, range)
		DS$.set.private('.TT.rngs', val = rngs)
	}
	return(rngs)
}
.mthd.set_TT_rngs.ds <- function (DS, rngs) {
	#_DOC_
	#Sets the ranges of the calibration parameters (scaling purpose).
	#_ARGUMENTS_
	#rngs: ranges
	#_MAIN_
	DS$.set.private('.TT.rngs', val = rngs)
	invisible()
}
.mthd.set_theta.ds <- function (DS, vars) {
	#_DOC_
	#Sets the uvrv representing the calibration parameters.
	#_ARGUMENTS_
	#vars: r6.list of uvrv variables representing the calibration parameters.
	#_MAIN_		
	theta = r6.list$new(name = paste0(DS$name, '.theta'), objs = vars, cl = 'uvrv')	
	DS$.set.private('.theta', val = theta)	
	invisible()	
}
.prvmthd.chck_frmt_TT.ds <- function (X) {
	#_DOC_
	#Cehcks that the format of X is complaint.
	#_ARGUMENTS_
	#X: TT (input matrix)
	#_CONTAINS_
	frmt.err <- function (V) {
		stop(paste(V, 'must be matrix with named columns'))
	}
	#_MAIN_
	if (!is(X, 'matrix')) frmt.err(deparse(substitute(X)))
	if (any(is.null(colnames(X)))) frmt.err(deparse(substitute(X)))
	return(X)
}
.prvmthd.chck_frmt_XY.ds <- function (Y) {
	#_DOC_
	#Checkes that the format of Y is complaint.
	#_ARGUMENTS_
	#Y: Y (simulation lis to matrices) or Y.star (observation list of matrices) 
	#_CONTAINS_
	frmt.err <- function (V) {
		stop(paste(V, 'must be a named list of matrices'))
	}
	#_MAIN_
	if (!is(Y, 'list')) frmt.err(deparse(substitute(Y)))
	if (any(is.null(names(Y)))) frmt.err(deparse(substitute(Y)))
	if (any(sapply(Y, function(x)!is(x, 'matrix')))) frmt.err(deparse(substitute(Y)))
	return(Y)
}
.prvmthd.clean_XY.ds <- function (Y) {
	#_DOC_
	#Checkes that the format of Y is complaint.
	#_ARGUMENTS_
	#Y: Y (simulation lis to matrices) or Y.star (observation list of matrices) 
	#_CONTAINS_
	frmt.err <- function (V) {
		stop(paste(V, 'must be a named list of matrices'))
	}
	cln <- function (X, Xnm) {
		nm = colnames(X)
		topop = which(sapply(nm, grepl, pattern = 'time', ignore.case = T))
		if (length(topop) > 0) {
			warning(paste0('possible "time" column found in ', Xnm, '. It has been removed.')) 
			return(X[,-topop, drop = F])
		} else {
			return(X)
		}
	}
	#_MAIN_
	nms = names(Y)
	for (i in 1:length(nms)) Y[[i]] = cln(Y[[i]], nms[i])
	return(Y)
}
.prvmthd.chck_dim.ds <- function (DS) {
	#_DOC_
	#Checks the dimensions of the dataset componenets.
	#_MAIN_
	Y.star = DS$.get.private('.Y.star')
	Y = DS$.get.private('.Y')
	#X = DS$.get.private('.X')	#uncomment to enable boundary conditions
	TT = DS$.get.private('.TT')
	if (length(Y.star) != length(Y)) {	#this line to turn off boundary conditions
#	if (length(Y.star) != length(Y) || length(Y.star) != length(X)) {	#this line to turn on boundary conditions
		stop('the number of matrices in Y.star, Y and X must be equal.')
	} 
	if (any(sapply(Y, nrow) != sapply(Y.star, nrow))) {	#this line to turn off boundary conditions 
#	if (any(sapply(Y, nrow) != sapply(Y.star, nrow)) || any(sapply(Y.star, nrow) != sapply(X, nrow))) {	#this line to turn on boundary conditions 
		stop('the matrices in Y.star, Y, and X must have the same number of rows.')
	}
	if (any(sapply(Y, ncol) != nrow(TT))) {
		stop('the matrices in Y must have numbers of columns equal to the number of rows of TT')
	}
	invisible()
}
.prvmthd.pca.ds <- function (DS) {
	#_DOC_
	#Perform PCA on a ds according to the number of periods and accuracy defined in the calibration environment
	#_MAIN_
	#pca on Y:
	Y = rbind.list(DS$Y)
	rm = which(apply(Y, 1, function(x)all(x == x[1])))
#	if (length(rm) > 0) {
#		rm = cbind(rm, Y[rm,])
#		Y = as.matrix(Y[-rm[,1],])
#		DS$.set.private('.rm', val = rm)
#	}
	if (length(DS$Y) > 1) {
		C = F
		S = T
	} else {
		C = F
		S = F
	}
	RD = pca$new(
		name = DS$name, 
		Y = Y, 
		X = normalize(DS$TT, MINS = DS$TT.rngs[1,], MAXS = DS$TT.rngs[2,]), 
#		BC = normalize(rbind.list(DS$X)),	#uncomment to turn on boundary conditions
		C = C, 
		S = S
	)
	DS$.set.private('.rd', val = RD)
}
.prvmthd.gof_sim.ds <- function (DS, gof) {
	#_DOC_
	#Calculates the specified gof for the simulation sample.
	#_ARGUMENTS_
	#gof: gof criterion (character)
	#_MAIN_
	y.star = rbind.list(DS$Y.star)
	ANS = min(apply(rbind.list(DS$Y), 2, function(x)do.call(gof, list(y = y.star, y.hat = x))))
	return(ANS)
}	
.mthd.bestSim.ds <- function (DS, ind = F) {
	#_DOC_
	#Returns the conbination of inputs corresponding to the best simulation.
	#_ARGUMENTS_
	#gof: gof criterion (character)
	#ind: T => return the index
	#_MAIN_
	y.star = rbind.list(DS$Y.star)
	i = which.min(apply(rbind.list(DS$Y), 2, function(x)rmse(y = y.star, y.hat = x)))
	if (ind) {
		return(i)
	} else { 
		return(DS$TT[i,])
	}
}	
