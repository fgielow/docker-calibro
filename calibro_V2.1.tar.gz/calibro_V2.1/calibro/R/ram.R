#  This file is part of Calibro.
#
#  Calibro is free software; you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation; either version 2 of the License, or
#  (at your option) any later version.
#  
#  Calibro is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#  
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software
#  Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
#  MA 02110-1301, USA.

#_DOC_
#ROBUST METROPOLIS ALGORITHM (RAM)
#Reference: Vihola, M. Robust adaptive Metropolis algorithm with coerced acceptance rate. Statistics and Computing, Springer Nature, 2011, 22, 997–1008 

#* PARAMETERS
#_DOC_
#Parameters needed to run a simulation of the ram algorithm

.par.default_state = list(
	#_DOC_
	#List containing the fields characterising the state of the algorithm.
	#By defaul the state fields are initialised to their default values.
	#_FIELDS_
	'z' = function (...) ..z.default(...),
	'S' = function (...) ..S_default.ram(...)
)

#* RAM CLASS
ram = R6Class('ram',
	#_DOC_
	#Class representing a simulation of the ram algorithm.
	inherit = amcmc,
	#** private
	private = list(
		#*** attributes
		.state_skel = list('z' = NULL, 'S' = NULL),				#skeleton list for the state
		.default_state = .par.default_state,					#lisf with functions for default initialisation of the state
		#*** methods
		.init_alg = function (...) ..init.ram(...),				#initialises the variables needed to run the algorithm
		.run_alg = function (...) ..run.ram(...),				#only run the algorithm (i.e must be caaled after .init_alg)
		.print_start = function (...) ..print_start.ram(...)	#print an header for the simulation
	)
)

..init.ram <- function (z, adapt, S, nBatches, lBatch, fp, ...) {
	#_DOC_
	#Initialises all the array needed to launch AMG
	#_ARGUMENTS_
	#z: initial input vector
	#adapt: > 0 => adapts the proposal distributions
	#lnSigmas: initial log variances of the proposals
	#nBatches: number of batches
	#lBatch: number of iteration per batch
	#_
	#_MAIN_
	#init genral parameters
	.intrf.amcmc__set_nlevels(1)
	.intrf.nBatches__init(nBatches)  
	.intrf.lBatch__init(lBatch)  
	.intrf.iter__init(0)
	.intrf.beta__init(1)
	.intrf.amcmc__set_alg(1)
	.intrf.amcmc__set_adapt(adapt)
	#init z
	.intrf.amcmc__z_init(z)
	#
	.intrf.u__init(fp*0)
	.intrf.fp__init(fp)
	.intrf.S__init(S)
}

..run.ram <- function (mdl, z, nBatches, S, ...) {
	#_DOC_
	#Runs the RAM simulation.
	#_ARGUMENTS_
	#mdl: model to process
	#z: initial parameters values
	#nBataches: number of batches
	#S: LT matrix of the covariance matrix, of the model parameters proposal distribution.
	#...: additional ignored arguments.
	#_MAIN_
	ANS  = .intrf.ram__run(z, nBatches, S)
	ANS[['z']] = ANS[['Z']][nrow(ANS[['Z']]),]
	nms = mdl$pars$get.attr('name', exp = T, cp.rm = T, wrap = F, mode = 'sapply')
	colnames(ANS[['Z']]) = nms
	names(ANS[['z']]) = nms
	names(ANS[['bestz']]) = nms
	return(ANS) 
}
..print_start.ram <- function (start.time, m, n, ...) {
	#_DOC_
	#Prints a message at the start of the RAM simulation.
	#_ARGUMENTS_
	#strat.time: start time
	#m: number of chains
	#n: number of simulations
	#...: additional ignored arguments
	#_MAIN_
	cat(paste('\n### ROBUST ADAPTIVE METROPOLIS ALGORITHM ###\n\n Start time:', start.time, 
			'\n Number of chains:', m, '\n Number of simulations:', n, '\n\n'))
}
..S_default.ram <- function (mdl, fp, ...) {
	#_DOC_
	#Initialises the LT matrix (Cholesky decomposition) to default values.
	#_ARGUMENTS_
	#mdl: model to simulate
	#fp: indexes of the free parameters
	#...: additional ignored arguments
	#_MAIN_
	sigmas = apply(mdl$pars$exe.mthd('r', n = 1000, exp = T, cp.rm = T, wrap = F, mode = 'sapply'), 2, sd)
	diag(sigmas[fp])/sqrt(length(fp))
}
.intrf.ram__run <- function (z, nBatches, S) {
	#_DOC_
	#Runs the AMG algorithm for the current initial input vector, number of bathches and proposal log variances
	#_ARGUMENTS_:
	#z: input vector
	#nBatches: number of batches
	#lnSigmas: log proposal variances
	##_MAIN_ 
	ANS = .C('__ram_MOD_intrf_ram__run', 
			'lz' = as.integer(length(z)),
			'Z' = double(length(z)*nBatches),
			'm' = nrow(S),
			'lnpd' = double(nBatches),
			'bestz' = double(length(z)),
			'bestLnpd' = double(1),
			'S' = as.double(S)
		)
	#makes Z a matrix	
	ANS[['S']] = matrix(ANS[['S']], nrow = sqrt(length(ANS[['S']])))
	ANS[['Z']] = matrix(ANS[['Z']], nrow = nBatches, ncol = length(z))
	return(ANS)	
}
.intrf.u__init <-function (u) {
	#_DOC_
	#Initialises the update vector u_
	#_MAIN_
	ANS = .C('__ram_MOD_intrf_u__init', 
		'n' = as.integer(length(u)),
		'u' = as.double(u)
	)
}
.intrf.S__init <- function (S) {
	#_DOC_
	#Initialises the LT matrix for the RAM algorithm
	#_MAIN_
	if (length(dim(S)) == 2) {
		l = 1
	} else if (length(dim(S)) == 3) {
		l = dim(S)[3]
	} else {
		stop('errors!!')
	}
	ANS = .C('__ram_MOD_intrf_s__init',
		'm' = as.integer(nrow(S)),
		'n' = as.integer(ncol(S)),
		'l' = as.integer(l),
		'S' = as.double(S)
	)
}

#* INTERFACES TO FORTRAN SUBROUTINES

.intrf.S__shape <- function () {
	#_DOC_
	#Retrieves the shape of the array S_ in the Fortran environment.
	#_MAIN_
	.C('__ram_MOD_intrf_s__shape', integer(3))[[1]]
}
.intrf.S__get <- function () {
	#_DOC_
	#Retreives the array S_ from the Fortran environment.
	#_MAIN_
	shp = .intrf.S__shape()
	ANS = .C('__ram_MOD_intrf_s__get', 'S' = double(prod(shp)), 'm' = as.integer(shp[1]), 'n' = as.integer(shp[2]), 'r' = as.integer(shp[3]))
	return(drop(array(ANS[['S']], dim = shp)))
}
	

