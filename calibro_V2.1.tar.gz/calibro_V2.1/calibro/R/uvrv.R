#  This file is part of Calibro.
#
#  Calibro is free software; you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation; either version 2 of the License, or
#  (at your option) any later version.
#  
#  Calibro is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#  
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software
#  Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
#  MA 02110-1301, USA.

.uvrv.symb = list(
	'const' = 'Const',
	'unif' = 'Unif',
	'beta' = 'Beta',
	'gamma' = 'Gamma',
	'gampar' = 'Gamma',
	'norm' = 'Norm',
	'exp' = 'Exp',
	'gamcmp' = 'Gamma_cmp',
	'iexp' = 'iExp'
)

#* .uvrv CLASS
.uvrv = R6Class('uvrv',
	#_DOC_
	#Root class for uvrv objects. All uvrv object inherit this class
	inherit = calibro.obj,
	#** public
	public = list(
		#*** attributes
		pars = NULL,	#named list of parameters
		cnv.rule1 = list( 
			t.max = 0.01,		#tollerance for estimation purposes
			size.min = 1000		#min size for sampling purposes
		),
		#*** methods
		#**** p
		p = function(p, lwt = 1, ln = 0){
			#_DOC_
			#Cumulative probability funuction.
			#_ARGUMENTS_
			#p: values
			#lwt: if T lower tail otherwise upper tail
			#ln: if T it returns the log
			#_MAIN_
			fortPars = private$smp.uvrv.pars(self$.fortPars())
			sapply(p, function(x).C('__uvrv_MOD_intrf_uvrv__p', double(1), as.double(x), as.integer(fortPars[1]), as.integer(length(fortPars[-1])),
				as.double(fortPars[-1]), as.integer(lwt), as.integer(ln))[[1]])
		},		
		#**** d
		d  = function (x, ln = 0) {
			#_DOC_
			#Probability density function.
			#_ARGUMENTS_
			#x: value
			#_MAIN_
			fortPars = private$smp.uvrv.pars(self$.fortPars())
			sapply(x, function(x).C('__uvrv_MOD_intrf_uvrv__d', double(1), as.double(x), as.integer(fortPars[1]), as.integer(length(fortPars[-1])), 
				as.double(fortPars[-1]), as.integer(ln))[[1]])
		},
		#**** q
		q = function (q, lwt = 1, ln = 0) {
			#Qunatile fuunction.
			#_ARGUMENTS_
			#q: quantiles
			#lwt: if T lower tail otherwise upper tail
			#ln: if T q is in log scale
			#_MAIN_
			if (self$.id == 0) {
				return(rep(self$map, length(q)))
			} else {
				fortPars = private$smp.uvrv.pars(self$.fortPars())
				sapply(q, function(x).C('__uvrv_MOD_intrf_uvrv__q', double(1), as.double(x), as.integer(fortPars[1]), as.integer(length(fortPars[-1])),
					as.double(fortPars[-1]), as.integer(lwt), as.integer(ln))[[1]])
			}
		},
		#**** r
		r = function (n) {
			#_DOC_
			#Random number generation
			#_ARGUMENTS_
			#n: size of the random sample.
			#_MAIN_
			if (self$.id <= 0) {
				return(rep(self$map, n))
			} else {
				smp = c()
				for (i in 1:n) {
					fortPars = private$smp.uvrv.pars(self$.fortPars())
					smp = c(smp, 
						.C('__uvrv_MOD_intrf_uvrv__r', double(1), as.integer(fortPars[1]), as.integer(length(fortPars[-1])), as.double(fortPars[-1]))[[1]]
					)
				}
				return(smp)
			} 
		},
		curve = function (...) {
			#_DOC_
			#Uses the curve function to plot the probability density distribution of the variable.
			#_ARGUMENTS_
			#...: arguments to be passed to curve
			#_MAIN_
			.mthd.curve.uvrv(self, ...)
		},
		#**** get.uvrv.pars
		get.uvrv.pars = function () {
			#_DOC_
			#Returns the parameter of the uvrv that are in turn uvrv.
			#_MAIN_
			uvrv.pars = NULL
			for (p in self$pars) if (is(p, 'uvrv')) uvrv.pars = c(uvrv.pars, p)
			return(uvrv.pars)
		},
		#**** print
		print = function () {
			pars = paste0(sapply(self$pars, function(x)ifelse(is(x, 'numeric'), signif(x, 4), x$name)), collapse = ', ')
			cat(paste0('\t', self$name, ' ~ ', private$symb(), '(', pars, ')\n'))
			if (!is.null(self$get.uvrv.pars())) cat('\n\t where:\n')
			for (p in self$pars) if (is(p, 'uvrv')) p$print()
		}, 
		#**** .fortPars
		.fortPars = function () {
			#_DOC_
			#Generates a list of parameter to pass to the Fortran routines
			#_MAIN_
			return(c(self$.id, unlist(self$pars)))
		}
	),
	#** active
	active = list(
		#*** map
		map = function (val) {
			#_DOC_
			#Softly sets the MAP vlaue of the variable.
			#The variable is considered estimated and not random anymore.
			#_MAIN_
			if (missing(val)) {
				return(private$.map)
			} else {
				if (private$..state != 0) {
					private$.map = val
					if(is.null(val)){private$..state = 1}else{private$..state = -1}
				}
			}
		},
		#*** MAP
		MAP = function (val) {
			#_DOC_
			#Strongly sets the MAP vlaue of the variable.
			#The variable is considered estimated and not random anymore.
			#_MAIN_
			if (missing(val)) {
				return(private$.map)
			} else {
				if (private$..state != 0) {
					private$.map = val
					if(is.null(val)){private$..state = 1}else{private$..state = 0}
				}
			}
		},
		#*** id
		.id = function () {
			#_DOC_
			#Returns the id identifying the uvrv in Fortran.
			#_MAIN_
			ifelse(is.null(private$.map), private$..id(), 0)
		},
		#*** .state
		.state = function (x) {
			#_DOC_
			#Return the state of the variable.
			#_MAIN_
			if (missing(x)) {return(private$..state)} else {}
		},
		.cstr = function () return(private$..cstr)
	),
	#** private
	private = list(
		#*** attributes
		..cstr = NULL, 
		.map = NULL,	#Maximum A Posteriori value
		symb = function().uvrv.symb[[class(self)[1]]],	#symbol for printing the vairable to screen
		..state = 1,	#state of the variable
		#*** ..id
		..id = function () .intrf.uvrv__id(class(self)[1]),
		#**** smp.uvrv.pars
		smp.uvrv.pars = function (fortPars) {
			#_DOC_
			#Sample the distribution parameters that are uvrv themselves and put the values in fortPars.
			#_ARGUMENTS_
			#fortPars: Fortran parameter list
			#_MAIN_
			for (i in 1:length(fortPars)) {
				if (is(fortPars[[i]], 'uvrv')) fortPars[[i]] = fortPars[[i]]$r(1)
			}
			return(fortPars)
		}	
	)
)

.mthd.curve.uvrv <- function (uvrv, ...) {
	#_DOC_
	#Uses the function 'curve' to plot different functions linked to the 'uvrv' class object.
	#_ARGUMENTS_
	#...: arguments to pass to 'curve'
	#_MAIN_
	args = list(...)
	if (is.null(args[['fun']])) {
		fun = 'd'
	} else {
		fun = args[['fun']]
		args[['fun']] = NULL
	}
	args[['expr']] = expression(uvrv[[fun]](x))
	args[['xlab']] = uvrv$name
	args[['ylab']] = paste0(fun, '(x)')
	if (is.null(args[['xlim']])) {
		if (fun == 'd' || fun == 'p') {
			args[['xlim']] = uvrv$q(c(0.0001, 0.9999))
		} 
	}
	if (is.null(args[['ylim']])) {
		if (fun == 'q') {
			args[['ylim']] =  uvrv$q(c(0.0001, 0.9999))
		} 
	}
	do.call('curve', args)
}

#* DIFFERENT TYPE OF UVRV IMPLEMENTED
#_DOC_
#In the following are listed the implemented kinds of 'uvrv'.
#The active bindings 'var', 'mean', and 'mode' always return the variance, mean and mode of the 
#'uvrv' class object respectively.

#* uvrv.const CLASS
uvrv.const = R6Class('const',
	#_DOC_
	#This class represent a fictitious uvrv and can be used to represent values that do not change during the calculations.
	inherit = .uvrv,
	#** public
	public = list(
		#*** methods
		#**** initialize
		initialize = function (name = NULL, map) {
			#_DOC_
			#Initialises the obj.
			#_ARGUMENTS_
			#name: name/description (short) of the variable
			#map: maximum a posteriori values (estimate)
			#_MAIN_
			self$name = name
			self$pars = list('min' = map, 'max' = map)
			private$.map = map
			private$..cstr = 0
		}
	),
	#** active
	active = list(
		#*** map
		map = function (val) {
			if (missing(val)) {
				return(private$.map)
			} else {
				warning('map attribute cannot be changed for uvrv.const objects.')
			}
		},
		#*** var
		var = function(x) {
			if (missing(x)) {return(0)} else {}
		},
		#*** mean
		mean = function (x) {
			if (missing(x)) {return(self$map)} else {}
		},
		#*** mode
		mode = function (x) {
			if (missing(x)) {return(self$map)} else {}
		}
	)
)

#* uvrv.unif CLASS
uvrv.unif = R6Class('unif',
	#_DOC_
	#Class representing variables with uniform distribution.
	inherit = .uvrv,
	#** public
	public = list(
		#*** methods
		#**** initialize
		initialize = function (name = NULL, lower, upper) {
			#_DOC_
			#Initialisation.
			#_ARGUMENTS_
			#name: name/description (short) for the variable
			#lower: minimun value for the variable
			#upper: maximum value for the variable
			#_MAIN_
			self$name = name
			self$pars = list('min' = lower, 'max' = upper)
			private$..cstr = 0
		}
	),
	#** active
	active = list(
		#*** var
		var = function (x) {
			if (missing(x)) {diff(unlist(self$pars))**2 / 12} else {}		
		},
		#*** mean
		mean = function (x) {
			if (missing(x)) {mean(unlist(self$pars))} else {}	
		},
		#*** mode
		mode = function (x) {
			if (missing(x)) {return(NA)} else {}
		}
	)
)

#* uvrv.beta CLASS
uvrv.beta = R6Class('beta',
	#_DOC_
	#Class representing beta distributed random variables.
	inherit = .uvrv,
	#** public
	public = list(
		#*** methods
		#**** initialize
		initialize = function (name = NULL, shape1, shape2) {
			#_DOC_
			#Initialisation
			#_ARGUMENTS_
			#name: name /descritpion (short) of the variable
			#shape1, shape2: parameters of the Beta distribution
			#_MAIN_
			self$name = name
			self$pars = list('shape1' = shape1, 'shape2' = shape2)
			private$..cstr = 2
		}
	),
	#** active
	active = list(
		#*** var
		var = function (x) {
			#_DOC_
			#Returns the variance of the 'uvrv'.
			#_MAIN_
			if (missing(x)) {
				self$pars[['shape1']] * self$pars[['shape2']] / (self$pars[['shape1']] + self$pars[['shape2']])**2 / 
					(self$pars[['shape1']] + self$pars[['shape2']] + 1)
			} else {}	
		},
		#*** mean
		mean = function (x) {
			#_DOC_
			#Returns the mean of the 'uvrv'.
			#_MAIN_
			if (missing(x)) {
				self$pars[['shape1']] / (self$pars[['shape1']] + self$pars[['shape2']])
			} else {}	
		},
		#*** mode
		mode = function (x) {
			#_DOC_
			#Returns the 
			if (all(unlist(self$pars) > 1)) {
				(self$pars[['shape1']] - 1) / (self$pars[['shape1']] + self$pars[['shape2']] - 2)
			} else {
				return(NA)
			}
		} 
	)
)	

#* uvrv.gamma CLASS
uvrv.gamma = R6Class('gamma',
	#_DOC_
	#Class representing Gamma distributed variables.
	inherit = .uvrv,
	#** public
	public = list(
		#*** methods
		#**** initialize
		initialize = function (name = NULL, shape, rate) {
			#_DOC_
			#Initialisation.
			#_ARGUMENTS_
			#name: name/description (short) of the variable.
			#shape, rate: parameter of the Gamma distribution
			#trunc: c(min, max) values. If NULL trunc = c(0, Inf)
			#_MAIN_
			self$name = name
			self$pars = list('shape' = shape, 'rate' = rate)
			if (is(rate, 'uvrv.gamma')) invisible(self)
			private$..cstr = 1
		},
		#**** multiply
		multiply = function (x) {
			#_DOC_
			#Multiplies the gamma variable by x
			#_MAIN_
			if (is(self$pars[['rate']], 'uvrv')) {
				self$pars[['rate']][['multiply']](x)
			} else {
				self$pars$rate = self$pars$rate / x
			}
		},
		#**** cmp
		cmp = function () {
			if (is(self$pars[['rate']], 'uvrv.gamma')) {
				return(
					uvrv.gamcmp$new(
						name = self$name,
						shape1 = self$pars[['shape']],
						shape2 = self$pars[['rate']]$pars[['shape']],
						rate = self$pars[['rate']]$pars[['rate']]
					)
				)
			}
		}
	),
	#** active
	active = list(
		#*** var
		var = function () {
			self$pars[['shape']] / self$pars[['rate']]**2
		},
		#*** mean
		mean = function () {
			self$pars[['shape']] / self$pars[['rate']]
		},
		#*** mode
		mode = function () {
			if (self$pars[['shape']] > 1) {
				(self$pars[['shape']] - 1) / self$pars[['rate']]
			} else {
				return(NA)
			}
		}
	)
)	

#*** TO UPDATE RATE AND SHAPE OF THE GAMMA DISTRIBUTION
#The following functions are used to update the gamma variable parameters.
update.shp <- function (shp, Y, K) {
	#_DOC_
	#Updates the shape of a gamma distributed variable.
	#The precision matrix of the data is assumed to be the identity matrix.
	#_ARGUMENTS_
	#shp: prior shape
	#Y: matrix of data
	#K: orthogonal basis matrix
	#_MAIN_
	Y = as.matrix(Y)
	K = as.matrix(K)
	shp.u = ncol(Y) * (nrow(Y) - ncol(K)) / 2
	return(shp + shp.u)
} 
update.rate.ort <- function (rt, Y, K, E = apply(K, 2, ssq)) {
	#_DOC_
	#Updates the rate of a gamma distributed variable.
	#The precision matrices of the data is  assumed to be the identity matrix.
	#_ARGUMENTS_
	#rt: prior rate 
	#Y: matrix of data
	#K: orthogonal basis matrix
	#E: ssq of the basis vectors
	#_CONTAINS_
	fun <- function (A, y) {
		return(t(y) %*% A %*% y)
	}
	#_MAIN_
	K = as.matrix(K)
	Y = as.matrix(Y)
	A = diag(1, nrow(K)) - K %*% diag(1/E, length(E)) %*% t(K)
	rt.u = 0.5 * sum(apply(Y, 2, function(y)fun(A = A, y = y)))
	return(rt + rt.u)
} 

update.rate.ort3 <- function (rt, D) {
	#_DOC_
	#Updates the rate of a gamma distributed variable.
	#The precision matrix of the data is assumed to be the identity matrix.
	#_ARGUMENTS_
	#rt: prior rate
	#D: inner product of the neglected bases
	#_MAIN_
	return(rt + 0.5 * ssq(D))
} 

update.rate.ort2 <- function (rt, Y, K, W) {
	#_DOC_
	#Updates the rate of a gamma distributed variable.
	#The precision matrix of the data is assumed to be i the dentity matrix.
	#_ARGUMENTS_
	#rt: prior rate 
	#Y: matrix of data
	#K: orthogonal basis matrix
	#W: matrix of coefficients for K (i.e. Y ~ KW)
	#_CONTAINS_
	fun <- function (A, y) {
		return(t(y) %*% A %*% y)
	}
	#_MAIN_
	K = as.matrix(K)
	W = as.matrix(W)
	Y = as.matrix(Y)
	rt.u = 0.5 * ssq(Y - K %*% t(W))
	return(rt + rt.u)
} 

#* uvrv.norm CLASS
uvrv.norm = R6Class('norm',
	#_DOC_
	#Class representing Normally distributed variables.
	inherit = .uvrv,
	#** public
	public = list(
		#*** methods
		#**** initialize
		initialize = function (name = NULL, mu, sigma) {
			#_DOC_
			#Initialisation.
			#name: name/description (short) of the variable
			#mu, sigma: mean and standard deviation
			#trunc: truncation
			#_MAIN_
			self$name = name
			self$pars = list('mean' = mu, 'sd' = sigma)
			private$..cstr = -1
		}
	),
	#** active
	active = list(
		#*** var
		var = function () {
			return(self$pars[['sd']]**2)
		},
		#*** mean
		mean = function () {
			return(self$pars[['mean']])
		},
		#*** mode
		mode = function () {
			return(self$pars[['mean']])
		}
	)
)

#* uvrv.lnorm
uvrv.lnorm = R6Class('lnorm',
	#_DOC_
	#Class representing log-Normal distributed variables.
	inherit = .uvrv,
	#** public
	public = list(
		#*** methods
		#**** initialize
		initialize = function (name = NULL, mu, sigma) {
			#_DOC_
			#Initialisation.
			#name: name/description (short) of the variable
			#mu, sigma: mean and standard deviation
			#trunc: truncation
			#_MAIN_
			self$name = name
			self$pars = list('mean' = mu, 'sd' = sigma)
			private$..cstr = -1
		}
	)
)

#* uvrv.exp CLASS
uvrv.exp = R6Class('exp',
	#_DOC_
	#Class representing Exponential distributed variables.
	inherit = .uvrv,
	#** public
	public = list(
		#*** methods
		#**** initialize
		initialize = function (name = NULL, rate) {
			#_DOC_
			#Initialisation.
			#_ARGUMENTS_
			#name: name/description (short)
			#rate: rate parameter 
			#_MAIN_
			self$name = name
			self$pars = list('rate' = rate)
			private$..cstr = 1
		},
		mode = function () {
			return(0)
		},
		mean = function () {
			return(1 / self$pars[['rate']])
		},
		var = function () {
			return(1 / self$pars[['rate']]**2)
		}, 
		#**** multiply
		multiply = function (x) {
			#_DOC_
			#Multiplies the variable by the contant x
			#_MAIN_
			self$pars[['rate']] = self$pars[['rate']] / x
		}
	)
) 

#** FUNCTIONS FOR UVRV OBJECTS
fit.uvrv <- function (nm, x, type, start, const) {
	#_DOC_
	#Wrapper to MASS::fitdistr. It returns a uvrv of the specified type fitted on x.
	#_ARGUMENTS_
	#nm: name/description of the variable
	#x: sample
	#type: distribution type
	#_MAIN_
	if (type == 'beta') {
		if (min(x) < 0) stop('x out of support: beta distribution is defined in [0,1]')
		if (max(x) > 1) stop('x out of support: beta distribution is defined in [0,1]')
		undef = c(which(x == 0), which(x == 1))
		if (length(undef) > 0) {
			x = x[-undef]
			warning(paste('x contained', length(undef), 'undefined values (0 or 1) and they have been removed'))
		}
		args = c(list('x' = x, 'densfun' = 'beta', 'start' = start, lower = sqrt(.Machine$double.eps)), const)
		pars = c(const, do.call(MASS::fitdistr, args = args)[['estimate']])
		return(uvrv.beta$new(name = nm, shape1 = pars[['shape1']], shape2 = pars[['shape2']]))
	} else if (type == 'gamma') {
		if (min(x) < 0) stop('x out of support: gamma distribution defined in [0, Inf]')
		args = c(list('x' = x, 'densfun' = 'gamma', 'start' = start, lower = sqrt(.Machine$double.eps)), const)
		pars = c(const, do.call(MASS::fitdistr, args = args)[['estimate']])
		return(uvrv.gamma$new(name = nm, shape = pars[['shape']], rate = pars[['rate']]))
	} else if (type == 'gampar') {
		if (min(x) < 0) stop('x out of support: gampar distribution defined in [0, Inf]')
		pdfun = function (x, m, s, log) dgamma(x, shape = (m + s)/s, rate = 1/s, log = log) 
		args = c(list('x' = x, 'densfun' = pdfun, 'lower' = 0, 'upper' = .Machine$double.xmax, 'start' = start, 'method' = 'Brent'), const)
		pars = c(const, do.call(MASS::fitdistr, args = args)[['estimate']])
		return(uvrv.gampar$new(name = nm, m = pars[[1]], s = pars[[2]]))
	} 
}	

par.mapping <- function (hp.nst, hp) {
	#_DOC_
	#Finds the indexes of the nested of a child in a conditional variable
	return(which(sapply(hp, function(x)identical(hp.nst, x))))
}

pars.mapping <- function (pars, allPars) {
	#_DOC_
	#Maps the parameters in pars with repsect to the parameters in allPars.
	#_ARGUMENTS_
	#pars: parameters to map
	#allPars: entire set of parameters
	#_MAIN
	sapply(pars, function(x) par.mapping(x, allPars))
}

#** INTERFACES TO FORTRAN SUBROUTINES
.intrf.uvrv__id <- function (type) {
	#_DOC_
	#Returns the integer indeitifier of a particular "uvurv" object in the Fortran environment.
	#_ARGUMENTS_
	#type: the type of the variable (e.g. gamma, norm, beta, ...)
	#_MAIN_
	.C(paste0('__uvrv_MOD_intrf_uvrv_', type, '__id'), integer(1))[[1]]
}
