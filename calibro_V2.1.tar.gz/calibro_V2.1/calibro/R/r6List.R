#  This file is part of Calibro.
#
#  Calibro is free software; you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation; either version 2 of the License, or
#  (at your option) any later version.
#  
#  Calibro is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#  
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software
#  Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
#  MA 02110-1301, USA.

#* r6.list CLASS
r6.list = R6Class('r6.list',
	#_DOC_
	#List of R6 objects.
	#It facilitates the manipulation, the #_MAIN_ of methods and the extraction of attributes of R6 objects of the same class.
	inherit = calibro.obj,
	#** public
	public = list(
		#*** methods
		#**** initialize
		initialize = function (name = NULL, objs = NULL, cl = NULL) {
			#_DOC_
			#Initialisation method.
			#_ARGUMENTS_
			#name: name for the list
			#objs: list of objects the include in the list
			#cl: class of the obects. R6 objects may have multiple class, this indicates the level of compatibility of the objects in the list.
			##_MAIN_
			self$name = name
			if (is.null(cl)) cl = class(objs[[1]])[[1]]	 #if cl is NULL the highest level iof compatibility is chosen
			if ('r6.list' %in% cl) {
				cl = objs[[1]]$cl 		#if r6.list have to be included in the r6.list take the class of the elements from the cl field
			} else {
				cl = cl[1]
			}
			private$.cl = cl
			#checks that the objects have the right classes
			if (!is.null(objs)) private$check.add(objs)
		},
		#**** append
		append = function (objs) {
			#_DOC_
			#Append objects to the 'r6.list' object.
			#_ARGUMENTS_
			#objs: list of objects
			#_MAIN_
			private$check.add(objs)
		},
		#**** replace
		replace = function (objs, nl = 2) {
			#_DOC_
			#Replace objects within the 'r6.list' object.
			#_ARGUMENTS_
			#objs: a named list with names the obj to replace and elements the replacements
			#nl: 1 => the name of self$list are considered if 2 => the obj names are considered
			#_MAIN_
			.mthd.replace.r6.list(self, objs, nl)
		},
		#**** pop
		pop = function (x, nl = 1, kp = F) {
			#_DOC_
			#Remove elements from the 'r6.list' object.
			#_ARGUMENTS_
			#x: indexes or names of the objs to remove
			#nl: 1 => the name of self$list are considered if 2 => the obj names are considered
			#keep: if T => keeps the objects indicated in x
			#_MAIN_ 
			.mthd.pop.r6.list(self, x, nl, kp)
		},
		#**** expand
		expand = function (cp.rm = F) {
			#_DOC_
			#Expand the 'r6.list' obj returning a list of all the objects within it (eventually also in nested r6.lists')
			#_ARGUMENTS_
			#cp.rm: T => remove duplicates
			#_MAIN_
			.mthd.expand.r6.list(self, cp.rm)
		},
		#**** extract
		extract = function (name, grep = F, wrap = F, ...) {
			#_DOC_
			#Extracts elements from the 'r6.list' obj.
			#_ARGUMENTS_
			#name: strings identifying or names of the objects 
			#grep: T => uses regular expressions
			#wrap: T => wrap the results in a 'r6.list' obj
			#...: additional arguments fro grep
			#_MAIN_
			.mthd.extract.r6.list(self, name, grep, wrap, ...)
		},
		#**** set.attr
		set.attr = function (attr, val, exp = T, all = T) {
			#_DOC_
			#Sets an attribute to a certain value for all the object in the r6.list.
			#Can be used to execute avtive bindings.
			#_ARGUMENTS_
			#attr: attribute name
			#val: value to set the attribute to
			#exp: expand the list before?
			#all: assign val to all or tread val as a vector (i.e. val[i] to ith obj in r6.list)
			#_MAIN_
			.mthd.set_attr.r6.list(self, attr, val, exp, all)
		}, 
		#**** get.attr
		get.attr = function (attr, mode = 'sapply', exp = T, cp.rm = F, wrap = F, cl = NULL) {
			#_DOC_
			#Returns a list/vector with the values of a specified atributed for all the objs in the r6.list.
			#_ARGUMENTS_
			#attr: attribute name
			#mode: use sapply ot r lapply
			#exp: expand the r6.list before?
			#cp.rm: remove duplicate before?
			#wrap: wraop the rsult in another r6.list
			#cl: class to use for the eventual wrapping r6.list
			#_MAIN_
			.mthd.get_attr.r6.list(self, attr, mode, exp, cp.rm, wrap, cl)
		},
		#**** exe.mthd
		exe.mthd = function (mthd, mode = 'sapply', exp = T, cp.rm = F, wrap = F, cl = NULL, ...) {
			#_DOC_
			#Execute a method for all the objs in a r6.list.
			#_ARGUMENTS_
			#mthd: name of the method
			#mode: use sapply or lapply
			#exp: expand the r6.list before
			#cp.rm: remove the duplicates before
			#wrap: wrap the results in a r6.list?
			#cl: class to use for the eventual wrapping r6.list
			#...: additional parameters to be passed to the method
			#_MAIN_
			.mthd.exe_mthd.r6.list(self, mthd, mode, exp, cp.rm, wrap, cl, ...)
		},
		#**** order
		order = function (ord, nl = 2) {
			#_DOC_
			#Orders the objs in the r6.list according to the vector arguments ord.
			#_ARGUMENTS_
			#ord: indexes, names expressing the order of the obj
			#nl: 1 => the name of self$list are considered if 2 => the obj names are considered
			.mthd.order.r6.list(self, ord, nl)
		},
		#**** print
		print = function() {
			#_DOC_
			#Printing method.
			#_MAIN_
			print(private$.list)
		}, 
		summary =  function () {
			self$exe.mthd('summary',  mode = 'lapply', exp = T, cp.rm = T, wrap = F)	
		}
	),
	#** active
	active = list(
		#*** list
		list = function (x) {
			#_DOC_
			#Return the plain list of the objs within the r6.list
			#_MAIN_
			if (missing(x)) {return(private$.list)} else {}
		},
		cl = function () {
			#_DOC_
			#Returns the cl argument used to store the objs
			#_MAIN_
			return(private$.cl)
		}
	),
	#** private
	private = list(
		#*** attributes
		.list = NULL,
		nested = NULL,
		.cl = NULL,
		#*** methods
		#**** check.add
		check.add = function (objs) .prvmthd.check_add.r6.list(self, objs),
		#**** deep_clone
		deep_clone = function (name, value) .prvmthd.deep_clone.r6.list(name, value)
	)
)

#* FUNCTIONS FOR r6.list class
r6.rep <- function (r6.obj, n, deep = T, cl = NULL) {
	#_DOC_
	#Creates and r6.list repeating 'n' times an r6 object ('r6.obj').
	#If 'deep' = T the object is copied.
	##_MAIN_
	ANS = r6.list$new(name = NULL, objs = list(r6.obj$clone(deep = deep)), cl = cl)
	if (n > 1) {
		for (i in 2:n) ANS$append(list(r6.obj$clone(deep = deep)))
	}
	return(ANS)
}
.mthd.replace.r6.list <- function (r6l, objs, nl) {
		#_DOC_
		#Replace the elements in private$.list corresponding to the same names in the r6.list given ('r6List').
		#If deep = F the replacement is in place, otherwise a copy with replaced objects is returned.
		#_MAIN_
		rpl = 0		#counts the number of replacement
		ls = r6l$list 
		if (nl == 1) {
			nms0 = names(ls)
		} else if (nl == 2) {
			nms0 = r6l$get.attr('name', mode = 'sapply', exp = T, cp.rm = F, wrap = F)
		} 
		nms1 = names(objs)
		for (i in 1:length(objs)) {
			if (r6l$cl %in% class(objs[[i]])) {
				if (nms1[i] %in% nms0) {
					ls[[which(nms0 == nms1[i])]] = objs[[i]]
					rpl = rpl + 1
				}
			} else {
				stop('cannot replace with objects of different classes!!!')
			}
		}
		r6l$.set.private('.list', val = ls)
		if (rpl == 0) warning('0 replacements')			
}	
.mthd.expand.r6.list <- function (r6l, cp.rm = F) {
	#_DOC_
	#Return the expansion (a list with all the simple r6 objects in private$.list)
	#_ARGUMENTS_
	#cp.rm: T duplicates are deleted.
	##_MAIN_
	ls = r6l$list
	nst = r6l$.get.private('nested')
	for (i in nst) {
		ls[[i]] = ls[[i]]$expand(cp.rm = F)
	}
	ls = unlist(ls)
	if (cp.rm) ls = unique(ls)
	return(ls)
}
.mthd.extract.r6.list <- function (r6l, name, grep, wrap, ...) {
	#_DOC_
	#Extracts the elements of the list having the given names, or containing the given pattern
	#_ARGUMENTS_
	#name: the name of the element or the patter to search for
	#grep: if T => name contains the pattern and grep is used to search among the name of element of the list
	#_MAIN_
	if (grep) {
		x = grep(name, r6l$get.attr('name', cp.rm = F, wrap = F), ...)
	} else {
		x = sapply(name, function(nm)which(r6l$get.attr('name', cp.rm = F, wrap = F) == nm))
	}
	if (wrap) {
		return(r6.list$new(name = NULL, objs = r6l$expand(cp.rm = F)[x], cl = r6l$cl))
	} else {
		return(r6l$expand(cp.rm = F)[x])
	}
}
.mthd.pop.r6.list <- function (r6l, x, nl, kp) {
	#_DOC_
	#Removes the elements specified from the 'r6.list' object.
	#_ARGUMENTS_
	#x: vector of names or integers indicating the element to remove from the list.
	#nl: name level. 1 => the names of the list are considered, 2 => the names of the objs are considered
	ls = r6l$list
	if (is.character(x)) {
		if (nl == 1) {
			x = unlist(sapply(x, function(xx) which(names(ls) == xx)))
		} else if (nl == 2) {
			x = unlist(sapply(x, function(xx)which(r6l$get.attr('name', mode = 'sapply', exp = T, cp.rm = F, , wrap = F) == xx)))
		} else {
			stop("unknown 'nl'.")
		}
	}
	if (length(x) > 0) {
		if (kp) {ls = ls[x]} else {ls = ls[-x]}
	}
	r6l$.set.private('.list', val = ls)
}
.mthd.set_attr.r6.list <- function (r6l, attr, val, exp, all) {
	#_DOC_
	#Sets an attribute to a certain values for all the elements of the list.
	#Arguemtns:
	#attr: attribure name
	#val: vlaue/vlaues
	#exp: expand beofre?
	#all: val to all the objs or vals[i] to obj[i]?
	#_MAIN_
	if (exp) {
		ls = r6l$expand(cp.rm = T)
	} else {
		ls = unique(r6l$list)
	}
	if (is.null(val)) {
		for (obj in ls) obj[[attr]] = NULL
	} else if (all) {
		for (obj in ls) obj[[attr]] = val
	} else if (length(val) == length(ls)) {
		for (i in 1:length(ls)) ls[[i]][[attr]] = val[[i]]				
	} else {
		stop('all is T => number of values in val must be equal to the number of element int he r6.list.')
	}	
}
.mthd.get_attr.r6.list <- function (r6l, attr, mode, exp, cp.rm, wrap, cl) {
	#_DOC_
	#Returns the pubblic attribute 'attr' for all the simple r6 objects in the r6.list.
	#_ARGUMENTS_
	#attr: attrbute name
	#cp.rm: if T duplicates are deleted
	#wrap: if T it tries to wrap the result in a r6.list
	##_MAIN_
	if (exp) {
		ls = r6l$expand(cp.rm = cp.rm)
	} else {
		ls = r6l$list
		if (cp.rm) ls = unique(ls)
	}
	ANS = do.call(mode, list(X = ls, FUN = function(x)x[[attr]]))
	names(ANS) = sapply(ls, function(x)x[['name']])
	if (wrap) {
		return(r6.list$new(name = paste0(r6l$name, '.', attr), objs = ANS, cl = cl))
	} else {
		return(ANS)
	} 
}
.mthd.exe_mthd.r6.list <- function (r6l, mthd, mode, exp, cp.rm, wrap, cl, ...) {
	#_DOC_
	#Executes the method 'mthd' for all the elements in the r6.list.
	#_ARGUMENTS_
	#mthd: method name
	#mode: 'sapply' or 'lapply' 
	#wrap: if T the it tries to wrap the result in an r6.list
	#cp.rm: if T duplicates are deleted
	#...: attional argumets for the method
	#_MAIN_
	if (exp) {
		ls = r6l$expand(cp.rm = cp.rm)
	} else {
		ls = r6l$list
		if (cp.rm) ls = unique(ls)
	}
	if (mode == 'parLapply') {
		nc = detectCores() - 1
		clus = makeCluster(nc)	#initilaises the cluster of workers
		ANS = parLapply(clus, ls, function(x) x[[mthd]](...))
		stopCluster(clus)
	} else {
		args = list('X' = ls, 'FUN' = function(x)x[[mthd]](...))
		if (mode == 'mclapply') args[['mc.cores']] = detectCores() - 1
		ANS = do.call(mode, args)
	}
	names(ANS) = sapply(ls, function(x)x[['name']])
	#~returns the results
	if (all(sapply(ANS, is.null))) {	#if nothing was returned by the method (e.g. setting of attributes)
		invisible()
	} else {
		if (wrap) {
			return(r6.list$new(name = paste0(r6l$name, '.', mthd), objs = ANS, cl = cl))
		} else {
			return(ANS)
		}
	}
	#~
}
.mthd.order.r6.list <- function (r6l, ord, nl) {
	#_DOC_
	#Orders the objs inside the r6.list according to the specifed order (ord).
	#_ARGUMENTS_
	#ord: order of the elements (names or indexes)
	#nl: 1 => the names of the list are considered, 2 => the names of the objs are considered
	#_MAIN_
	if (is.character(ord)) {
		if (nl == 1) {
			nms = names(r6l$list)
			ord = unlist(sapply(ord, function(x)which(nms == ord)))
		} else if (nl == 2) {
			nms = r6l$get.attr('name', exp = F, mode = 'sapply', wrap = F, cp.rm = )
			ord = unlist(sapply(ord, function(x)which(nms == x)))
			
		} else {
			stop("unknown 'nl'.")
		}
	}
	ls = r6l$list[ord]
	r6l$.set.private('.list', val = ls)
}
.prvmthd.check_add.r6.list <- function (r6l, objs) {
	#_DOC_
	#Check that the elements in objs are suitbale and then adds them to the list
	#_MAIN_
	nst = r6l$.get.private('nested')
	ls = r6l$.get.private('.list')
	if (is.null(names(objs))) names(objs) = paste0('obj', length(ls) + 1:length(objs))
	for (i in 1:length(objs)) {
		cli = class(objs[[i]])
		if (cli[[1]] == 'r6.list') {
			cli = objs[[i]]$cl
			nst = c(nst, length(ls) + i)
		}
		if (!(r6l$cl %in% cli)) stop('objects must have the same class')
	}
	ls = c(ls, objs)
	r6l$.set.private('nested', val = nst)
	r6l$.set.private('.list', val = ls)
}
.prvmthd.deep_clone.r6.list <- function (name, value) {
	#_DOC_
	#deep_colne method for the r6.list class.
	#_ARGUMENTS_
	#name: name of the filed
	#value: value of the filed
	#_MAIN_
	if (name == '.list') {
		return(lapply(value, function(x)x$clone(deep = T)))
	} else {
		return(value)
	}
}
