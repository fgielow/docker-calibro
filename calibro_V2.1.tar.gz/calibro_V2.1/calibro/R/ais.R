#  This file is part of Calibro.
#
#  Calibro is free software; you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation; either version 2 of the License, or
#  (at your option) any later version.
#  
#  Calibro is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#  
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software
#  Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
#  MA 02110-1301, USA.

#_DOC_
#ANNEALED IMPORTANCE SAMPLING
#Reference: Annealed importance sampling Statistics and Computing, Kluwer Academic Publishers, 2001, 11, 125-139 

#* PARAMETERS
#_DOC_
#Parameters needed for the undertaking of a generic AIS simulation.

.par.default_args.ais = list(	
	#_DOC_
	#List containing default values for the parameters necessari to run AIS simulations
	#_FIELDS_
	m = detectCores()-1,	#number of cores to use (max available -1); corresposnds to the number of simulations (i.e. 1 core / simulation)
	n = 1000, 				#sample size to achieve for each simulation (i.e. total sample size = m * n)
	nlevels = 200, 			#number of levels or anealing distributuions connecting the prior to the posterior
	b = function (...) ..b_lin.ais(...),	#function indicating the temperature schedule 
	nBatches = function (...) ..nBatches_default.ais(...), 	#function returning the number of batches.
	lBatches = function (...) ..lBatches_default.ais(...), 	#function returning the number of steps for each batch
	adapt = 1,	#adapt flag ( > 0 => adapt priposal distribution) 
	vrb = 3,	#verbose level
	prntstep = 5	#number of step after which printing summary output to screen
)
.par.ans_skel.ais = list(
	#_DOC
	#skeleton list for the output of AIS 
	#_FIELDS
	'Z' = NULL,		#sample matrix 
	'lnpd' = NULL, 	#log-likelihood values for each point in the sample
	'bestLnpd' = -.Machine$double.xmax, #best log likelihood found	
	'bestz' = NULL,	#point corresponding to the best log-likelihood 				
	'omega' = NULL	#omega values for the calculation of the marignal likelihood (or normalising constant)
)
.par.ans_upd_mthds.ais = c(
	#_DOC_
	#List of function for the updating of the list output of AIS. 
	#Each filed contain a function updating the corresponding filed in the output list.
	#_FIELDS_
	.par.ans_upd_mthds.amcmc,
	'omega' = function (ansi, ANSi) {
		omega = rbind(ansi[['omega']], ANSi[['omega']])
		ansi[['omega']] = omega
		return(ansi)
	}
)

#** AIS with RAM step
#_DOC_
#Parameters needed for the undertaking of an AIS simulation with RAM step.

.par.state_skel.ais_ram = list(
	#_DOC_
	#Skeleton list for storing the state of the simulation. 
	#State variables that are already contained in the output list are nor duplicated.
	#_FIELDS_
	S = NULL,	#LT proposal convariance matrix 
	iter = NULL	#number of iteration
)	
.par.default_state.ais_ram = list(
	#_DOC_
	#List containing the functions initialising a defaul state for the simulation.
	#Each filed initialises the corresponding filed in the state list.
	#_FIELDS_
	S = function (...) ..S_default.ais_ram(...), 
	iter = function (...) ..iter_default.ais(...)
)	#default state

#** AIS wirh AMG
#_DOC_
#Parameters needed to undertale an AIS simulation with AMG step.

.par.state_skel.ais_amg = list(
	#_DOC_
	#Skeleton list for storing the state of the simualtion.
	#State variables that are already contained in the output list are not duplicated.
	#_FIELDS_
	lnSigmas = NULL	#log-variances values for the proposal
)	
.par.default_state.ais_amg = list(
	#_DOC_
	#Initialises the sata to default values. Each field initialises the
	#corresponding one in the state list.
	lnSigmas = function (...) ..lnSigmas_default.ais_amg(...)
)	

#* AIS CLASS
ais = R6Class('ais',
	#_DOC_
	#Class representing an AIS simulation
	inherit = amcmc,
	#** public
	public = list(
		#*** methods
		#**** initialize
		initialize = function(mdl, step, ...) {
			#_DOC_
			#Initialises the class
			#_ARGUMENTS_
			#mdl: model to simulate.
			#step: kind of step ('ram' or 'amg' at the moment).
			#...: additional arguments for the simulations.
			#_MAIN_
			if (step == 'amg') {	
				private$.init_alg = function (...) .prvmthd.init_ais_amg.ais(...)
				private$.run_alg = function (...) .prvmthd.run_ais_amg.ais(...)
				private$.state_skel = .par.state_skel.ais_amg
				private$.default_state = .par.default_state.ais_amg
				private$.print_start = function (...) .prvmthd.print_start_ais_amg.ais(...)
			} else if (step == 'ram') {
				private$.init_alg = function (...) .prvmthd.init_ais_ram.ais(...)
				private$.run_alg = function (...) .prvmthd.run_ais_ram.ais(...)
				private$.state_skel = .par.state_skel.ais_ram
				private$.default_state = .par.default_state.ais_ram
				private$.print_start = function (...) .prvmthd.print_start_ais_ram.ais(...)
			}
			private$.step = step
			super$initialize(mdl = mdl, ...)
		},
		#**** plot
		plot = function (...) {
			#_DOC_
			#Plots a representation of the simulation.
			#_ARGUMENTS_
			#...: parameters to pass to the plotting function.
			#_MAIN_ 
			.mthd.plot.ais(self, ...)
		},
		#**** ais.ans
		ans.ais = function (bind = T) {
			#_DOC_
			#Returns the results of the simulation.
			#_ARGUMENTS_
			#bind: if T in case of multiple simulation binds the oputput list together.
			#_MAIN_	
			.mthd.get_ans.ais(self, bind)
		},
		#**** print
		print = function () {
			#_DOC_
			#Prints a human readable representaiton of the simulation.
			#_MAIN_
			.mthd.print.ais(self)
		},
		summary = function () {
			#_DOC_
			#Print a summary of the simulation so far.
			#_MAIN_
			.mthd.summary.ais(self)
		}
	),
	#** active
	active = list(
		#***
		step =  function (x) {
			#_DOC_
			#Returns the step adopted (ram of amg).
			#_MAIN_
			if (missing(x)) {return(private$.step)} else {}	
		},
		#**** Z
		Z = function (x) {
			#_DOC_
			#Returns the binded sample from the simulation.
			#_MAIN_
			if (missing(x)) {.actmthd.get_Z.ais(self)} else {}
		},
		#**** omega
		omega = function (x) {
			#_DOC_
			#Returns the omega values for the calculation of the marginal likelihood 
			#(or normalising constant).
			#_MAIN_
			if (missing(x)) {.actmthd.get_omega.ais(self)} else {}
		}
	),
	#** private
	private = list(
		#*** attributes
		.step = NULL,
		.ans_skel = .par.ans_skel.ais,				#output skeleton
		.ans_upd_mthds = .par.ans_upd_mthds.ais,	#updating methods
		.default_args = .par.default_args.ais,		#default arguments
		#*** methods
		.init_alg = NULL,							#initialises the simualtion
		.run_alg = NULL,							#run the simulation
		.print_start = NULL,						#print the header of the simalation	
		.cnv_single = function (...) ..cnv_single.ais(...),	#convergence criterion for one simulaton
		.cnv_multi = function (...) ..cnv_multi.ais(...)	#convergence cretirion for multiple simulation
	)
)

#* METHODS
#_DOC_
#Functions called by the methods of the 'ais' class.
#In the following AIS represent as 'ais' calss object.

.mthd.plot.ais <- function (AIS, ...) {
	#_DOC_
	#Plots the state of the simulation.
	#_ARGUMENTS_
	#...: additional graphical paramters.
	#_MAIN_ 
	plot(AIS$Z, trace = F, ...)			
}
.mthd.print.ais <- function (AIS) {
	#_DOC_
	#Prints a human readable summary of the simulation.
	#_MAIN_
	cat(paste0('\nAIS_', AIS$step, ': ', AIS$name, '\n\n'))	
	AIS$summary()
}

#* ACTIVE METHODS
#_DOC_ 
#Function called by the active bindings of the class 'ais'.
#In the following AIS is an 'ais' class object.

.mthd.summary.ais <- function (AIS) {
	#_DOC_
	#Return a summary of the simulation.
	#_MAIN_
	return(..summary.ans.ais(AIS$ans.ais(bind = T)))
}
.actmthd.get_Z.ais <- function (AIS, bind = T) {
	#_DOC_
	#Returns the matrix of values sampled during the simulation.
	#_ARGUMENTS_
	#bind: if T in case of multiple simulation binds the matrices row-wise.
	#_MAIN_
	AIS$ans.ais(bind = bind)$Z
}
.actmthd.get_omega.ais <- function (AIS, bind = T) {
	#_DOC_
	#Returns the omega values for the calculation of the marginal likelihood (or normalisation constant).
	#_ARGUMENTS_
	#bind: if T in case of multiple simulation concatenates the values together.
	#_MAIN_
	AIS$ais.ans(bind = bind)$omega
}
.mthd.get_ans.ais <- function (AIS, bind) {
	#_DOC_
	#Returns the output list.
	#_ARGUMENTS_
	#bind: if T in case of multiple simulation the lists are bind together.
	#_MAIN_
	fp = AIS$mdl$.fp
	if (bind) {
		Z = rbind.list(lapply(AIS$ans, function(x)x[['Z']][,fp, drop = F]))
		omega = unlist(lapply(AIS$ans, function(x)x[['omega']]))
		return(..brn.ais(Z, omega))
	} else {
		return(lapply(AIS$ans, function(x)..brn.ais(x[['Z']][,fp, drop = F], x[['omega']])))
	}
}

#* PRIVATE METHODS
#_DOC_
#Functions called by the private methods of the class 'ais'.

.prvmthd.run_ais_ram.ais <- function (mdl, ...) {
	#_DOC_
	#Runs an 'ais' simulation with 'ram' step.
	#_ARGUMENTS_
	#mdl: model to simulate.
	#...: additional ingnored parameters
	#_MAIN_
	z = mdl$pars$exe.mthd('r', n = 1, exp = T, cp.rm = T, mode = 'sapply', wrap = F)
	.intrf.amcmc__z_init(z)
	ANS = .intrf.ais__run(z, 2)
	ANS[['S']] = .intrf.S__get()
	ANS[['iter']] = .intrf.iter__get()
	nms = mdl$pars$get.attr('name', exp = T, cp.rm = T, wrap = F, mode = 'sapply')
	names(ANS[['bestz']]) = nms
	names(ANS[['Z']]) = mdl$pars$get.attr('name', exp = T, cp.rm = T, wrap = F, mode = 'sapply')
	return(ANS)
}
.prvmthd.run_ais_amg.ais <- function (mdl, ...) {
	#_DOC_
	#Runs an 'ais' simulation with 'amg' step.
	#_ARGUMENTS_
	#mdl: model to simulate
	#...: additional ingnored arguments
	#_MAIN_
	z = mdl$pars$exe.mthd('r', n = 1, exp = T, cp.rm = T, mode = 'sapply', wrap = F)
	.intrf.amcmc__z_init(z)
	ANS = .intrf.ais__run(z, 1)
	names(ANS[['Z']]) = mdl$pars$get.attr('name', exp = T, cp.rm = T, wrap = F, mode = 'sapply')
	ANS[['lnSigmas']] = .intrf.lnSigmas__get()
	return(ANS)
}
.prvmthd.init_ais_amg.ais <- function (mdl, fp, nlevels, lnSigmas, nBatches, lBatches, b, adapt, ...) {
	#_DOC_
	#Initialises an 'ais' simulation with 'amg' step.
	#_ARGUMENTS_
	#mdl: model to simulate
	#fp: free parameters of the model
	#nlevels: number of nelevels or annealing distributions
	#lnSigmas: log-variances of the proposal
	#nBatches: number of simulation batches
	#lBatches: number of cycle pre batch
	#b: temperature scehdule
	#adapt: adapt flag (> 0 => adapt)
	#...: additional ingnored parameters 
	#_MAIN_
	lz = length(mdl$pars$expand(cp.rm = T))
	.intrf.amcmc__set_nlevels(nlevels)
	.intrf.acount__init(matrix(0, lz, nlevels))
	.intrf.fp__init(fp)
	.intrf.lnSigmas__init(lnSigmas)
	.intrf.nBatches__init(nBatches)  
	.intrf.lBatch__init(lBatches)  
	.intrf.iter__init(integer(nlevels))
	.intrf.beta__init(b)	
	.intrf.amcmc__set_alg(3)
}
.prvmthd.init_ais_ram.ais <- function (nlevels, S, fp, nBatches, lBatches, b, adapt, iter, ...) {
	#_DOC_
	#Initialises 'ais' simulation with 'ram' step.
	#_ARGUMENTS_
	#nlevels: number of levels (annealing distributions)
	#S: LT matrix for RAM
	#fp: free parameters mask
	#nBathces: number of batch per level
	#lBatches: batch lengths
	#b: beta coefficients for the levels
	#adapt: 0 > => adapt proposals
	#iter: number of iteration
	#...: additional ignored parametrs
	#_MAIN_
	.intrf.amcmc__set_nlevels(nlevels)
	.intrf.nBatches__init(nBatches)  
	.intrf.lBatch__init(lBatches)  
	.intrf.iter__init(iter)
	.intrf.beta__init(b)	
	.intrf.amcmc__set_alg(3)
	.intrf.amcmc__set_adapt(adapt)
	.intrf.u__init(rnorm(length(fp)))
	.intrf.fp__init(fp)
	.intrf.S__init(S)
}
.prvmthd.print_start_ais_ram.ais <- function (start.time, m, n, ...) {
	#_DOC_
	#Prints the simulation header for 'ram' step.
	#_ARGUMENTS_
	#start.time: start time
	#m: number of chains
	#n: number of simulations
	#_MAIN_
	cat(paste('\n### ANNEALED IMPORTANCE SAMPLING ALGORITHM ###\n\n Start time:', start.time, 
		'\n Step: RAM\n Number of chains:', m, '\n Number of simulations:', n, '\n\n'))
}
.prvmthd.print_start_ais_amg.ais <- function (start.time, m, n, ...) {
	#_DOC_
	#Prints the simulation header for 'amg' step.
	#_ARGUMENTS_
	#start.time: start time
	#m: number of chains
	#n: number of simulations
	#_MAIN_
	cat(paste('\n### ANNEALED IMPORTANCE SAMPLING ALGORITHM ###\n\n Start time:', start.time, 
		'\n Step: AMG\n Number of chains:', m, '\n Number of simulations:', n, '\n\n'))
}

#AUXILIARY FUNCTIONS

..cnv_single.ais <- function (Z, fp, omega, t.max, size.min, vrb, ...) {
	#_DOC_
	#Convergence criterion for single simulations.
	#_ARGUMENTS_
	#Z: sampling matrix
	#fp: model free parameters
	#omega: omega values
	#t.max: threshold for the standard error of the estimated mean
	#size.min: minimum size for the sample
	#vrb: verbose level
	#...: additional ignored parameters
	#_MAIN_
	X = ..brn.ais(Z = Z[,fp], omega = omega)
	..cnv_rule.ais(X, t.max = t.max, size.min = size.min, vrb = vrb)
}
..cnv_multi.ais <- function (m, fp, t.max, size.min, vrb, ...) {
	#_DOC_
	#Convergence criterion for multiple simulations.
	#_ARGUMENTS_
	#m: number of chains
	#t.max: threshold for the standard error of the estimated mean
	#size.min: minimum size for the sample
	#vrb: verbose level
	#...: additional ingnored parameters
	#_MAIN_
	X = list(...)
	Z = rbind.list(lapply(1:m, function(i)X[[paste0('ANS', i)]][['Z']]))
	omega = c(sapply(1:m, function(i)X[[paste0('ANS', i)]][['omega']]))
	..cnv_rule.ais(..brn.ais(Z = Z[,fp], omega = omega), t.max = t.max, size.min = size.min, vrb = vrb)
}
..nBatches_default.ais <- function (nlevels, ...) {
	#_DOC_
	#Returns the default number of bathces per level.
	#_ARGUMENTS_
	#nlevels: number of levels
	#...: additional ignored parameters
	#_MAIN_
	return(c(rep(1, nlevels - 1), 1))
}
..lBatches_default.ais <- function (nlevels, ...) {
	#_DOC_
	#Returns the default length of each batch.
	#_ARGUMENTS_
	#nlevels: number of levels
	#...:additional ignored parameters
	#_MAIN_
	return(c(rep(3, nlevels - 1), 10))
}
..S_default.ais_ram <- function (fp, mdl, nlevels, ...) {
	#_DOC_
	#Returns the default value for the initial LT covariance matrix if the proposal.
	#_ARGUMENTS_
	#fp: model free parameters
	#mdl: model to simulate
	#nlevels: number of levels
	#...: additional ignored parameters
	#_MAIN_
	sigmas = apply(mdl$pars$exe.mthd('r', n = 1000, exp = T, cp.rm = T, wrap = F, mode = 'sapply'), 2, sd)
	return(array(diag(sigmas[fp]/length(fp)**0.5), dim = c(length(fp), length(fp), nlevels)))
}
..lnSigmas_default.ais_amg <- function (mdl, nlevels, ...) {
	#_DOC_
	#Returns the default values for the initial log-variances of the proposal.
	#_ARGUMENTS_
	#mdl: model to simulate
	#nlevels: number of levels
	#...: additional ignored parameters
	#_MAIN_
	sigmas = apply(mdl$pars$exe.mthd('r', n = 1000, exp = T, cp.rm = T, wrap = F, mode = 'sapply'), 2, sd) 
	sigmas[sigmas == 0] = .intrf.env_par__get('tol')
	lz = length(mdl$pars$expand(cp.rm = T))
	lnSigmas = matrix(log(sigmas/6), nrow = lz, ncol = nlevels)
}
..iter_default.ais <- function (nlevels, ...) {
	#_DOC_
	#Returns the default values for the number of iterations for each level
	#_ARGUMENTS_
	#nLevels: number of levels
	#...: additional ignored parameters
	#_MAIN_
	rep(0, nlevels)
}
..cnv_rule.ais <- function (aisOut, t.max, size.min, vrb) {
	#_DOC_
	#Evaluate the convergence of a Markov chain according to the corrected sa / mean  ratio and to the minimum effective sie to achieve.
	#_ARGUMENTS_
	#aisOut: output from 'ais' simulation
	#t.max: max allowed ratio se/mean (vector)
	#min.size: minimum allowed effective sizes of the chain (vector)
	#vrb: verbose level 1, 2, or 3.
	#_MAIN_
	smr = ..summary.ans.ais(aisOut)
	t = abs(smr$statistics[,'Corrected SE'] / smr$statistics[,'Mean'])
	smr$statistics = cbind(smr$statistics, t)
	cnv1 = t <= t.max
	cnv2 = smr[['effSize']] >= size.min
	omega.tol = smr[['omega.lnSe']] - smr[['omega.lnMean']]
	cnv3 = omega.tol <= log(0.1)
	cnv = all(cnv1 & cnv2) && cnv3
	#~printing output
	if (vrb == 1) {
		t.stat = t - t.max
		t.stat[t.stat < 0] = 0
		s.stat = size.min - smr[['effSize']]
		s.stat[s.stat < 0] = 0
		cat('\rConvergence measures (-> 0):', paste('t =', nrm(t.stat), 's = ', nrm(s.stat), '\n'))
	} else if (vrb == 2) { 
		smr$statistics = smr$statistics[,c('Mean', 'SD', 't')]
		print(smr)
	} else if (vrb == 3) {
		print(smr)
	}
	#~
	return(cnv)
}
..brn.ais <- function (Z, omega) {
	#_DOC_
	#Burns the tail of the sample, so as to eliminate outliers.
	#_ARGUMENTS_
	#Z: sample matrix
	#omega: omega values
	#_MAIN_
	nms = colnames(Z)
	Z = apply(Z, 2, hdi.mcmc, p = 0.99, smp = T)	#just the 1% of the values is discarded so as to eliminate heavy outliers.
	names(Z) = nms
	Z = coda::mcmc(Z)
	omega = hdi.mcmc(omega, 0.99, smp = T)	#just the 1% of the values is discarded so as to eliminate heavy outliers.
	omega = coda::mcmc(omega)
	ANS = list(
		'Z' = Z,
		'omega' = omega
	)
	class(ANS) = 'ans.ais'
	return(ANS)
}
..ais.crSe <- function (x, omega) {
	#_DOC_
	#Corrects the se of the mean estimate according to the effective sample size
	#_ARGUMENTS_
	#x: sample of values for one variable
	#omega: omega values
	#_MAIN_
	Vx = var(x) / ..ais.effSize(omega)
	return(sqrt(Vx))
}
..ais.effSize <- function (omega) {
	#_DOC_
	#Calculates the effectve size of the sample.
	#_ARGUEMENTS_
	#omega: omega values
	#_MAIN_
	VO = exp(logVarExp(omega - logSumExp(omega)))
	return(length(omega) / (1 + VO))
}	
..summary.ans.ais <- function (aisOut) {
	#_DOC_
	#Calculates the summary statistics charactersing an 'ais' simulation.
	#_ARGUMENTS_
	#aisOut: 'ais' simulation output
	#_MAIN_
	if (!is(aisOut, 'ans.ais')) stop('aisOut must be of calss ans.ais!!!')
	Z.mean = apply(aisOut$Z, 2, mean)
	Z.sd = apply(aisOut$Z, 2, sd)
	nse = Z.sd / sqrt(nrow(aisOut$Z))
	effSize = ..ais.effSize(aisOut$omega)
	cse = Z.sd / sqrt(effSize)
	quantiles = t(apply(aisOut$Z, 2, quantile))
	nIter = length(aisOut$omega)
	omega.lnMean = logMeanExp(aisOut$omega)
	omega.lnSd = logSdExp(aisOut$omega)
	omega.lnSe = omega.lnSd - 0.5 * log(nIter)
	eff = effSize / nIter
	stats = cbind(
		'Mean' = Z.mean,
		'SD' = Z.sd,
		'Naive SE' = nse,
		'Corrected SE' = cse
	)
	ANS = list('statistics' = stats, 'quantiles' = quantiles, 'nIter' = nIter, 'omega.lnMean' = omega.lnMean, 
		'omega.lnSe' = omega.lnSe, 'omega.lnSd' = omega.lnSd, 'effSize' = effSize, 'eff' = eff)
	class(ANS) = 'summary.ans.ais'
	return(ANS)
}
print.summary.ans.ais <- function (aos) {
	#_DOC_
	#Print method for 'summary.ans.ais' objects.
	#_ARGUMENTS_
	#aos: 'ais' summary output object
	#_MAIN_
	if (!is(aos, 'summary.ans.ais')) stop('aos must be of class summary.ans.ais!!!')
	cat(paste('\nIterations =', aos[['nIter']], '\n'))
	cat(paste('ln(E[omega]) =', aos[['omega.lnMean']], '\n'))
	cat(paste('ln(SE[omega]) =', aos[['omega.lnSe']], '\n'))
	cat(paste('ln(SD[omega]) =', aos[['omega.lnSd']], '\n'))
	cat(paste('Effective size =', aos[['effSize']], '\n'))
	cat(paste('Efficiency =', aos[['eff']], '\n'))
	cat('\n1. Empirical mean and standard deviation for each variable,\n plus standard error of the mean:\n\n')
	print(aos[['statistics']])	
	cat('\n2. Quantiles for each variable:\n\n')
	print(aos[['quantiles']])
	cat('\n\n')
}
..plot.ans.ais <- function (aisOut) {
	#_DOC_
	#Plot method for 'ais' output objects.
	#_ARGUEMENTS_
	#aisOut: 'ais' output object
	#_MAIN_
	if (!is(aisOut, 'ans.ais')) stop('aisOut must be of class ans.ais!!!')
	for (i in 1:length(aisOut$Z)) {
		plot(coda::mcmc(aisOut$Z[[i]], main = names(aisOut$Z)[[i]]))
		cat('Press ENTER to continue')
		scan()
	}
	plot(coda::mcmc(aisOut$omega), main = 'omega')
}

#** BETA SETTING
..b_lin.ais <- function (nlevels, ...) {
	#_DOC_
	#Linear trend for the beta factors relative to the different levels
	#_ARGUMENTS_
	#n: number of levels
	#a: miltiplier
	#_MAIN_
	return(1:nlevels / nlevels)
}
..b_log.ais <- function (nlevels, ...) {
	#_DOC_
	#Logarithmic trend for the beta factors relative to the different levels
	#Arguemnts:
	#n: number of levels
	#a: multiplier
	#_MAIN_
	return((1 + log(1:nlevels)) / (1 + log(nlevels)))
}
..b_sqrts.ais <- function (nlevels, ...) {
	#_DOC_
	#Geometricla trend for the beta factors relative to the different levels
	#_ARGUMENTS_
	#n: number of levels
	#a multiplier
	#_MAIN_
	return(sqrt(1:nlevels) / sqrt(nlevels))
}

#** INTERFACES TO FORTRAN SUBROUTINES
.intrf.ais__run <- function (z, step){
	#_DOC_
	#Runs an 'ais' simulation according to the given step.
	#_ARGUMENTS_
	#z: initial values for the variables
	#step: kind of step ('amg' or 'ram' now)
	#_MAIN_
	ANS = .C('__ais_MOD_intrf_ais__run',
		'step' = as.integer(step),
		'omega' = double(1),	
		'Z' = as.double(z*0),
		'bestz' = as.double(z*0),
		'lnpd' = double(1),		
		'bestLnpd' = double(1)		
	)	
	return(ANS)
}
.intrf.stepFuns___init <- function () {
	#_DOC_
	#Initialises the function vector containing all the usable steps.
	#_MAIN_
	ANS = .C('__ais_MOD_intrf_stepfuns___init')
}
.intrf.adaptFuns___init <- function () {
	#_DOC_
	#Initialises the function vector containing all the usable adaption criterion.
	#_MAIN_
	ANS = .C('__ais_MOD_intrf_adaptfuns___init')
}		
