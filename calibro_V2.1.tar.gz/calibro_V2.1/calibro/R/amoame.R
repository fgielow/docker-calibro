#NELDER-MEAD DOWNHILL SIMPLEX METHOD (amoeba)
#Reference: Press, W. H.; Teukolsky, S. A.; Vetterling, W. T. & Flannery, B. P. 
#Numerical Recipes in Fortran 90 (2Nd Ed.): The Art of Parallel Scientific Computing Cambridge University Press, 1996 

#  This file is part of Calibro.
#
#  Calibro is free software; you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation; either version 2 of the License, or
#  (at your option) any later version.
#  
#  Calibro is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#  
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software
#  Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
#  MA 02110-1301, USA.

#* PARAMETERS
#_DOC_
#Parameters to run an 'amoeba' or 'amebsa' simulation

.par.default_args.amoeba = list(
	#_DOC_
	#Default parameters needed to run an 'amoeba' simulation.
	#_FIELDS_
	'm' = 1,			#number of parallel simulations
	'ftol' = 0.0001,	#convergence tolerance 		
	'n' = 5, 			#nnumber of restart
	'itmax' = 10000, 	#maximum number of iteration per simualtion
	'vrb' = 1, 			#verbose level
	'ctr' = function (...) ..ctr_default.amoeba(...),	#constrain on parameters 
	prntstep = 1		#Print feedbacks to screen after each x simulations
)

#* AMOEBA CLASS
amoeba = R6Class('amoeba',
	#_DOC_
	#Class representing an amoeba simulation
	inherit = opt,
	#** private
	private = list(
		#*** attributes
		.ans = list('besty' = NULL, 'bestz' = NULL),		#output list 
		.default_args = .par.default_args.amoeba,		#default simulation argument values
		.init_alg = function (...) {},					#initialises the simulation (it does nothing need for compatibility)
		.run_alg = function (...) .prvmthd.run.amoeba(...),	#Only runs the simulation
		.print_start = function (...) .prvmthd.print_start.amoeba(...)	#print an header at the beginning of the simulation
	)
)

#** AUXILIARY FUNCTIONS
.prvmthd.run.amoeba <- function (mdl, fp, bestz, ftol, itmax, ctr, bnd, ...) {
	#_DOC_
	#Runs an 'amoeba' simulation
	#_ARGUMENTS_
	#mdl: model to simulate
	#fp: model free parameters
	#bestz: actual values of the parametrs corresponding to the best y
	#ftol: tolerace for the convergence criterion
	#itmax: maximum numbber of iterations
	#ctr: constrains for the model parameters
	#bnd: boundary (quantiles) for sclaing the initial simplex
	#...: addtional ignored parameters
	#_MAIN_
	P = ..init.simplex(mdl, bnd)
	.intrf.amoeba__run(P = P, pv = fp, ftol = ftol, itmax = itmax, ctr = ctr)
}
..ctr_default.amoeba <- function (mdl, ...) {
	#_DOC_
	#Return default constrain for the model parameters
	#_ARGUMENTS_
	#mdl: model to simulate
	#...: additional ignored arguments
	#_MAIN_
	mdl$pars$get.attr('.cstr', cp.rm = T, wrap = F, mode = 'sapply', exp = T)
}
.prvmthd.print_start.amoeba <- function (start.time, n, ...) {
	#_DOC_
	#Print a header at the beginning of the 'amoeba' of the simulation
	#_ARGUMENTS_
	#start.time: start time
	#n: number of simulations
	#...: additional ignored parameters
	#_MAIN_
	cat(paste('\n### NELDER-MEAD DOWNHILL SIMPLEX ALGORITHM ###\n\n Version: amoeba\n Start time:', start.time, '\n Number of simulations:', n, '\n\n'))
}
	
##** AUXILIARY FUNCTIONS for amoeba and amebsa
..init.simplex <- function (mdl, bnd) {
	#_DOC_
	#Initialises the starting simplex
	#_ARGUMENTS_
	#mdl: model to simulate
	#bnd: boundaries (quantiles) for scaling the simplex
	#_MAIN_
	require(lhs, quietly = T)
	m = length(mdl$pars$expand(cp.rm = T))
	n = length(mdl$.fp) + 1
	P = randomLHS(n, m)
	P = normalize(P, MAX = bnd[2,], MIN = bnd[1,], inv = T)
	P = sapply(1:(m), function(i)mdl$pars$expand(cp.rm = T)[[i]]$q(P[,i]))
	return(P)
}	

#** INTERFACES
.intrf.amoeba__run <- function (P, pv, ftol, itmax, ctr) {
	#_DOC_
	#Interface to the Fortran subroutine running 'amoeba' simulations.
	#_ARGUMENTS_
	#P: initial simplex
	#pv: index of the free parameters of the model
	#itmax: maximum number of iteration
	#ctr: model parameter constrain (real numbers)
	#_MAIN_
	ANS = .C('__optim_MOD_amoeba', 
		as.double(P), 
		double(nrow(P)), 
		as.integer(ncol(P)),
		as.integer(length(pv)),
		as.integer(pv), 
		as.double(ftol), 
		as.integer(itmax), 
		as.integer(ctr))
	P = matrix(ANS[[1]], nrow = nrow(P), ncol = ncol(P))
	pb = P[1,]
	yb = -ANS[[2]][1]	#the fortran routine minimises so -mdl is used as function to minimise
	return(list('bestz' = pb, 'besty' = yb))
}
.intrf.amebsa__run <- function (P, ftol, pv, itmax, b, ctr) {
	#_DOC_
	#Calls the fortran subroutine running NMD in a simulate annealing fashion
	#_ARGUMENTS_
	#P: initial simplex
	#ftol: convergence tollerance
	#itmax: max number of iterations
	#b: inverse temperature 
	#ctr: kind of constrain
	#_MAIN_
	ANS = .C('__optim_MOD_amebsa', 
		as.double(P), 
		double(nrow(P)), 
		double(ncol(P)), 
		as.double(.Machine$double.xmax), 
		as.integer(ncol(P)),
		as.integer(length(pv)),
		as.integer(pv), 
		as.double(ftol), 
		as.integer(itmax), 
		as.double(1/b),
		as.integer(ctr))		
	P = matrix(ANS[[1]], nrow = nrow(P), ncol = ncol(P))
	pb = P[1,]
	yb = -ANS[[2]][1]	#the fortran routine minimises so -mdl is used as function to minimise
	return(list('pb' = pb, 'yb' = yb))		
}

