#  This file is part of Calibro.
#
#  Calibro is free software; you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation; either version 2 of the License, or
#  (at your option) any later version.
#  
#  Calibro is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#  
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software
#  Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
#  MA 02110-1301, USA.

#_DOC_
#Interface to the fortran gpr module

.intrf.mdl__id <- function (mdlname) {
	#_DOC_
	#Returns the identifier of the kind of model in the Fortran environment
	#_ARGUMENTS_
	#mdlname: type of model (class)
	#_MAIN_
	.C(paste0('__intrf_gprs_MOD_intrf_', mdlname, '__id'), integer(1))[[1]]
}
.intrf.mdl__set <- function (mdlname) {
	#_DOC_
	#Sete the flag ideintifying the type of model
	#_ARGUMENTS_
	#id: flag value
	#_MAIN_
	ANS = .C('__intrf_gprs_MOD_intrf_gpr__set_mdl',
		'mdl' = as.integer(.intrf.mdl__id(mdlname))
	)
}
.intrf.gpr__predict <- function (gpri) {
	#_DOC_
	#Predicts for the ith gpr.
	#_ARGUMENTS_
	#gpri: gpr index
	#_MAIN_
	ANS = .C('__intrf_gprs_MOD_intrf_gpr__predict', 'gpri' = as.integer(gpri))
}	
.intrf.Y__allocate <- function (yId, ngprs) {
	#_DOC_
	#Allocates the MMY_ accorrding to the number of gprs (ngprs).
	#_ARGUMENTS_
	#yId: Y identifier
	#ngprs: number of gpr
	#_MAIN_
	ANS = .C('__intrf_gprs_MOD_intrf_y__allocate',
		'yId' = as.integer(yId),
		'ngprs' = as.integer(ngprs)
	)
}
.intrf.Y__init <- function (yId, i, Y) {
	#_DOC_
	#Initialises training training or target observation matrices.
	#Arguemtns:
	#yId: 1 fotr training, 2 for obsevations
	#i: gpr index
	#Y: matrix of values
	#_MAIN_
	ANS = .C('__intrf_gprs_MOD_intrf_y__init',
		'yId' = as.integer(yId),
		'i' = as.integer(i),
		'm' = as.integer(nrow(Y)),
		'Y' = as.double(Y)
	)	
}
.intrf.gpr__evlpd <- function (mdlname, hp) {
	#_DOC_
	#Evaluates the posterior probability density distribution of the gpr
	#Arguemtns:
	#hp: vector of hps
	#_MAIN_
	ANS = .C(paste0('__intrf_gprs_MOD_intrf_', mdlname, '__evlpd'),
		'pd' = double(1),
		'pr' = double(1),
		'Lhp' = as.integer(length(hp)),
		'hp' = as.double(hp)
	)
	return(ANS[c('pd', 'pr')])
}
.intrf.pmu__allocate <- function (ngprs) {
	#_DOC_
	#Allocates pmu_ according to the number of gprs (ngprs).
	#_MAIN_
	ANS = .C('__intrf_gprs_MOD_intrf_pmu__allocate', 
		'gprs' = as.integer(ngprs))
}
.intrf.pmu__init <- function (i, pm) {
	#_DOC_
	#Initialises pmu_. The matrices pm are stores in the slot of the MV pmu_ until full.
	#_ARGUMENTS_
	#i: gpr index
	#pm: vector
	#_MAIN_
	ANS = .C('__intrf_gprs_MOD_intrf_pmu__init', 
		'i' = as.integer(i),
		'm' = as.integer(nrow(pm)), 
		'pm' = as.double(pm)
	)
}
.intrf.pmu__get <- function (gpri) {
	#_DOC_
	#Retrieves the value of pm for the ith gpr (gpri)
	#_MAIN_
	m = .C('__intrf_gprs_MOD_intrf_pmu__dim', 
		'm' = integer(1), 
		'gpri' = as.integer(gpri)
	)[['m']]
	ANS = .C('__intrf_gprs_MOD_intrf_pmu__get', 
		'pm' = double(m), 
		'm' = as.integer(m), 
		'gpri' = as.integer(gpri)
	)
	return(as.matrix(ANS[['pm']]))
}
.intrf.prior__init <- function (priors) {
	#_DOC_
	#Initialises priors_ accroding to values in the matrix priors.
	#_MAIN_
	RES = .C('__priors_MOD_intrf_prior__init', as.integer(length(priors)), as.integer(priors))
}
.intrf.priorpars__allocate <- function (p) {
	#_DOC_
	#Allocates the matrix vector for storing the parameters of the prior distributions
	#_ARGUMENTS_
	#p: number of prior dostributions
	#_MAIN_
	RES = .C('__priors_MOD_intrf_priorpars__allocate', as.integer(p))
}
.intrf.priorpars__init <- function (i, priorpars) {
	#_DOC_
	#Initialises the prameters of the prior distributions
	#_ARGUMENTS_
	#i: distributon index
	#priorpars: distribution parameters
	#_MAIN_
	RES = .C('__priors_MOD_intrf_priorpars__init', as.integer(as.integer(i)), as.integer(length(priorpars)), as.double(priorpars))
}
.intrf.nested__allocate <- function (p) {
	#_DOC_
	#Allocates the matrix vector for storing the info necessary to consider nested hyper parameters
	#_ARGUMENTS_
	#p: number of nested hyper parameters
	#_MAIN_
	RES = .C('__priors_MOD_intrf_nested__allocate', as.integer(p))
}
.intrf.nested__init <- function (i, nested) {
	#_DOC_
	#Initialises the info nbecessary to consider nested hyper parameters
	#_ARGUMENTS_
	#i: nested hp index
	#nested: relative parameters
	#_MAIN_
	RES = .C('__priors_MOD_intrf_nested__init', as.integer(as.integer(i)), as.integer(length(nested)), as.integer(nested))
}	
.intrf.thetaMapp__allocate <- function (n) {
	#_DOC_
	#Allocates the matrix of matrices storing the mapping of the calibration parameters
	#_ARGUMENTS_
	#n: number of gpr
	#_MAIN_
	ANS = .C('__intrf_gprs_MOD_intrf_ttmapp__allocate',
		'ngprs' = as.integer(n)
	)
}
.intrf.thetaMapp__allocateMVi <- function (i, n) {
	#_DOC_
	#Allocates the matrix vectors in the matrix of matrix storing the mapping of the calibration parameters
	#_ARGUMENTS_
	#i: gpr index
	#n: number of input vectors (corresponding to the number of output of the gp)
	#_MAIN_
	ANS = .C('__intrf_gprs_MOD_intrf_ttmapp__allocatemvi',
		'i' = as.integer(i),
		'n' = as.integer(n)
	)
}			
.intrf.thetaMapp__init <- function (i, j, thetaMapp) {
	#_DOC_
	#Initilaises the mapping of the calibration parameters
	#_ARGUMENTS_
	#i: gpr index
	#j: gp output index
	#thetaMapp: mapping
	#_MAIN_
	ANS = .C('__intrf_gprs_MOD_intrf_ttmapp__init',
		'i' = as.integer(i),
		'j' = as.integer(j),
		't' = as.integer(length(thetaMapp)),
		'ttMapp' = as.integer(thetaMapp)
	)
}
.intrf.gprCal__evlPd <- function (z) {
	#_DOC_
	#Evaluates the gprCal for the input in z
	#_ARGUMENTS_
	#z: inputs
	#_MAIN_
	ANS = .C('__intrf_gprs_MOD_intrf_gprcal__evlpd',
		'pd' = double(1),
		'pr' = double(1),
		'lz' = as.integer(length(z)),
		'z' = as.double(z)
	)
	return(ANS[c('pd', 'pr')])
}
