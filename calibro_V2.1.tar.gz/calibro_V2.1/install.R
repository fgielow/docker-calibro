#TURNS OFF WARNINGS
options(warn = -1)

#CHECK DEPENDENCIES

if (!require(R6, quietly = T)) {
	cat('Installing package "R6"...', sep = '\n')
	install.packages('R6')
	if(!require(R6, quietly = T))stop("installation script failed. Try manual installation.")
} else {
	cat('Package "R6" found.\n')
}

if (!require(lhs, quietly = T)) {
	cat('Installing package "lhs"...', sep = '\n')
	install.packages('lhs')
	if(!require(lhs, quietly = T))stop("installation script failed. Try manual installation.")
} else {
	cat('Package "lhs" found.\n')
}

if (!require(coda, quietly = T)) {
	cat('Installing package "coda"...', sep = '\n')
	install.packages('coda')
	if(!require(coda, quietly = T))stop("installation script failed. Try manual installation.")

} else {
	cat('Package "coda" found.\n')
}

if (!require(modeest, quietly = T)) {
	cat('Installing package "modeest"...', sep = '\n')
	install.packages('modeest')
	if(!require(modeest, quietly = T))stop("installation script failed. Try manual installation.")

} else {
	cat('Package "modeest" found.\n')
}

if (!require(optparse, quietly = T)) {
	cat('Installing package "optparse"...', sep = '\n')
	install.packages('optparse')
	if(!require(optparse, quietly = T))stop("installation script failed. Try manual installation.")

} else {
	cat('Package "optparse" found.\n')
}

if (!require(jsonlite, quietly = T)) {
	cat('Installing package "jsonlite"...', sep = '\n')
	install.packages('jsonlite')
	if(!require(jsonlite, quietly = T))stop("installation script failed. Try manual installation.")

} else {
	cat('Package "jsonlite" found.\n')
}

if (!require(knitr, quietly = T)) {
	cat('Installing package "knitr"...', sep = '\n')
	install.packages('knitr')
	if(!require(knitr, quietly = T))stop("installation script failed. Try manual installation.")

} else {
	cat('Package "knitr" found.\n')
}
if (!require(xtable, quietly = T)) {
	cat('Installing package "xtable"...', sep = '\n')
	install.packages('xtable')
	if(!require(xtable, quietly = T))stop("installation script failed. Try manual installation.")
} else {
	cat('Package "xtable" found.\n')
}
if (!require(tinytex, quietly = T)) {
	cat('Installing package "tinytex"...', sep = '\n')
	install.packages('tinytex')
	if(!require(tinytex, quietly = T))stop("installation script failed. Try manual installation.")
} else {
	cat('Package "tinytex" found.\n')
}

#INSTALL TINYTEX
ANS = try(tinytex::install_tinytex())

#INSTALL CALIBRO
cat('Installing package "calibro"...', sep = '\n')
install.packages('src.tar.gz')
if(!require(calibro, quietly = T))stop("installation script failed. Try manual installation.")


calibro_dir = file.path(installed.packages(.libPaths())['calibro',]['LibPath'], 'calibro')	#gets installation path
Sys.chmod(file.path(calibro_dir, 'calibrino'), mode = "777", use_umask = TRUE)	#makes calibrino executable

#~to add to the .bashrc file
export_PATH = paste0('export PATH="', calibro_dir, ':$PATH"')

#~close intallation
cat('\nCalibro correctly installed.', sep = '\n') 
cat(paste0('To use Calibrino please add\n\n', export_PATH, '\n\nto your ".bashrc" file.'), sep = '\n')
cat('To verify the correct installation of Calibrino type "calibrino -h" in your bash prompt.', sep = '\n')
cat('You can exit the "R" prompt by typing "q()".\n', sep = '\n')	
	
	
	
