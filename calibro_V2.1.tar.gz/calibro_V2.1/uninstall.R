#TURNS OFF WARNINGS
options(warn = -1)

#CHECK DEPENDENCIES

if (require(calibro, quietly = T)) {

	calibro_dir = file.path(installed.packages(.libPaths())['calibro',]['LibPath'], 'calibro') #gets installation path
	export_PATH = paste0('export PATH="', calibro_dir, ':$PATH"') #to remove from .bashrc

	cat('Remove calibro dependencies as well? (y/n)', sep = '\n')
	ANS = scan(what = 'character', n = 1)
	
	if (ANS == 'y') {
		
		cat('Removing dependencies...', sep = '\n')
		
		if (require(R6, quietly = T)) {
			cat('Removing package "R6"...', sep = '\n')
			remove.packages('R6')
			cat('done', sep = '\n')
		} else {
			cat('Package "R6" not found.\n')
		}

		if (require(lhs, quietly = T)) {
			cat('Removing package "lhs"...', sep = '\n')
			remove.packages('lhs')
			cat('done', sep = '\n')
		} else {
			cat('Package "lhs" not found.\n')
		}

		if (require(coda, quietly = T)) {
			cat('Removing package "coda"...', sep = '\n')
			remove.packages('coda')
			cat('done', sep = '\n')
		} else {
			cat('Package "coda" not found.\n')
		}

		if (require(modeest, quietly = T)) {
			cat('Removing package "modeest"...', sep = '\n')
			remove.packages('modeest')
			cat('done', sep = '\n')
		} else {
			cat('Package "modeest" not found.\n')
		}

		if (require(optparse, quietly = T)) {
			cat('Removing package "optparse"...', sep = '\n')
			remove.packages('optparse')
		} else {
			cat('Package "optparse" not found.\n')
		}

		if (require(jsonlite, quietly = T)) {
			cat('Removing package "jsonlite"...', sep = '\n')
			remove.packages('jsonlite')
			cat('done', sep = '\n')
		} else {
			cat('Package "jsonlite" not found.\n')
		}

		if (require(knitr, quietly = T)) {
			cat('Removing package "knitr"...', sep = '\n')
			remove.packages('knitr')
			cat('done', sep = '\n')
		} else {
			cat('Package "jsonlite" not found.\n', sep = '\n')
		}

		if (require(xtable, quietly = T)) {
			cat('Removing package "xtable"...', sep = '\n')
			remove.packages('xtable')
			cat('done', sep = '\n')
		} else {
			cat('Package "xtable" not found.\n')
		}
		
		try(tinytex::uninstall_tinytex())	#remove tinytex

		if (require(tinytex, quietly = T)) {
			cat('Removing package "tinytex"...', sep = '\n')
			remove.packages('tinytex')
			cat('done', sep = '\n')
		} else {
			cat('Package "jsonlite" not found.\n')
		}
	}

	remove.packages('calibro')

	cat('\nCalibro and relative dependencies correctly removed.', sep ='\n') 
	cat('To completely remove Calibrino, delete the following line from your ".bashrc" file:\n', sep ='\n') 
	cat(export_PATH, sep ='\n') 
	cat('\nYou can exit the "R" prompt by typing "q()".\n', sep = '\n')	

} else {
	cat('Nothing to do. Calibro not present on your system.', sep = '\n')
	cat('You can exit the "R" prompt by typing "q()".\n', sep = '\n')	
}







